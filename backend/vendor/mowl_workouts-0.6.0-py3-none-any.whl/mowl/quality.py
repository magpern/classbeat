"""Checks a workout as a ride: does it change on the music, and can a class ride it?

It only reports; nothing here stops a save. The limits are typical of MOWL's own rides as
measured by MiniCodeMonkey/flywheel (four official rides plus a larger sample) and what the
owner knows of real classes, not app rules.
"""
from . import music
from .sync import STANDING_RPM
from .workout import mmss

MAX_STANDING_SEC = 90  # official rides stand about 30 s at a time and rarely past 90 s
CADENCE_JUMP_RPM = 15  # a bigger change inside one block is a cue the rider has to remember
MAX_ZONE_RUN_SEC = 560  # official rides hold one zone for 191-537 s at most
SHOW_TIMES = 5  # list at most this many clock times per issue
LOUD_MATCH = ((0.5, "the hard parts land on the loud parts"), (0.25, "loosely follows the music"),
              (0.0, "barely related to the music"))


def _intervals(spec: dict) -> list:
    """(start, interval, segment number) for every interval."""
    t, out = 0, []
    for n, s in enumerate(spec["segments"]):
        for i in s["intervals"]:
            out.append((t, i, n))
            t += i["sec"]
    return out


def _rpm(i: dict) -> float | None:
    rpm = i.get("rpm")
    return (rpm[0] + rpm[1]) / 2 if isinstance(rpm, list) and rpm[1] else None


def _at(times: list) -> str:
    more = f" and {len(times) - SHOW_TIMES} more" if len(times) > SHOW_TIMES else ""
    return ", ".join(mmss(t) for t in times[:SHOW_TIMES]) + more


def _energy_at(m: dict, t: float) -> float | None:
    s = music.song_at(m, t)
    return s.get("energy")


def loudness_match(spec: dict, m: dict) -> dict | None:
    """Length-weighted correlation between each work interval's zone and the energy of the music
    under it (recoveries, warm-ups and cooldowns are soft whatever the music does). None
    without section energy in the map or without enough variation to say."""
    if not any(s.get("energy") is not None for s in m["songs"]):
        return None
    points = []
    for t, i, n in _intervals(spec):
        if spec["segments"][n]["kind"] in ("recovery", "cooldown", "warmup"):
            continue
        under = [e for e in (_energy_at(m, t + 0.5 + k) for k in range(0, int(i["sec"]), 2)) if e is not None]
        if under:
            points.append((i["zone"], sum(under) / len(under), i["sec"]))
    total = sum(w for _, _, w in points)
    if len(points) < 3 or not total:
        return None
    mx, my = (sum(x * w for x, _, w in points) / total, sum(y * w for _, y, w in points) / total)
    vx, vy = (sum(w * (x - mx) ** 2 for x, _, w in points), sum(w * (y - my) ** 2 for _, y, w in points))
    if not vx or not vy:
        return None
    r = sum(w * (x - mx) * (y - my) for x, y, w in points) / (vx * vy) ** 0.5
    reading = next((text for floor, text in LOUD_MATCH if r >= floor), "the hard parts sit on the quiet parts")
    return {"value": round(r, 2), "reading": reading}


def report(wanted: dict, fitted: dict, m: dict | None = None, timeline: list | None = None) -> dict:
    """wanted: the spec as written; fitted: after sync.fit_to_music (or the same spec without
    music); m: the music map; timeline: fit_to_music's report."""
    ivs = _intervals(fitted)
    issues = []

    run, start = 0, 0
    for t, i, _ in ivs + [(0, {"sec": 0}, -1)]:
        if i.get("standing"):
            start, run = (start, run + i["sec"]) if run else (t, i["sec"])
            continue
        if run > MAX_STANDING_SEC:
            issues.append(f"standing for {run} s from {mmss(start)}; official rides rarely stand "
                          f"past {MAX_STANDING_SEC} s, so alternate with seated")
        run = 0
    low, high = STANDING_RPM[:2]
    off = [t for t, i, _ in ivs if i.get("standing") and _rpm(i) and not low <= _rpm(i) <= high]
    if off:
        issues.append(f"standing outside {low}-{high} rpm at {_at(off)}")

    best, cur = (0, 0, 0), (0, 0, 0)  # (seconds, zone, from)
    for t, i, _ in ivs:
        cur = (cur[0] + i["sec"], i["zone"], cur[2]) if cur[1] == i["zone"] else (i["sec"], i["zone"], t)
        best = max(best, cur)
    if best[0] > MAX_ZONE_RUN_SEC:
        issues.append(f"zone {best[1]} for {best[0]} s from {mmss(best[2])}; official rides hold one zone "
                      f"for at most about {MAX_ZONE_RUN_SEC} s")
    out = {"longest_zone_run": {"zone": best[1], "sec": best[0], "from": mmss(best[2])}}

    jumps, prev = [], None
    for t, i, n in ivs:
        rpm = None if i.get("acc") else _rpm(i)  # a burst is faster by design
        if rpm and prev and prev[0] == n and abs(rpm - prev[1]) > CADENCE_JUMP_RPM:
            jumps.append(t)
        if rpm:
            prev = (n, rpm)
    if jumps:
        issues.append(f"cadence changes by more than {CADENCE_JUMP_RPM} rpm inside a block at {_at(jumps)}; "
                      "a block usually keeps one cadence")

    if timeline:
        on = [r["on"] for r in timeline[1:]]
        out["changes_on_music"] = f"{sum(o != 'unsnapped' for o in on)} of {len(on)}"
    if m:
        beat = [i.get("rpm") == "beat" for _, i, _ in _intervals(wanted)]
        spans = {}  # segment number -> (start, end), as a block's cadence comes from the songs in it
        for t, i, n in ivs:
            a, b = spans.get(n, (t, t))
            spans[n] = (a, max(b, t + i["sec"]))
        off_beat = []
        for k, (t, i, n) in enumerate(ivs):
            rpm = _rpm(i)
            if not (rpm and k < len(beat) and beat[k]):
                continue
            a, b = spans[n]
            bpms = {s["bpm"] for s in m["songs"] if s["start"] < b and s["end"] > a}
            if not any(abs(rpm - x) <= 1 for bpm in bpms for x in (bpm, bpm / 2, bpm * 2)):
                off_beat.append(t)
        if off_beat:
            issues.append(f'"beat" cadence is off the beat at {_at(off_beat)}: no full, half or double '
                          "BPM suits that effort, so it uses a typical cadence instead")
        match = loudness_match(fitted, m)
        if match:
            out["loudness_match"] = match
            if match["value"] < 0:
                issues.append("the hardest efforts sit on the quietest parts of the music "
                              f"(loudness match {match['value']:+.2f})")
    out["issues"] = issues
    return out
