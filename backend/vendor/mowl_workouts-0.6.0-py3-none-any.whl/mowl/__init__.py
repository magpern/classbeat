"""Create Intelligent Cycling / MOWL workouts and time them to Swedebeat music."""
