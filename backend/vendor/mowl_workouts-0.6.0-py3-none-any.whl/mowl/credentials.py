"""Everything that identifies one user to MOWL, Swedebeat and Spotify, in one object.

Every client call takes a `Credentials`; nothing in the package keeps a token, a client ID
or a signed-in client at module level, so one process can serve many users at once. This
module never reads or writes files: the CLI and the MCP server load a `Credentials` from
`~/.mowl` (see local.py), and a hosted app builds one from its own database.

Spotify access tokens expire. `spotify_web` renews one through the refresh token and then
calls `on_spotify_token(tokens)` so the owner can persist the new tokens; `tokens` holds
`access_token`, `refresh_token` and `expires_at`. A hosted app that refreshes tokens itself
sets `spotify_refresh_enabled=False`: the package then never contacts Spotify's token endpoint
and never calls `on_spotify_token`, and an expired access token is an error. It can also set
`spotify_max_retry_wait=0`, so a 429 is raised at once instead of sleeping in its thread.
"""
import threading
from dataclasses import dataclass, field
from typing import Callable

from .errors import MowlError

DEFAULT_SPOTIFY_REDIRECT = "http://127.0.0.1:8888/callback"


@dataclass
class Credentials:
    mowl_token: str = field(default="", repr=False)
    swedebeat_token: str = field(default="", repr=False)
    swedebeat_device_id: str = ""
    # Swedebeat's app key and iv, only when not bundled in the package (dev override).
    swedebeat_app: dict | None = field(default=None, repr=False)
    spotify_client_id: str = ""
    spotify_redirect_uri: str = DEFAULT_SPOTIFY_REDIRECT
    spotify_access_token: str = field(default="", repr=False)
    spotify_refresh_token: str = field(default="", repr=False)
    spotify_expires_at: float = 0.0  # epoch seconds
    on_spotify_token: Callable[[dict], None] | None = field(default=None, repr=False, compare=False)
    spotify_refresh_enabled: bool = True
    spotify_max_retry_wait: float = 30.0  # seconds; 0 never sleeps on a 429
    # Serialises Spotify refreshes, so concurrent calls on one user's credentials renew once.
    lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False, compare=False)

    def require_mowl(self) -> str:
        if len(self.mowl_token or "") != 36:
            raise MowlError("MOWL is not connected; sign in with connect_account or `mowl connect`.")
        return self.mowl_token

    def require_swedebeat(self) -> str:
        if not self.swedebeat_token:
            raise MowlError("Swedebeat is not connected; sign in with connect_account('swedebeat') "
                            "or `mowl connect swedebeat`")
        return self.swedebeat_token

    def set_spotify_tokens(self, tokens: dict) -> None:
        """Take new Spotify tokens (a token response with `expires_at`) and tell the owner."""
        if not self.spotify_refresh_enabled:  # the owner manages tokens; nothing may renew them here
            raise MowlError("Spotify token renewal is disabled for these credentials")
        self.spotify_access_token = tokens["access_token"]
        self.spotify_refresh_token = tokens.get("refresh_token") or self.spotify_refresh_token
        self.spotify_expires_at = tokens["expires_at"]
        if self.on_spotify_token:
            self.on_spotify_token({"access_token": self.spotify_access_token,
                                   "refresh_token": self.spotify_refresh_token,
                                   "expires_at": self.spotify_expires_at})
