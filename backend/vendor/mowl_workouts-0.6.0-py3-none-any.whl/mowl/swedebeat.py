"""Swedebeat's own login and "match a Spotify list" API, for the user's own account.

Found by decompiling the Swedebeat Android app (com.swedebeat 2.1). The app logs in to
www.swedebeat.se with AES-encoded credentials and gets a token, which it then sends as the
`X-Auth-Token` header to both www.swedebeat.se/downloader/* and cloud.swedebeat.se. We
reproduce only the login handshake and the catalogue lookup; the password is never stored.
The token and device id live in the caller's `Credentials`; this module reads no user files.

"Matching a Spotify list" happens on the phone: for each Spotify track the app searches the
Swedebeat catalogue (cloud.swedebeat.se/track/extendedsearch) and keeps the first hit, so
the music that plays is Swedebeat's own licensed catalogue, not Spotify audio.
"""
import base64
import difflib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .credentials import Credentials
from .errors import MowlError

WWW = "https://www.swedebeat.se/"
CLOUD = "https://cloud.swedebeat.se/"
# The app sends an OkHttp user agent; some PHP endpoints are picky about a default one.
UA = "SwedeBeat/2.1 okhttp/4.12.0"
# The app encodes the login fields with an AES key built into it. That key is Swedebeat's,
# so it is not in the source: the release workflow writes it into the package from a GitHub
# secret (BUNDLED_FILE; shipped app data, not user state), and a caller can override it with
# Credentials.swedebeat_app = {"key", "iv"} for development. With neither, Swedebeat
# sign-in is simply unavailable.
BUNDLED_FILE = os.path.join(os.path.dirname(__file__), "_swedebeat_app.json")


def _app(creds: Credentials | None) -> dict | None:
    if creds is not None and creds.swedebeat_app:
        return creds.swedebeat_app
    try:
        with open(BUNDLED_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, ValueError):
        return None


def is_available(creds: Credentials | None = None) -> bool:
    return _app(creds) is not None


def _app_keys(creds: Credentials | None = None) -> tuple[bytes, bytes]:
    try:
        app = _app(creds)
        key, iv = app["key"].encode("latin-1"), app["iv"].encode("latin-1")
    except (TypeError, KeyError, ValueError):
        raise MowlError("Swedebeat sign-in isn't available in this version of mowl-workouts")
    if len(key) != 32 or len(iv) != 16:
        raise MowlError("the Swedebeat app key must be 32 bytes and the iv 16 bytes")
    return key, iv


# --- login ------------------------------------------------------------------------

def _encode(value: str, creds: Credentials | None = None) -> str:
    """Reproduce the app's Utils.encodeString: AES-CBC over "SwdBeat<epoch>:%%:<value>",
    hex (lowercase), then Base64. The app zero-pads to a 16-char block and pads a whole
    block when already aligned, so we match that exactly."""
    plain = f"SwdBeat{round(time.time())}:%%:{value}"
    padded = plain + "\x00" * (16 - len(plain) % 16)
    key, iv = _app_keys(creds)
    enc = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    ct = enc.update(padded.encode("utf-8")) + enc.finalize()
    return base64.b64encode(ct.hex().encode("utf-8")).decode("ascii")


def _post_json(url: str, body: dict, token: str | None = None, timeout: int = 30) -> dict:
    headers = {"Accept": "application/json", "Content-Type": "application/json", "User-Agent": UA}
    if token:
        headers["X-Auth-Token"] = token
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST", headers=headers)
    return _send(req, timeout)


def _get(url: str, token: str, timeout: int = 30) -> dict:
    req = urllib.request.Request(url, method="GET", headers={
        "Accept": "application/json", "X-Auth-Token": token, "User-Agent": UA})
    return _send(req, timeout)


def _send(req, timeout: int = 30) -> dict:
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        raise MowlError(f"Swedebeat {req.get_method()} {req.selector.split('?')[0]}: "
                        f"HTTP {e.code} {e.read()[:200]!r}") from e
    return json.loads(raw) if raw else {}


def login(creds: Credentials, email: str, password: str, force: bool = False) -> dict:
    """Log in to the user's Swedebeat account. The token and device id are set on `creds`
    (the caller persists them from there); the returned dict has no token: device_id, email,
    customer_id, brand and connected_as. A stable device id
    is reused across logins. force=True takes the session even if another device holds it
    (which can sign the phone app out), so it defaults to False."""
    device_id = creds.swedebeat_device_id or uuid.uuid4().hex[:16]
    body = {"email": _encode(email, creds), "password": _encode(password, creds),
            "deviceid": _encode(device_id, creds), "force": force}
    resp = _post_json(WWW + "downloader/login.php", body)
    token = resp.get("token")
    if not token:
        raise MowlError(resp.get("message") or resp.get("errorMessage") or "Swedebeat login failed")
    creds.swedebeat_token, creds.swedebeat_device_id = token, device_id
    return {"device_id": device_id, "email": email,
            "customer_id": resp.get("customerId"), "brand": resp.get("brand"),
            "connected_as": resp.get("customerName") or resp.get("customerId")}


# --- matching a Spotify track to the Swedebeat catalogue --------------------------

def _field(value: str) -> str:
    """Encode one term value the way the app does: ' -> ’, then URL-encode with + as %20."""
    return urllib.parse.quote(value.replace("'", "’"), safe="")


def _hits(resp) -> list:
    """The catalogue tracks in an extendedsearch response, whatever shape it arrives in (the
    decompiled model allows `data` / `searchListResult` wrappers)."""
    node = resp
    for key in ("data", "searchListResult", "tracks", "results", "hits"):
        if isinstance(node, dict) and key in node:
            node = node[key]
    if isinstance(node, dict):
        node = node.get("hit") or node.get("items") or node
    if isinstance(node, list):
        return [h for h in node if isinstance(h, dict) and h]
    return [node] if isinstance(node, dict) and node else []


def _first_hit(resp) -> dict | None:
    return next(iter(_hits(resp)), None)


# Spotify adds version notes ("- Remastered 2003", "(feat. X)", "- Radio Edit") that the
# catalogue doesn't have. Only notes with one of these words are dropped, so "(I Can't Get
# No) Satisfaction" keeps its brackets.
_VERSION = r"remaster|edit|version|mix|live|mono|stereo|feat\.?|ft\.|with |radio|single|extended|original|\d{4}"


def clean_title(title: str) -> str:
    t = re.sub(rf"\s+-\s+[^-]*\b({_VERSION}).*$", "", title, flags=re.I)
    t = re.sub(rf"\s*[(\[][^)\]]*\b({_VERSION})[^)\]]*[)\]]", "", t, flags=re.I)
    return t.strip() or title.strip()


def _norm(title: str) -> str:
    t = clean_title(title).lower().replace("&", " and ")
    t = re.sub(r"['’`]", "", t)
    return " ".join(re.sub(r"[^\w]+", " ", t).split())


def title_score(wanted: str, got: str) -> float:
    """0-1: how alike two titles are once version notes, case and punctuation are gone."""
    return difflib.SequenceMatcher(None, _norm(wanted), _norm(got)).ratio()


# The search matches loosely: "Prayer" by Bon Jovi finds "Living On A Prayer". Below this,
# a hit is a different song by the same artist, not the one asked for.
SAME_SONG = 0.85


def match_track(creds: Credentials, title: str, artist: str) -> dict:
    """Look one track up in the Swedebeat catalogue. status is "found" (the same song),
    "unsure" (only a different-looking title by that artist) or "missing"."""
    token = creds.require_swedebeat()
    q = f"(and+(term+field=songtitle+'{_field(clean_title(title))}')(term+field=artist+'{_field(artist)}'))"
    url = CLOUD + "track/extendedsearch?q=" + q + "&q.parser=structured&start=0&size=5"
    hits = _hits(_get(url, token))
    best = max(hits, key=lambda h: title_score(title, str(h.get("title") or "")), default=None)
    score = title_score(title, str(best.get("title") or "")) if best else 0.0
    status = "missing" if best is None else "found" if score >= SAME_SONG else "unsure"
    track = best and {"reference": best.get("reference"), "title": best.get("title"),
                      "artist": (best.get("artist") or {}).get("title"), "duration": best.get("duration")}
    out = {"wanted": f"{artist} - {title}", "status": status, "found": status == "found", "track": track}
    if track:
        out["swedebeat"] = f"{track['artist']} - {track['title']}"
    return out


def match_tracks(creds: Credentials, tracks: list) -> dict:
    """Match a list of [{"title", "artist"}] (extra keys ignored), in order. Returns the found,
    unsure and missing songs, and the length of the found ones in Swedebeat's versions."""
    groups = {"found": [], "unsure": [], "missing": []}
    for n, t in enumerate(tracks, 1):
        title = t.get("title") or t.get("name") or ""
        artist = t.get("artist") or next(iter(t.get("artists") or []), "")
        res = match_track(creds, title, artist)
        groups[res["status"]].append({"position": n, **res})
    secs = [r["track"]["duration"] for r in groups["found"] if isinstance(r["track"].get("duration"), (int, float))]
    return {"matched": len(groups["found"]), "uncertain": len(groups["unsure"]), "unmatched": len(groups["missing"]),
            "swedebeat_sec": round(sum(secs)), **groups}
