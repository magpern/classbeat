"""Signing in from a browser page instead of a terminal.

connect("mowl") serves a small sign-in form on 127.0.0.1 (a random port), opens it in the
user's browser and waits for them to sign in. The password goes from that form straight to
the service's own login call and is never stored, logged or echoed; only the returned token
is saved, exactly as `mowl login` does. Spotify has its own consent page instead
(spotify_web.connect). Only MOWL is required; Spotify and Swedebeat are optional.

Anything that can start a process can use it (the Claude Code panel does):
  python -m mowl.connect status | mowl | swedebeat | spotify | disconnect <service>
It prints one JSON object and never prints a token.
"""
import html
import http.server
import importlib.metadata
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.parse
import webbrowser

from . import api, local, spotify_web, swedebeat
from .errors import MowlError

LAUNCHER_FILE = local.LAUNCHER_FILE
SERVICES = ("mowl", "spotify", "swedebeat")
SPOTIFY_DASHBOARD = "https://developer.spotify.com/dashboard"
SPOTIFY_REDIRECT = "http://127.0.0.1:8888/callback"
SPOTIFY_START = "http://127.0.0.1:8888/start"
FORMS = {
    "mowl": ("MOWL", "Use the email and password you sign in to the Intelligent Cycling app with."),
    "swedebeat": ("Swedebeat", "Use the email and password of your Swedebeat account."),
}


def _version() -> str | None:
    try:
        return importlib.metadata.version("mowl-workouts")
    except importlib.metadata.PackageNotFoundError:
        return None  # run from a checkout that isn't installed


def status() -> dict:
    """What is connected and which version runs, without reading out any token."""
    have = local.connected()
    return {
        "version": _version(),
        "mowl": {"connected": have["mowl"], "required": True},
        "spotify": {"connected": have["spotify"], "required": False, "app_configured": have["spotify_app"]},
        "swedebeat": {"connected": have["swedebeat"], "required": False,
                      "available": swedebeat.is_available(local.load_credentials())},
    }


def disconnect(service: str) -> dict:
    """Forget a service's token on this computer."""
    if service not in SERVICES:
        raise MowlError(f"unknown service {service!r}; use one of {', '.join(SERVICES)}")
    local.disconnect(service)
    return {"disconnected": service}


def _sign_in(service: str, email: str, password: str, force: bool) -> dict:
    if service == "mowl":
        local.save_mowl_token(api.login(email, password))
        return {"connected": "mowl"}
    creds = local.load_credentials()
    session = swedebeat.login(creds, email, password, force=force)
    local.save_swedebeat_session(creds, session)
    return {"connected": "swedebeat", "connected_as": session["connected_as"], "brand": session["brand"]}


def _form(service: str, nonce: str, email: str = "", error: str = "") -> str:
    title, hint = FORMS[service]
    force = ("<label class=check><input type=checkbox name=force value=1> Sign in even if the "
             "Swedebeat app is signed in on another device (it signs that device out)</label>"
             if service == "swedebeat" else "")
    alert = f"<p class=error role=alert>{html.escape(error)}</p>" if error else ""
    return _page(f"Connect {title}", f"""
<h1>Connect {title}</h1>
<p class=hint>{hint}</p>{alert}
<form method=post action="/">
  <input type=hidden name=nonce value="{nonce}">
  <label>Email<input name=email type=email autocomplete=username required autofocus
    value="{html.escape(email, quote=True)}"></label>
  <label>Password<input name=password type=password autocomplete=current-password required></label>
  {force}
  <button type=submit>Sign in</button>
</form>
<p class=small>Your password goes only to {title}. It is not stored; only the sign-in
token is kept on this computer, in <code>~/.mowl</code>.</p>""")


def _page(title: str, body: str, head: str = "") -> str:
    return f"""<!doctype html><html lang=en><head><meta charset=utf-8>{head}
<meta name=viewport content="width=device-width,initial-scale=1"><title>{title}</title><style>
:root{{--bg:#f4f5f7;--card:#fff;--text:#1d1f23;--muted:#5d636e;--line:#d5d8de;--accent:#e4572e;--bad:#b42318}}
@media (prefers-color-scheme:dark){{:root{{--bg:#16181c;--card:#1f2228;--text:#eceef2;
--muted:#a3a9b4;--line:#3a3f48;--accent:#ff7a50;--bad:#ff8a80}}}}
body{{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);
color:var(--text);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{width:min(460px,calc(100% - 32px));background:var(--card);border:1px solid var(--line);
border-radius:14px;padding:28px}}
h1{{margin:0 0 4px;font-size:22px}} h1::before{{content:"🚴 "}}
.hint,.small{{color:var(--muted)}} .small{{font-size:13px;margin-bottom:0}}
label{{display:block;margin:14px 0 0;font-weight:600}}
input[type=email],input[type=password]{{display:block;box-sizing:border-box;width:100%;
margin-top:4px;padding:10px 12px;font:inherit;color:inherit;background:var(--bg);
border:1px solid var(--line);border-radius:8px}}
.check{{font-weight:400;font-size:14px;color:var(--muted)}}
button{{margin-top:20px;width:100%;padding:11px;font:inherit;font-weight:600;color:#fff;
background:var(--accent);border:0;border-radius:8px;cursor:pointer}}
.error{{color:var(--bad);font-weight:600}}
a{{color:var(--accent)}} .steps{{padding-left:20px}} .steps li{{margin:8px 0}}
input[name=client_id]{{display:block;box-sizing:border-box;width:100%;margin-top:4px;
padding:10px 12px;font:15px ui-monospace,monospace;color:inherit;background:var(--bg);
border:1px solid var(--line);border-radius:8px}}
.copy{{display:flex;gap:8px;align-items:center;margin-top:6px}}
.copy code{{flex:1;padding:6px 8px;background:var(--bg);border:1px solid var(--line);
border-radius:6px;font-size:13px;overflow-wrap:anywhere}}
.small-button{{width:auto;margin:0;padding:6px 12px;font-size:13px}}
</style></head><body><main>{body}</main></body></html>"""


def _spotify_form(nonce: str, client_id: str = "", error: str = "") -> str:
    alert = f"<p class=error role=alert>{html.escape(error)}</p>" if error else ""
    return _page("Set up Spotify", f"""
<h1>Set up Spotify</h1>
<p class=hint>Once only, about two minutes. This lets Claude search songs and make playlists
in your Spotify account. It needs Spotify Premium.</p>{alert}
<ol class=steps>
  <li>Open the <a href="{SPOTIFY_DASHBOARD}" target=_blank rel=noopener>Spotify developer
    dashboard</a> and log in with your Spotify account.</li>
  <li>Click <b>Create app</b>. Any name and description will do, for example
    <i>My MOWL classes</i>.</li>
  <li>Under <b>Redirect URIs</b>, paste this and click <b>Add</b>:
    <span class=copy><code id=uri>{SPOTIFY_REDIRECT}</code>
    <button type=button class=small-button
      onclick="navigator.clipboard.writeText(document.getElementById('uri').textContent);this.textContent='Copied'">Copy</button></span></li>
  <li>Tick <b>Web API</b>, accept the terms and click <b>Save</b>.</li>
  <li>Copy the <b>Client ID</b> from the app's page and paste it here. You don't need the
    client secret.</li>
</ol>
<form method=post action="/">
  <input type=hidden name=nonce value="{nonce}">
  <label>Client ID<input name=client_id required autofocus autocomplete=off spellcheck=false
    pattern="[0-9a-fA-F]{{32}}" title="32 letters and digits"
    value="{html.escape(client_id, quote=True)}"></label>
  <button type=submit>Save and connect Spotify</button>
</form>""")


def _save_spotify_app(fields: dict) -> dict:
    client_id = fields.get("client_id", [""])[0].strip()
    if not re.fullmatch(r"[0-9a-fA-F]{32}", client_id):
        raise MowlError("That isn't a Client ID: it should be 32 letters and digits.")
    local.save_spotify_client_id(client_id, SPOTIFY_REDIRECT)
    return {"spotify_app": "saved"}


def connect(service: str = "mowl", timeout: float = 300, open_browser=webbrowser.open) -> dict:
    """Open a sign-in page for the service in the user's browser and wait for them."""
    if service == "spotify":
        if local.connected()["spotify_app"]:
            return spotify_web.connect(local.load_credentials(), timeout)
        # First time: the setup page saves the Client ID, then sends the same tab on to
        # Spotify's consent page, which spotify_web serves at /start.
        _serve("Spotify", lambda nonce, fields, error: _spotify_form(
                   nonce, fields.get("client_id", [""])[0], error),
               _save_spotify_app,
               _page("Opening Spotify", "<h1>Saved</h1><p class=hint>Opening Spotify…</p>",
                     head=f'<meta http-equiv=refresh content="1;url={SPOTIFY_START}">'),
               timeout, open_browser)
        return spotify_web.connect(local.load_credentials(), timeout, open_browser=lambda url: None)
    if service not in FORMS:
        raise MowlError(f"unknown service {service!r}; use one of {', '.join(SERVICES)}")
    if service == "swedebeat":
        swedebeat._app_keys(local.load_credentials())  # raises "not available" before any page opens
    title = FORMS[service][0]
    prefill = local.swedebeat_email() if service == "swedebeat" else ""

    def page(nonce, fields, error):
        return _form(service, nonce, fields.get("email", [prefill])[0].strip(), error)

    def submit(fields):
        return _sign_in(service, fields.get("email", [""])[0].strip(),
                        fields.pop("password", [""])[0], force=bool(fields.get("force")))
    return _serve(title, page, submit,
                  _page(f"{title} connected", f"<h1>{title} is connected</h1>"
                        "<p class=hint>You can close this tab and go back to Claude.</p>"),
                  timeout, open_browser)


def _serve(title: str, page, submit, done_page: str, timeout: float, open_browser) -> dict:
    """Serve one form on 127.0.0.1 until submit() succeeds; submit may raise MowlError to
    show the form again with the message. page(nonce, fields, error) draws the form."""
    nonce = secrets.token_urlsafe(24)
    done = {}

    class Page(http.server.BaseHTTPRequestHandler):
        def _send(self, code: int, text: str = ""):
            self.send_response(code)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(text.encode())

        def _ours(self) -> bool:
            # Only this page may post: same host (no DNS rebinding) and same origin.
            origin = self.headers.get("Origin")
            return self.headers.get("Host") == host and origin in (None, f"http://{host}")

        def do_GET(self):
            if self.path != "/":
                return self._send(404)
            self._send(200, page(nonce, {}, ""))

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            if self.path != "/" or not self._ours() or length > 4096:
                return self._send(403)
            fields = urllib.parse.parse_qs(self.rfile.read(length).decode())
            if fields.get("nonce", [""])[0] != nonce:
                return self._send(403)
            try:
                done["result"] = submit(fields)
            except MowlError as e:
                fields.pop("password", None)  # never draw it back into the page
                return self._send(200, page(nonce, fields, str(e)))
            self._send(200, done_page)

        def log_message(self, *args):
            pass  # request lines would only be noise; nothing here may reach a log

    server = http.server.HTTPServer(("127.0.0.1", 0), Page)
    server.timeout = 1
    host = f"127.0.0.1:{server.server_address[1]}"
    url = f"http://{host}/"
    # stderr, never stdout: on the MCP server stdout is the protocol.
    print(f"Connect {title} in your browser: {url}", file=sys.stderr)
    threading.Thread(target=open_browser, args=(url,), daemon=True).start()
    deadline = time.monotonic() + timeout
    try:
        while "result" not in done and time.monotonic() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if "result" not in done:
        raise MowlError(f"no answer within {int(timeout // 60)} minutes; try again")
    return done["result"]


def remember_launcher() -> None:
    """Note which Python runs mowl, so the Claude Code panel can start this module."""
    try:
        os.makedirs(os.path.dirname(LAUNCHER_FILE), exist_ok=True)
        with open(LAUNCHER_FILE, "w", encoding="utf-8") as f:
            json.dump({"python": sys.executable}, f)
    except OSError:
        pass  # the panel can still be pointed at Python in its settings


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    remember_launcher()
    cmd = argv[0] if argv else "status"
    try:
        out = (status() if cmd == "status" else
               disconnect(argv[1]) if cmd == "disconnect" else connect(cmd))
    except (MowlError, IndexError) as e:
        print(json.dumps({"error": str(e) or "missing service"}))
        return 1
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
