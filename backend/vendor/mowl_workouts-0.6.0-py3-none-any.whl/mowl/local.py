"""Everything that reads or writes the user's files in ~/.mowl: the one place that does.

Only the entry points (cli.py, server.py, connect.py) import this. The rest of the package
takes a `Credentials` and a `MapStore` as arguments and touches no user files, so another
program (a hosted app) can use it with its own database.

  token.txt                  MOWL session token
  spotify_app.json           Spotify Client ID (and redirect URI)
  spotify_token.json         Spotify access/refresh token and expiry
  swedebeat_token.json       Swedebeat token, device id, email
  swedebeat_app.json         Swedebeat app key (dev override of the bundled one)
  music/analysis/, links/    the music maps (FileMapStore); music/*.json are the 0.3.x files
"""
import json
import os
import re

from .credentials import DEFAULT_SPOTIFY_REDIRECT, Credentials
from .errors import MowlError
from .library import split_legacy

HOME = os.path.join(os.path.expanduser("~"), ".mowl")
TOKEN_FILE = os.path.join(HOME, "token.txt")
SPOTIFY_APP_FILE = os.path.join(HOME, "spotify_app.json")
SPOTIFY_TOKEN_FILE = os.path.join(HOME, "spotify_token.json")
SWEDEBEAT_TOKEN_FILE = os.path.join(HOME, "swedebeat_token.json")
SWEDEBEAT_APP_FILE = os.path.join(HOME, "swedebeat_app.json")
LAUNCHER_FILE = os.path.join(HOME, "launcher.json")
MUSIC_DIR = os.path.join(HOME, "music")


def _read_json(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def _write_json(path: str, data: dict) -> None:
    _write(path, json.dumps(data))


# --- credentials --------------------------------------------------------------------

def save_spotify_token(tokens: dict) -> None:
    _write_json(SPOTIFY_TOKEN_FILE, tokens)


def load_credentials() -> Credentials:
    """Credentials from ~/.mowl. Missing files give empty fields; the first call that needs
    one raises the "not connected" error. A renewed Spotify token is written back."""
    try:
        with open(TOKEN_FILE, encoding="utf-8") as f:
            mowl = f.read().strip()
    except FileNotFoundError:
        mowl = ""
    app, tok = _read_json(SPOTIFY_APP_FILE), _read_json(SPOTIFY_TOKEN_FILE)
    sw = _read_json(SWEDEBEAT_TOKEN_FILE)
    sw_app = _read_json(SWEDEBEAT_APP_FILE)
    return Credentials(
        mowl_token=mowl,
        swedebeat_token=sw.get("token", ""), swedebeat_device_id=sw.get("device_id", ""),
        swedebeat_app=sw_app if "key" in sw_app and "iv" in sw_app else None,
        spotify_client_id=app.get("client_id", ""),
        spotify_redirect_uri=app.get("redirect_uri") or DEFAULT_SPOTIFY_REDIRECT,
        spotify_access_token=tok.get("access_token", ""), spotify_refresh_token=tok.get("refresh_token", ""),
        spotify_expires_at=float(tok.get("expires_at") or 0),
        on_spotify_token=save_spotify_token)


def save_mowl_token(token: str) -> None:
    _write(TOKEN_FILE, token)


def save_swedebeat_session(creds: Credentials, session: dict) -> None:
    """Keep the token from `creds` (set by swedebeat.login) with the session's details."""
    _write_json(SWEDEBEAT_TOKEN_FILE, {"token": creds.swedebeat_token, **{k: session.get(k) for k in
                                       ("device_id", "email", "customer_id", "brand")}})


def swedebeat_email() -> str:
    return _read_json(SWEDEBEAT_TOKEN_FILE).get("email", "")


def save_spotify_client_id(client_id: str, redirect_uri: str) -> None:
    _write_json(SPOTIFY_APP_FILE, {"client_id": client_id, "redirect_uri": redirect_uri})


def connected() -> dict:
    """Which services have a saved sign-in, without reading out any token."""
    return {"mowl": len(load_credentials().mowl_token) == 36,
            "spotify": os.path.exists(SPOTIFY_TOKEN_FILE), "spotify_app": os.path.exists(SPOTIFY_APP_FILE),
            "swedebeat": bool(_read_json(SWEDEBEAT_TOKEN_FILE).get("token"))}


def disconnect(service: str) -> None:
    """Forget a service's saved sign-in. Swedebeat keeps its device id and email, so the
    next login is the same device."""
    if service == "swedebeat":
        kept = {k: v for k, v in _read_json(SWEDEBEAT_TOKEN_FILE).items() if k in ("device_id", "email")}
        if kept or os.path.exists(SWEDEBEAT_TOKEN_FILE):
            _write_json(SWEDEBEAT_TOKEN_FILE, kept)
    else:
        path = TOKEN_FILE if service == "mowl" else SPOTIFY_TOKEN_FILE
        if os.path.exists(path):
            os.remove(path)


# --- music maps ---------------------------------------------------------------------

_SAFE = re.compile(r"[A-Za-z0-9_-]+")


class FileMapStore:
    """MapStore on disk: shared analyses and this user's links in separate folders. Maps
    cached by 0.3.x (one file per mix or playlist under music/) are split on first use."""

    def __init__(self, root: str | None = None):
        self.root = root or MUSIC_DIR

    def _path(self, kind: str, source: str, key: str) -> str:
        if not _SAFE.fullmatch(source) or not _SAFE.fullmatch(str(key)):
            raise MowlError(f"not a valid {source} ID: {key!r}")
        return os.path.join(self.root, *([kind] if kind else []), f"{source}-{key}.json")

    def _migrate(self, source: str, key: str) -> None:
        old = _read_json(self._path("", source, key))
        if not old.get("map") or "playlist_id" not in old:
            return
        analysis, link = split_legacy(old)
        for kind, data in (("analysis", analysis), ("links", link)):
            if not os.path.exists(self._path(kind, source, key)):  # never overwrite newer data
                _write_json(self._path(kind, source, key), data)

    def _get(self, kind: str, source: str, key: str) -> dict | None:
        path = self._path(kind, source, key)
        if not os.path.exists(path):
            self._migrate(source, key)  # the old file stays, so 0.3.x still works beside it
        return _read_json(path) or None

    def get_analysis(self, source: str, fingerprint: str) -> dict | None:
        return self._get("analysis", source, fingerprint)

    def put_analysis(self, source: str, fingerprint: str, analysis: dict) -> None:
        _write_json(self._path("analysis", source, fingerprint), analysis)

    def get_link(self, source: str, source_id: str) -> dict | None:
        return self._get("links", source, source_id)

    def put_link(self, source: str, source_id: str, link: dict) -> None:
        _write_json(self._path("links", source, source_id), link)
