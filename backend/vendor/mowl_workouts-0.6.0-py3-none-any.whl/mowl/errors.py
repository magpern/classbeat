"""The one error type the package raises for expected failures."""


class MowlError(RuntimeError):
    """`status` is the HTTP status of the failed call (None when there was none) and
    `retry_after` the seconds a 429 asked to wait (None when not given), so a caller can
    classify a failure without reading the message."""

    def __init__(self, *args, status: int | None = None, retry_after: int | None = None):
        super().__init__(*args)
        self.status = status
        self.retry_after = retry_after
