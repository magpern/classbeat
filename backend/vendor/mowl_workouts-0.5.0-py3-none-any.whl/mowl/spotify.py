"""Music map of a Spotify playlist, built from what MOWL knows about it.

MOWL cannot give the audio of Spotify tracks, but it gives each track's exact length and
BPM, and relays Spotify's section analysis (start, duration, loudness; no beats). So:
- track changes are exact, assuming the player plays the playlist in order, without
  shuffle, and with Spotify's crossfade at 10 s as MOWL's how-to asks; each track then
  starts `CROSSFADE_SEC` before the previous one ends (`crossfade` 0 for a device with
  crossfade off);
- each section starts a new bar grid, since Spotify's sections start on bar starts and an
  integer BPM would drift over a whole track; each section is one "song" entry in the map;
- a section boundary that gets clearly louder is a drop, clearly quieter a breakdown.
"""
import copy

from . import music

SECTION_DB = 3.0  # loudness change between sections (dB) that counts as a drop or breakdown
TRACK_STRENGTH = 9.0  # a new track outranks any section change when snapping
# MOWL's how-to asks for Spotify's crossfade at 10 s, but its own editor lays tracks about 9 s
# apart: fitting segment starts to track starts on four official rides gave 1-3 s error at 9 s
# against 6-10 s at 8 or 10 (reported by MiniCodeMonkey/flywheel). 8, 9 and 10 time almost alike.
CROSSFADE_SEC = 9.0
MAX_CROSSFADE_SEC = 12.0  # Spotify's own setting goes up to 12 s


def build_map(tracks: list, sections: dict, crossfade: float = CROSSFADE_SEC) -> dict:
    """tracks: MOWL playlist tracks in play order; sections: SpotifyTrackID -> sections;
    crossfade: seconds each track overlaps the next one."""
    entries, events, t0 = [], [], 0.0
    for n, tr in enumerate(tracks, 1):
        dur = tr["Duration"] / 1000.0
        bpm = float(tr.get("BPM") or 0) or 120.0
        secs = [s for s in sections.get(tr["SpotifyTrackID"]) or [] if s["start"] < dur - 0.5]
        if not secs or secs[0]["start"] > 0.5:
            secs = [{"start": 0.0, "duration": dur, "loudness": None}] + secs
        for i, s in enumerate(secs):
            a = t0 + s["start"]
            b = t0 + (secs[i + 1]["start"] if i + 1 < len(secs) else dur)
            entries.append({"song": len(entries) + 1, "track": n, "start": round(a, 3), "end": round(b, 3),
                            "bpm": bpm, "bpm_known": bool(tr.get("BPM")), "first_downbeat": round(a, 3),
                            "first_phrase": round(a, 3), "phrase_bars": music.PHRASE_BARS,
                            "beat1_margin": None, "beat1_source": "spotify section"})
            if i == 0:
                if n > 1:
                    events.append({"t": round(a, 3), "kind": "track", "strength": TRACK_STRENGTH,
                                   "song": entries[-1]["song"]})
            elif s.get("loudness") is not None and secs[i - 1].get("loudness") is not None:
                d = s["loudness"] - secs[i - 1]["loudness"]
                if abs(d) >= SECTION_DB:
                    events.append({"t": round(a, 3), "kind": "drop" if d > 0 else "breakdown",
                                   "strength": round(abs(d) / SECTION_DB, 2), "song": entries[-1]["song"]})
        # The next track fades in over this one's tail, so both grids are live there
        # (sync snaps on either; music.song_at gives the incoming track).
        t0 += dur - (crossfade if n < len(tracks) else 0.0)
    return {"version": music.MAP_VERSION, "source": "spotify", "duration": round(t0, 3), "crossfade": crossfade,
            "songs": entries, "events": events,
            "tracks": [{"track": n, "title": tr["Title"], "artist": tr["Artist"], "bpm": tr.get("BPM"),
                        "spotify_id": tr["SpotifyTrackID"], "sec": round(tr["Duration"] / 1000.0, 3)}
                       for n, tr in enumerate(tracks, 1)]}


def with_crossfade(m: dict, crossfade: float) -> dict:
    """The map as heard with another crossfade: track n moves by the change times (n - 1).
    A map without `crossfade` (cached before it existed) has its tracks back to back."""
    d = m.get("crossfade", 0.0) - crossfade
    if not d:
        return m
    m = copy.deepcopy(m)
    track_of = {s["song"]: s["track"] for s in m["songs"]}
    for s in m["songs"]:
        shift = d * (s["track"] - 1)
        for k in ("start", "end", "first_downbeat", "first_phrase"):
            s[k] = round(s[k] + shift, 3)
    for e in m["events"]:
        e["t"] = round(e["t"] + d * (track_of[e["song"]] - 1), 3)
    m["duration"] = round(m["duration"] + d * (len(m["tracks"]) - 1), 3)
    m["crossfade"] = crossfade
    return m


def unknown_bpm(m: dict) -> list:
    """Titles of tracks MOWL had no BPM for; their bars are a guess at 120 BPM."""
    return [t["title"] for t in m["tracks"] if not t["bpm"]]
