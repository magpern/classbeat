"""Workout spec -> MOWL program, segments and intervals.

Spec: {"name", "description"?, "short_description"?,
       "music"?: {"swedebeat": mix name or ID, "snap"?: true, "fit"?: false},
       "segments": [{"name", "kind": "warmup|main|recovery|cooldown",
                     "intervals": [{"sec", "zone" (1-7), "standing"?, "acc"?,
                                    "rpm"?: [from, to] or "beat",
                                    "game"?: one of GAMES, "ftp_test"?: 3, 5 or 20}]}]}

Saving mirrors the app's Session Designer: PUT v1/programs (or v1/programs/{id}),
then per segment PUT v1/segments, DELETE .../intervals, PUT .../intervals/multiple,
and finally PUT v1/programs/{id}/segments, which replaces the segment list.
"""
from . import api
from .credentials import Credentials
from .errors import MowlError

# Zone set 1 (v1/intensityzonesets/1): HR, FTP, MAP, FTHR ranges per zone.
ZONES = {
    1: (-1, 70, 0, 55, -1, 49, 61, 68),
    2: (71, 76, 56, 75, 50, 55, 69, 83),
    3: (77, 82, 76, 90, 56, 75, 84, 94),
    4: (83, 90, 91, 105, 76, 94, 95, 105),
    5: (91, 96, 106, 120, 95, 105, 106, -1),
    6: (97, 98, 120, 150, 106, 120, -1, -1),
    7: (99, 100, -1, -1, -1, -1, -1, -1),  # Neuromuscular Power: all out, no power ceiling
}
ZONE_NAMES = {1: "Recovery", 2: "Endurance", 3: "Tempo", 4: "Threshold", 5: "VO2max", 6: "Anaerobic",
              7: "Neuromuscular"}
# IF^2 per zone, fitted against the TSS the app stored for real programs (within ~1 TSS;
# the app recomputes its own value when it re-saves a workout). Zone 7 is fitted from a
# single race class, so it's the roughest of them.
TSS_WEIGHT = {1: 0.249, 2: 0.42, 3: 0.75, 4: 1.039, 5: 1.197, 6: 1.937, 7: 2.282}
POSITION = {False: 1, True: 2}  # 1 Seated, 2 Standing
CYCLE = {False: 1, True: 4}  # 1 SB, 4 ACC
KINDS = ("warmup", "main", "recovery", "cooldown")
# Team games from the app's "Add a game" menu -> IntervalGameID, read from a workout made with
# each game in menu order. The server uses older names (4 Toe The Line, 5 Speed, 6 FillTheCup,
# 7 Dummygame1); 2 Race Track Laps and 3 Time Trial aren't in the menu. Saving the ID is enough.
GAMES = {"racetrack": 1, "power_pull": 4, "fast_lane": 5, "overflow": 6, "ghost_target": 7}
# FTP tests by length in minutes -> FtpTestID ("No FtpTest found by ID 4").
FTP_TESTS = {3: 1, 5: 2, 20: 3}
GAME_NAMES = {v: k for k, v in GAMES.items()}
MAX_PROGRAM_SEC = 3 * 3600
MIN_COOLDOWN_SEC = 60  # the app refuses to save a workout without a cooldown of at least this


def seconds(seg: dict) -> int:
    return sum(i["sec"] for i in seg["intervals"])


def total_seconds(spec: dict) -> int:
    return sum(seconds(s) for s in spec["segments"])


def validate(spec: dict) -> None:
    """Raise ValueError unless the spec is something the app would accept."""
    def need(cond, msg):
        if not cond:
            raise ValueError(msg)
    need(isinstance(spec, dict), "spec must be an object")
    need(isinstance(spec.get("name"), str) and spec["name"].strip(), "workout needs a name")
    need(len(spec["name"]) <= 100, "name max 100 chars")
    need(len(spec.get("description", "")) <= 500, "description max 500 chars")
    segs = spec.get("segments")
    need(isinstance(segs, list) and segs, "workout needs segments")
    for s in segs:
        need(isinstance(s.get("name"), str) and s["name"].strip(), "every segment needs a name")
        need(s.get("kind") in KINDS, f"segment {s['name']!r}: kind must be one of {KINDS}")
        need(isinstance(s.get("intervals"), list) and s["intervals"], f"segment {s['name']!r} has no intervals")
        for i in s["intervals"]:
            need(isinstance(i.get("sec"), int) and 1 <= i["sec"] <= 3600,
                 f"segment {s['name']!r}: sec must be a whole number 1-3600 (MOWL stores whole seconds)")
            need(i.get("zone") in ZONES, f"segment {s['name']!r}: zone must be 1-7")
            need(i.get("game") in (None, *GAMES), f"segment {s['name']!r}: game must be one of {tuple(GAMES)}")
            if "ftp_test" in i:
                need(i["ftp_test"] in FTP_TESTS, f"segment {s['name']!r}: ftp_test must be 3, 5 or 20 (minutes)")
                need(i["sec"] == i["ftp_test"] * 60, f"segment {s['name']!r}: a {i['ftp_test']} min FTP test lasts {i['ftp_test'] * 60} s")
                need("game" not in i, f"segment {s['name']!r}: an interval can't be a game and an FTP test")
            rpm = i.get("rpm", [0, 0])
            need(isinstance(rpm, list) and len(rpm) == 2 and all(isinstance(x, int) and 0 <= x <= 200 for x in rpm)
                 and rpm[0] <= rpm[1], f"segment {s['name']!r}: rpm must be [from, to]")
    # The app's own rules for games and FTP tests, across segment boundaries too.
    special = [bool(i.get("game") or i.get("ftp_test")) for s in segs for i in s["intervals"]]
    need(not any(a and b for a, b in zip(special, special[1:])),
         "games and FTP tests must be separated by a regular interval")
    need(sum("ftp_test" in i for s in segs for i in s["intervals"]) <= 1, "only one FTP test per workout")
    need(segs[-1]["kind"] == "cooldown", "the last segment must be the cooldown")
    need(sum(s["kind"] == "cooldown" for s in segs) == 1, "exactly one cooldown segment")
    need(seconds(segs[-1]) >= MIN_COOLDOWN_SEC, f"cooldown must be at least {MIN_COOLDOWN_SEC} s")
    need(total_seconds(spec) <= MAX_PROGRAM_SEC, "workout max 3 hours")


def tss(spec: dict) -> float:
    return sum(i["sec"] * TSS_WEIGHT[i["zone"]] for s in spec["segments"] for i in s["intervals"]) / 36


def interval_body(i: dict) -> dict:
    hr0, hr1, ftp0, ftp1, map0, map1, fthr0, fthr1 = ZONES[i["zone"]]
    rpm = i.get("rpm", [0, 0])
    # Numbers as strings and the "ScaleBong" spelling copy the app exactly.
    return {
        "Duration": i["sec"], "RPMFrom": str(rpm[0]), "RPMTo": str(rpm[1]),
        "PulseZoneFrom": str(hr0), "PulseZoneTo": str(hr1), "Intensity": 1,
        "PositionTypeID": POSITION[bool(i.get("standing"))], "CycleID": CYCLE[bool(i.get("acc"))],
        "FTPFrom": str(ftp0), "FTPTo": str(ftp1), "MAPFrom": str(map0), "MAPTo": str(map1),
        "FTHRFrom": str(fthr0), "FTHRTo": str(fthr1), "LTHRFrom": "0", "LTHRTo": "0",
        "VO2From": "0", "VO2To": "0", "ScaleCoggan": i["zone"], "Scale1to5": 0, "ScaleBong": 0,
        "PresetCode": 0, "CreatedfromCode": False, "CueCards": [],
        "IntervalGame": {"IntervalGameID": GAMES[i["game"]]} if i.get("game") else None,
        "FtpTest": {"FtpTestID": FTP_TESTS[i["ftp_test"]]} if i.get("ftp_test") else None,
        "Gradient": 0,
    }


def save(spec: dict, creds: Credentials, playlist_id: int = -1, program_id: int | None = None) -> dict:
    """Create the workout, or with program_id re-save an existing one the way the app does
    (new segment copies replace the old segment list). Returns the program and segment IDs."""
    validate(spec)
    path = f"v1/programs/{program_id}" if program_id else "v1/programs"
    program = api.call(creds, "PUT", path, {
        **({"ProgramID": program_id} if program_id else {}),
        "ProgramCategoryID": api.MY_WORKOUTS, "Name": spec["name"],
        "Description": spec.get("description", ""), "ShortDescription": spec.get("short_description", ""),
        "PlaylistID": playlist_id, "IsPublic": False, "TSS": tss(spec), "ActivityTypeID": 0,
    })
    pid = program["ProgramID"]
    if program_id and pid != program_id:
        # PUT v1/programs without the ID creates a new program; never write segments into a
        # copy while reporting an update.
        raise MowlError(f"MOWL saved workout {program_id} as a new workout {pid}; check My Workouts")
    seg_ids = []
    for s in spec["segments"]:
        seg = api.call(creds, "PUT", "v1/segments", {
            "Name": s["name"], "Description": s.get("description", ""),
            "ShortDescription": s.get("short_description", ""),
            "IsWarmup": s["kind"] == "warmup", "IsActiveRecovery": s["kind"] == "recovery",
            "IsCooldown": s["kind"] == "cooldown", "TotalDuration": seconds(s),
            "IsPublic": False, "IsTemplate": False, "ActivityTypeID": 0,
        })
        sid = seg["SegmentID"]
        api.call(creds, "DELETE", f"v1/segments/{sid}/intervals")
        api.call(creds, "PUT", f"v1/segments/{sid}/intervals/multiple",
                 {"Intervals": [interval_body(i) for i in s["intervals"]]})
        seg_ids.append(sid)
    api.call(creds, "PUT", f"v1/programs/{pid}/segments", {"SegmentIDs": seg_ids})
    return {"program_id": pid, "segment_ids": seg_ids, "updated": bool(program_id)}


def summarize(program: dict) -> dict:
    """Compact view of a program as returned by GET v1/programs/{id}."""
    t, segs = 0, []
    for s in program.get("Segments") or []:
        ivs = [{"start": mmss(t + sum(x["Duration"] for x in s["Intervals"][:n])), "sec": i["Duration"],
                "zone": i["ScaleCoggan"], "position": i["PositionTypeName"], "cycle": i["CycleName"],
                "rpm": [i["RPMFrom"], i["RPMTo"]],
                **({"game": GAME_NAMES.get(i["IntervalGame"]["IntervalGameID"], i["IntervalGame"].get("IntervalGameName"))}
                   if i.get("IntervalGame") else {}),
                **({"ftp_test": i["FtpTest"].get("DisplayName")} if i.get("FtpTest") else {})}
               for n, i in enumerate(s["Intervals"])]
        kind = ("warmup" if s["IsWarmup"] else "recovery" if s["IsActiveRecovery"]
                else "cooldown" if s["IsCooldown"] else "main")
        segs.append({"name": s["Name"], "kind": kind, "start": mmss(t), "sec": s["TotalDuration"], "intervals": ivs})
        t += s["TotalDuration"]
    pl = program.get("Playlist") or {}
    return {"program_id": program["ProgramID"], "name": program["Name"], "public": program["IsPublic"],
            "duration": mmss(program["TotalDuration"]), "tss": round(program.get("TSS") or 0, 1),
            "music": ({"type": pl.get("PlaylistType"), "name": pl.get("PlaylistName"),
                       "playlist_id": program.get("PlaylistID")} if pl else None),
            "description": program.get("Description"), "segments": segs}


def mmss(sec: float) -> str:
    tenths = round(max(0.0, float(sec)) * 10)
    whole, frac = divmod(tenths, 10)
    return f"{whole // 60}:{whole % 60:02d}" + (f".{frac}" if frac else "")
