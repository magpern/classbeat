"""Thin client for the MOWL REST API (https://api.mowl.com/v1/).

Every call mirrors one the Intelligent Cycling app makes (captured 2026-10-27, app 8.8.8).
The session token comes from the `Credentials` passed to each call and is never logged.
"""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from .credentials import Credentials
from .errors import MowlError

API = "https://api.mowl.com/"
HEADERS = {
    # The server rejects Python's default User-Agent, so present the app's.
    "User-Agent": "IntelligentCycling/UE5-CL-0 (http-legacy) Windows/10.0.26200.1.256.64bit",
    "itc-client-version": "8.8.8",
    "itc-client-os-family": "Windows",
    "content-type": "application/json;charset=utf-8",
}
MY_WORKOUTS = 17  # ProgramCategoryID of "My Workouts"


# Two constant IDs the app uses when signing in (captured from its traffic): the first
# identifies the app to Authenticate, the second exchanges the login ticket for a token.
APP_GUID = "C00869F2-4457-486D-ADAD-47409605B187"
TICKET_GUID = "8285D895-29F6-425B-AE60-1725A68FF42E"


def login(email: str, password: str) -> str:
    """Sign in with email + password and return the session token; the caller keeps it.
    Mirrors the app: Authenticate -> a ticket, then exchange the ticket for the token. No proxy
    needed. The password is used only for this call and never stored."""
    ticket = call(None, "POST", f"v1/Authentication/Authenticate/{APP_GUID}",
                  form={"Email": email, "Password": password})
    if not isinstance(ticket, str) or len(ticket) != 36:
        raise MowlError("sign-in failed; check your email and password")
    token = call(None, "GET", f"v1/Authentication/Ticket/{ticket}/{TICKET_GUID}")
    if not isinstance(token, str) or len(token) != 36:
        raise MowlError("sign-in did not return a token")
    return token


def call(creds: Credentials | None, method: str, path: str, body=None, form=None, timeout: int = 30):
    headers = dict(HEADERS)
    if creds is not None:  # login calls have no token yet
        headers["authorization"] = creds.require_mowl()
    data = json.dumps(body).encode() if body is not None else None
    if form is not None:
        # Several endpoints take form fields, not JSON.
        data = urllib.parse.urlencode(form).encode()
        headers["content-type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(API + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            out = json.load(r)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise MowlError("MOWL rejected the token; sign in again with connect_account or `mowl connect`.") from e
        raise MowlError(f"{method} {path}: HTTP {e.code}") from e
    if out.get("Error"):
        raise MowlError(f"{method} {path}: {out['Error']}")
    return out["Data"]


# --- workouts ---------------------------------------------------------------

def list_workouts(creds: Credentials, ordering: str = "creationDateDesc", page: int = 0, per_page: int = 50) -> list:
    return call(creds, "POST", "v1/programs", form={
        "ProgramCategoryID": MY_WORKOUTS, "PageNumber": page, "itemsPerPage": per_page,
        "BikeTypeID": 1, "ProgramOrdering": ordering})


def get_workout(creds: Credentials, program_id: int) -> dict:
    return call(creds, "GET", f"v1/programs/{program_id}")


def zone_set(creds: Credentials, zone_set_id: int = 1) -> dict:
    return call(creds, "GET", f"v1/intensityzonesets/{zone_set_id}")


# --- Swedebeat music ----------------------------------------------------------

def swedebeat_mixes(creds: Credentials, name_like: str = "") -> list:
    """The user's own Swedebeat mixes: [{ID, Name, URL, DurationInMilliseconds}]."""
    return call(creds, "POST", "v1/swedebeat/Playlists", form={"NameLike": name_like})["Playlists"]


def find_swedebeat(creds: Credentials, wanted) -> dict:
    """Match a Swedebeat mix by exact ID or case-insensitive name."""
    wanted = str(wanted).strip()
    matches = [m for m in swedebeat_mixes(creds)
               if m["ID"] == wanted or m["Name"].lower() == wanted.lower()]
    if len(matches) != 1:
        raise MowlError(f"Swedebeat mix {wanted!r}: {len(matches)} matches")
    return matches[0]


def attach_swedebeat(creds: Credentials, swedebeat_id: str) -> dict:
    """Wrap a Swedebeat mix in a MOWL playlist; returns the playlist with its PlaylistID."""
    return call(creds, "PUT", "v1/swedebeat/Playlist", form={"SwedebeatPlaylistID": swedebeat_id})


def playlist_tracks(creds: Credentials, playlist_id: int) -> list:
    return call(creds, "GET", f"v1/Playlists/{playlist_id}/tracks")


def wait_indexed(creds: Credentials, playlist_id: int, timeout: float = 180) -> dict:
    """MOWL processes a new mix before the app can play it; poll like the app does."""
    deadline = time.monotonic() + timeout
    while True:
        track = playlist_tracks(creds, playlist_id)[0]
        if track.get("IndexStatus") == "Track indexing done":
            return track
        if track.get("IndexError"):
            raise MowlError(f"MOWL could not process the mix: {track['IndexError']}")
        if time.monotonic() > deadline:
            raise MowlError("MOWL is still processing the mix; try again in a minute.")
        time.sleep(2)


# --- Spotify music --------------------------------------------------------------

def spotify_playlists(creds: Credentials, name_like: str = "") -> list:
    """The user's Spotify playlists as MOWL sees them: [{ID, Name, TrackCount, HasUnavailableTracks}]."""
    # A bare list here, unlike the Swedebeat call's {"Playlists": [...]}.
    return call(creds, "POST", "v1/Spotify/Playlists", form={"NameLike": name_like})


def find_spotify(creds: Credentials, wanted) -> dict:
    """Match a Spotify playlist by exact ID or case-insensitive name."""
    wanted = str(wanted).strip()
    matches = [p for p in spotify_playlists(creds)
               if p["ID"] == wanted or p["Name"].lower() == wanted.lower()]
    if len(matches) != 1:
        raise MowlError(f"Spotify playlist {wanted!r}: {len(matches)} matches")
    return matches[0]


def attach_spotify(creds: Credentials, spotify_id: str) -> dict:
    """Wrap a Spotify playlist in a MOWL playlist (JSON body, unlike Swedebeat); takes ~10 s."""
    return call(creds, "PUT", "v1/Spotify/Playlist", {"SpotifyPlaylistID": spotify_id}, timeout=120)


def playlist_availability(creds: Credentials, playlist_id: int) -> dict:
    """Tracks the Session Designer reports as unplayable (e.g. not available in the user's region)."""
    return call(creds, "GET", f"v1/Playlists/{playlist_id}/sessiondesigner/availability")


def spotify_sections(creds: Credentials, spotify_track_id: str) -> list:
    """Spotify's sections for a track, relayed by MOWL: [{start, duration, loudness}] (no beats)."""
    return call(creds, "GET", f"v1/Spotify/Tracks/{spotify_track_id}/AudioAnalysis")["sections"]


def download_swedebeat_audio(creds: Credentials, playlist_id: int, out_path: str) -> str:
    """Download the mix through the short-lived link MOWL gives the app."""
    links = call(creds, "GET", f"v1/swedebeat/playlist/{playlist_id}/TemporaryLinks")["TemporaryLinks"]
    req = urllib.request.Request(links[0]["TemporaryLink"], headers={"User-Agent": HEADERS["User-Agent"]})
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    tmp = out_path + ".part"
    with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)
    os.replace(tmp, out_path)
    return out_path
