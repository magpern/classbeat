"""Checks a workout as a ride: does it change on the music, and can a class ride it?

It only reports; nothing here stops a save. The limits are typical of MOWL's own rides as
measured by MiniCodeMonkey/flywheel (four official rides plus a larger sample), not app rules.
"""
from . import music
from .workout import mmss

MAX_STANDING_SEC = 90  # official rides stand about 30 s at a time and rarely past 90 s
STANDING_RPM = (60, 80)  # official rides stand at 60 to the high 70s
CADENCE_JUMP_RPM = 15  # a bigger change inside one song is a cue the music doesn't give
MAX_ZONE_RUN_SEC = 560  # official rides hold one zone for 191-537 s at most
SHOW_TIMES = 5  # list at most this many clock times per issue


def _intervals(spec: dict) -> list:
    t, out = 0, []
    for s in spec["segments"]:
        for i in s["intervals"]:
            out.append((t, i))
            t += i["sec"]
    return out


def _rpm(i: dict) -> float | None:
    rpm = i.get("rpm")
    return (rpm[0] + rpm[1]) / 2 if isinstance(rpm, list) and rpm[1] else None


def _at(times: list) -> str:
    more = f" and {len(times) - SHOW_TIMES} more" if len(times) > SHOW_TIMES else ""
    return ", ".join(mmss(t) for t in times[:SHOW_TIMES]) + more


def report(wanted: dict, fitted: dict, m: dict | None = None, timeline: list | None = None) -> dict:
    """wanted: the spec as written; fitted: after sync.fit_to_music (or the same spec without
    music); m: the music map; timeline: fit_to_music's report."""
    ivs = _intervals(fitted)
    issues = []

    run, start = 0, 0
    for t, i in ivs + [(0, {"sec": 0})]:
        if i.get("standing"):
            start, run = (start, run + i["sec"]) if run else (t, i["sec"])
            continue
        if run > MAX_STANDING_SEC:
            issues.append(f"standing for {run} s from {mmss(start)}; official rides rarely stand "
                          f"past {MAX_STANDING_SEC} s, so alternate with seated")
        run = 0
    low, high = STANDING_RPM
    off = [t for t, i in ivs if i.get("standing") and _rpm(i) and not low <= _rpm(i) <= high]
    if off:
        issues.append(f"standing outside {low}-{high} rpm at {_at(off)}")

    best, cur = (0, 0, 0), (0, 0, 0)  # (seconds, zone, from)
    for t, i in ivs:
        cur = (cur[0] + i["sec"], i["zone"], cur[2]) if cur[1] == i["zone"] else (i["sec"], i["zone"], t)
        best = max(best, cur)
    if best[0] > MAX_ZONE_RUN_SEC:
        issues.append(f"zone {best[1]} for {best[0]} s from {mmss(best[2])}; official rides hold one zone "
                      f"for at most about {MAX_ZONE_RUN_SEC} s")
    out = {"longest_zone_run": {"zone": best[1], "sec": best[0], "from": mmss(best[2])}}

    if timeline:
        on = [r["on"] for r in timeline[1:]]
        out["changes_on_music"] = f"{sum(o != 'unsnapped' for o in on)} of {len(on)}"
    if m:
        beat = [i.get("rpm") == "beat" for _, i in _intervals(wanted)]
        jumps, off_beat, prev = [], [], None
        for n, (t, i) in enumerate(ivs):
            song = music.song_at(m, t + i["sec"] / 2)
            key, rpm = song.get("track", song["song"]), _rpm(i)
            if rpm and prev and prev[0] == key and abs(rpm - prev[1]) > CADENCE_JUMP_RPM:
                jumps.append(t)
            if rpm:
                prev = (key, rpm)
            if rpm and n < len(beat) and beat[n] and not any(
                    abs(rpm - x) <= 1 for x in (song["bpm"], song["bpm"] / 2, song["bpm"] * 2)):
                off_beat.append(t)
        if jumps:
            issues.append(f"cadence changes by more than {CADENCE_JUMP_RPM} rpm inside a song at {_at(jumps)}; "
                          "official rides keep one cadence per song")
        if off_beat:
            issues.append(f'"beat" cadence is off the beat at {_at(off_beat)}: no full, half or double '
                          "BPM suits that effort, so it uses a typical cadence instead")
    out["issues"] = issues
    return out
