"""The one error type the package raises for expected failures."""


class MowlError(RuntimeError):
    pass
