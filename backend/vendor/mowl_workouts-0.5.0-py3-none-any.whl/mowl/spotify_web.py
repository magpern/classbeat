"""Spotify Web API: find songs and build playlists for a class.

Sign-in is the Authorization Code flow with PKCE (no client secret): the user approves
once in their own browser. The client ID, access token and refresh token live in the
caller's `Credentials`; this module reads and writes no files (a renewed token is passed to
`creds.on_spotify_token`).
Spotify's Development Mode limits apply: search returns at most 10 results per call,
and BPM / audio features are not available to new apps; MOWL supplies those instead.
"""
import base64
import hashlib
import http.server
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from .credentials import Credentials
from .errors import MowlError

ACCOUNTS = "https://accounts.spotify.com/"
API = "https://api.spotify.com/v1/"
SCOPES = "playlist-read-private playlist-modify-private playlist-modify-public"
SEARCH_LIMIT = 10  # Development Mode maximum
SPOTIFY_ID = re.compile(r"[0-9A-Za-z]{22}")
VERSION_WORDS = re.compile(r"\b(live|karaoke|instrumental|cover|tribute|re-?recorded|acoustic|demo|8-bit)\b", re.I)


def _post_form(url: str, form: dict) -> dict:
    req = urllib.request.Request(url, data=urllib.parse.urlencode(form).encode(), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        raise MowlError(f"Spotify sign-in failed: HTTP {e.code} {e.read()[:200]!r}") from e


def _with_expiry(tok: dict) -> dict:
    return {**tok, "expires_at": time.time() + tok.get("expires_in", 3600) - 60}


def connect(creds: Credentials, timeout: float = 300, open_browser=webbrowser.open) -> dict:
    """Open Spotify's consent page in the user's browser and wait for them to approve. The
    page is also served at /start on the callback address, for a tab to be sent on to it.
    The new tokens are set on `creds` (and passed to its on_spotify_token). Needs
    creds.spotify_client_id. Returns who signed in; never a token."""
    if not creds.spotify_client_id:
        raise MowlError("No Spotify app configured; set the Client ID first (mowl connect spotify)")
    redirect = urllib.parse.urlparse(creds.spotify_redirect_uri)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    result = {}

    class Callback(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if self.path == "/start":
                self.send_response(302)
                self.send_header("Location", url)
                self.end_headers()
                return
            if urllib.parse.urlparse(self.path).path != redirect.path:
                self.send_response(404)
                self.end_headers()
                return
            if q.get("state", [""])[0] == state:
                result.update({k: v[0] for k, v in q.items()})
            ok = "code" in result
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(("Spotify is connected; you can close this tab." if ok
                              else "Spotify was not connected.").encode())

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer((redirect.hostname, redirect.port), Callback)
    server.timeout = 1
    url = ACCOUNTS + "authorize?" + urllib.parse.urlencode({
        "client_id": creds.spotify_client_id, "response_type": "code", "redirect_uri": creds.spotify_redirect_uri,
        "code_challenge_method": "S256", "code_challenge": challenge, "scope": SCOPES, "state": state})
    threading.Thread(target=open_browser, args=(url,), daemon=True).start()
    deadline = time.monotonic() + timeout
    try:
        while "code" not in result and "error" not in result and time.monotonic() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if "code" not in result:
        raise MowlError(f"Spotify was not connected ({result.get('error', 'no answer in time')}); "
                        f"open this page to try again: {url}")
    tok = _post_form(ACCOUNTS + "api/token", {
        "grant_type": "authorization_code", "code": result["code"], "redirect_uri": creds.spotify_redirect_uri,
        "client_id": creds.spotify_client_id, "code_verifier": verifier})
    creds.set_spotify_tokens(_with_expiry(tok))
    me = call(creds, "GET", "me")
    return {"connected_as": me.get("display_name") or me.get("id"), "product": me.get("product")}


def _access_token(creds: Credentials) -> str:
    with creds.lock:  # one refresh at a time per user; other users' credentials are unaffected
        if not creds.spotify_access_token and not creds.spotify_refresh_token:
            raise MowlError("Spotify is not connected yet; run connect_spotify first")
        if creds.spotify_access_token and time.time() < creds.spotify_expires_at:
            return creds.spotify_access_token
        if not creds.spotify_refresh_token or not creds.spotify_client_id:
            raise MowlError("Spotify sign-in expired; run connect_spotify again")
        new = _post_form(ACCOUNTS + "api/token", {"grant_type": "refresh_token",
                                                   "refresh_token": creds.spotify_refresh_token,
                                                   "client_id": creds.spotify_client_id})
        creds.set_spotify_tokens(_with_expiry(new))  # Spotify may or may not rotate the refresh token
        return creds.spotify_access_token


def call(creds: Credentials, method: str, path: str, params: dict | None = None, body=None):
    url = API + path + ("?" + urllib.parse.urlencode(params) if params else "")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {_access_token(creds)}", "Content-Type": "application/json"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < 2:  # rate limited: wait as told
                time.sleep(min(30, int(e.headers.get("Retry-After", "2"))))
                continue
            raise MowlError(f"Spotify {method} {path}: HTTP {e.code} {e.read()[:200]!r}") from e


# --- songs ------------------------------------------------------------------------

def _track(t: dict) -> dict:
    return {"uri": t["uri"], "id": t["id"], "title": t["name"],
            "artists": [a["name"] for a in t.get("artists", [])], "album": t.get("album", {}).get("name"),
            "year": (t.get("album", {}).get("release_date") or "")[:4], "sec": round(t["duration_ms"] / 1000)}


def search_tracks(creds: Credentials, query: str, limit: int = SEARCH_LIMIT) -> list:
    data = call(creds, "GET", "search", {"q": query, "type": "track", "limit": min(limit, SEARCH_LIMIT)})
    return [_track(t) for t in data.get("tracks", {}).get("items", [])]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def best_match(wanted_artist: str, wanted_title: str, candidates: list) -> dict | None:
    """The candidate by the wanted artist whose title matches best, avoiding live, karaoke,
    cover and similar versions unless the wanted title asks for one."""
    artist, title = _norm(wanted_artist), _norm(wanted_title)

    def score(c):
        if not any(artist in _norm(a) or _norm(a) in artist for a in c["artists"]):
            return None
        t = _norm(c["title"])
        s = 3 if t == title else 2 if t.startswith(title) else 1 if title in t else 0
        if not s:
            return None
        if VERSION_WORDS.search(c["title"]) and not VERSION_WORDS.search(wanted_title):
            s -= 2.5
        if "remaster" in t:
            s -= 0.1  # fine, but prefer the original release when both exist
        return s
    scored = [(score(c), n, c) for n, c in enumerate(candidates)]
    scored = [x for x in scored if x[0] is not None and x[0] > 0]
    return max(scored, key=lambda x: (x[0], -x[1]))[2] if scored else None


def find_songs(creds: Credentials, songs: list, years: str = "") -> dict:
    """Resolve [{"artist", "title"}] to Spotify tracks. years like "1990-1999" narrows the search,
    falling back to an unrestricted search when the song was re-released later."""
    found, missing = [], []
    for s in songs:
        base = f'track:"{s["title"]}" artist:"{s["artist"]}"'
        hit = None
        for q in ([f"{base} year:{years}"] if years else []) + [base, f'{s["artist"]} {s["title"]}']:
            hit = best_match(s["artist"], s["title"], search_tracks(creds, q))
            if hit:
                break
        if hit:
            found.append({**{k: v for k, v in s.items() if k not in ("artist", "title")}, **hit,
                          "wanted": f'{s["artist"]} - {s["title"]}'})
        else:
            missing.append(s)
    return {"found": found, "missing": missing}


# --- playlists --------------------------------------------------------------------

def my_playlists(creds: Credentials) -> list:
    out, offset = [], 0
    while True:
        page = call(creds, "GET", "me/playlists", {"limit": 50, "offset": offset})
        out += page.get("items", [])
        if not page.get("next"):
            return out
        offset += 50


def playlist_tracks(creds: Credentials, playlist_id: str) -> list:
    """Every track of a Spotify playlist, in order, as _track dicts."""
    out, offset = [], 0
    fields = "items(track(name,id,uri,duration_ms,artists(name),album(name,release_date))),next"
    while True:
        page = call(creds, "GET", f"playlists/{playlist_id}/tracks", {"limit": 100, "offset": offset, "fields": fields})
        out += [_track(it["track"]) for it in page.get("items", []) if it.get("track")]
        if not page.get("next"):
            return out
        offset += 100


def find_playlist_tracks(creds: Credentials, playlist: str) -> list:
    """Tracks of a Spotify playlist given by 22-char ID or by the name of the user's own playlist."""
    pid = str(playlist).strip()
    if not SPOTIFY_ID.fullmatch(pid):
        match = next((p for p in my_playlists(creds) if p["name"].lower() == pid.lower()), None)
        if not match:
            raise MowlError(f"no Spotify playlist named {playlist!r}")
        pid = match["id"]
    return playlist_tracks(creds, pid)


def _check_id(playlist_id: str) -> str:
    if not isinstance(playlist_id, str) or not SPOTIFY_ID.fullmatch(playlist_id):
        raise MowlError(f"not a Spotify playlist ID: {playlist_id!r}")
    return playlist_id


def _add_items(creds: Credentials, playlist_id: str, uris: list) -> None:
    for i in range(0, len(uris), 100):  # the API takes at most 100 per call
        call(creds, "POST", f"playlists/{playlist_id}/items", body={"uris": uris[i:i + 100]})


def _create(creds: Credentials, name: str, uris: list, description: str, public: bool) -> str:
    pid = call(creds, "POST", "me/playlists", body={
        "name": name, "description": description, "public": public, "collaborative": False})["id"]
    _add_items(creds, pid, uris)
    return pid


def create_playlist(creds: Credentials, name: str, uris: list, description: str = "") -> str:
    """Create a new private, non-collaborative playlist holding the tracks in this order and
    return its ID. Always new: it never looks at existing playlists, so it is safe for a
    server that must not touch a playlist it did not create."""
    return _create(creds, name, uris, description, public=False)


def replace_playlist_items(creds: Credentials, playlist_id: str, uris: list) -> None:
    """Replace every track of the playlist with exactly this ID by `uris`, in order."""
    pid = _check_id(playlist_id)
    call(creds, "PUT", f"playlists/{pid}/items", body={"uris": uris[:100]})
    _add_items(creds, pid, uris[100:])


def save_playlist(creds: Credentials, name: str, uris: list, description: str = "", public: bool = False) -> dict:
    """Name-based helper for the CLI and the local MCP server only: replace the songs of the
    user's own playlist with that name, or create it, so re-running a design reuses one playlist
    instead of piling up new ones. Hosted apps should store IDs and use create_playlist and
    replace_playlist_items instead."""
    me = call(creds, "GET", "me")["id"]
    existing = next((p for p in my_playlists(creds) if p["name"] == name and p["owner"]["id"] == me), None)
    if existing:
        pid = existing["id"]
        replace_playlist_items(creds, pid, uris)
    else:
        pid = _create(creds, name, uris, description, public)
    return {"spotify_id": pid, "name": name, "tracks": len(uris), "replaced": bool(existing)}
