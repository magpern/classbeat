"""Fit a workout spec to a music map: every change on beat 1, cadence from the BPM.

Each interval change is moved to the nearest drop or breakdown within `tolerance`
seconds, otherwise to the nearest bar start (beat 1). Times are then rounded to whole
seconds, because MOWL stores interval lengths in whole seconds, so each change lands
within half a second of the beat without the error adding up.
"""
import copy

from . import music
from .workout import MIN_COOLDOWN_SEC, mmss

MIN_INTERVAL = 5  # s; never squeeze an interval shorter than this when snapping
# (lowest, highest, preferred) cadence riding on the beat, per kind of effort
SPRINT_RPM = (95, 125, 105)
STANDING_RPM = (55, 88, 70)
SEATED_HARD_RPM = (62, 100, 80)  # seated zone 4+: tempo, threshold or a seated climb
SEATED_RPM = (75, 108, 90)


def _candidates(m: dict, t: float, window: float) -> list:
    """Bar starts near t, from every song whose edge zone covers t."""
    out = []
    for s in m["songs"]:
        if s["start"] - music.EDGE <= t <= s["end"] + music.EDGE:
            out += [(x, "bar", s["bpm"]) for x in music.grid_points(s, 4, s["first_downbeat"], t - window, t + window)]
    return out


def _snap_one(m, t, lo, hi, tolerance):
    """Best beat-1 time for a change wanted at t, strictly inside (lo, hi)."""
    events = [(e["t"], e["kind"], music.song_at(m, e["t"])["bpm"]) for e in m["events"]
              if abs(e["t"] - t) <= tolerance and lo < e["t"] < hi]
    if events:
        return min(events, key=lambda e: abs(e[0] - t))
    bars = [c for c in _candidates(m, t, 8.0) if lo < c[0] < hi]
    if bars:
        return min(bars, key=lambda c: abs(c[0] - t))
    return (t, "unsnapped", music.song_at(m, t)["bpm"])


def cadence(bpm: float, interval: dict) -> list:
    """rpm range riding on the beat: the BPM, half or double it, whichever in the effort's
    range is closest to its preferred cadence; otherwise a range around that cadence."""
    if interval.get("acc"):
        lo, hi, want = SPRINT_RPM
    elif interval.get("standing"):
        lo, hi, want = STANDING_RPM
    elif interval["zone"] >= 4:
        lo, hi, want = SEATED_HARD_RPM
    else:
        lo, hi, want = SEATED_RPM
    fits = [c for c in (bpm, bpm / 2, bpm * 2) if lo <= c <= hi]
    if fits:
        c = round(min(fits, key=lambda c: abs(c - want)))
        return [c - 2, c + 2]
    return [want - 5, want + 5]


def fit_to_music(spec: dict, m: dict, tolerance: float = 6.0) -> tuple[dict, list]:
    """Return (snapped spec, timeline report). The spec's interval lengths are treated as
    the wanted lengths; options come from spec["music"]: "fit" stretches the whole workout
    to the length of the mix first."""
    spec = copy.deepcopy(spec)
    opts = spec.get("music") or {}
    ivs = [i for s in spec["segments"] for i in s["intervals"]]
    starts, t = [], 0.0
    for i in ivs:
        starts.append(t)
        t += float(i["sec"])
    total = t
    if opts.get("fit", False) and total > 0:
        scale = int(m["duration"]) / total
        starts = [x * scale for x in starts]
        total = float(int(m["duration"]))
    first_cooldown = sum(len(s["intervals"]) for s in spec["segments"][:-1])
    snapped = [(0.0, "start", music.song_at(m, 0.0)["bpm"])]
    for n in range(1, len(ivs)):
        lo = snapped[-1][0] + MIN_INTERVAL
        if n <= first_cooldown:
            # leave room for the remaining intervals and a full-length cooldown
            hi = total - MIN_COOLDOWN_SEC - 0.5 - (first_cooldown - n) * MIN_INTERVAL
        else:
            hi = total - (len(ivs) - n) * MIN_INTERVAL
        want = min(max(starts[n], lo), hi)
        snapped.append(_snap_one(m, want, lo, hi, tolerance))
    cuts = [round(x[0]) for x in snapped] + [round(total)]
    for n in range(1, len(cuts)):
        cuts[n] = max(cuts[n], cuts[n - 1] + 1)
    report = []
    for n, i in enumerate(ivs):
        i["sec"] = cuts[n + 1] - cuts[n]
        if i.get("rpm") == "beat":
            mid = (snapped[n][0] + (snapped[n + 1][0] if n + 1 < len(snapped) else total)) / 2
            i["rpm"] = cadence(music.song_at(m, mid)["bpm"], i)
        exact, what, bpm = snapped[n]
        row = {"start": mmss(cuts[n]), "on": what, "beat_at": mmss(exact),
               "moved": round(exact - starts[n], 1), "bpm": round(bpm, 1), "zone": i["zone"], "sec": i["sec"]}
        if what == "bar":
            # Drops and breakdowns are found directly; a plain bar start relies on the song's
            # beat-1 vote, so say how clear that vote was (1.0 = a coin toss).
            row["beat1_margin"] = music.song_at(m, exact).get("beat1_margin")
        report.append(row)
    return spec, report
