"""Command line for the same actions as the MCP server.

  mowl connect [mowl|spotify|swedebeat]   sign in on a page in your browser (default mowl)
  mowl status                      which accounts are connected
  mowl disconnect <service>        forget a service's token on this computer
  mowl login [email]               sign in to MOWL here in the terminal instead
  mowl workouts                    list My Workouts
  mowl show <program_id>           one workout
  mowl mixes [filter]              list Swedebeat mixes
  mowl analyze <mix> [--refresh]   music map of a mix
  mowl beat1 <mix> <song> <beats>  move a song's beat 1 by whole beats (after listening)
  mowl spotify [filter]            list Spotify playlists
  mowl spotify-map <playlist> [--refresh]
  mowl preview <spec.json>         check a spec and show the music timeline
  mowl create <spec.json>          save a new workout
  mowl update <program_id> <spec.json>
  mowl corpus-categories           read-only: the program category IDs the app lists
  mowl corpus-fetch --categories 12,14 [--delay 3] [--limit N] [--dir D]
                                   read-only, slow, resumable: cache library programs on this computer
  mowl corpus-analyze [--dir D] [--out O] [--min-group 3]
                                   offline: write aggregate statistics only (no titles or names)
  mowl swedebeat-login [email] [--force]   log in to Swedebeat (asks for the password here)
  mowl swedebeat-match <spotify playlist>  match a Spotify list to the Swedebeat catalogue
"""
import getpass
import json
import sys

from . import api, connect, local, server, service, spotify_web, swedebeat
from .errors import MowlError


def _mowl_login(args: list) -> dict:
    email = next((a for a in args if not a.startswith("-")), "") or input("MOWL email: ").strip()
    password = getpass.getpass("MOWL password (not shown, not stored): ")
    if not password:
        raise MowlError("no password entered")
    local.save_mowl_token(api.login(email, password))
    return {"signed_in": True, "token_saved_to": local.TOKEN_FILE}


def _swedebeat_login(args: list) -> dict:
    email = next((a for a in args if not a.startswith("-")), "") or input("Swedebeat email: ").strip()
    password = getpass.getpass("Swedebeat password (not shown, not stored): ")
    if not password:
        raise MowlError("no password entered")
    creds = local.load_credentials()
    session = swedebeat.login(creds, email, password, force="--force" in args)
    local.save_swedebeat_session(creds, session)
    return {"connected_as": session["connected_as"], "brand": session["brand"]}


def _opt(args: list, name: str, default=None):
    return args[args.index(name) + 1] if name in args and args.index(name) + 1 < len(args) else default


def _corpus_fetch(args: list) -> dict:
    categories = _opt(args, "--categories")
    if not categories:
        raise MowlError("give --categories, for example --categories 12,14 or 1-40 "
                        "(`mowl corpus-categories` lists them)")
    limit = _opt(args, "--limit")
    store = local.FileCorpusStore(_opt(args, "--dir"))
    return service.corpus_fetch(
        local.load_credentials(), store, categories, delay=max(1.0, float(_opt(args, "--delay", 3))),
        limit=int(limit) if limit else None, progress=lambda msg: print(msg, file=sys.stderr))


def _load(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd, args = argv[0], argv[1:]
    creds = local.load_credentials  # read ~/.mowl only for the command that runs
    try:
        out = {
            "connect": lambda: connect.connect(args[0] if args else "mowl"),
            "status": connect.status,
            "disconnect": lambda: connect.disconnect(args[0]),
            "login": lambda: _mowl_login(args),
            "workouts": lambda: server.list_workouts(),
            "show": lambda: server.get_workout(int(args[0])),
            "mixes": lambda: server.list_swedebeat_mixes(args[0] if args else ""),
            "analyze": lambda: server.analyze_swedebeat_mix(args[0], refresh="--refresh" in args),
            "beat1": lambda: server.correct_beat_one(args[0], int(args[1]), int(args[2])),
            "spotify": lambda: server.list_spotify_playlists(args[0] if args else ""),
            "spotify-map": lambda: server.analyze_spotify_playlist(args[0], refresh="--refresh" in args),
            "preview": lambda: server.preview_workout(_load(args[0])),
            "create": lambda: server.create_workout(_load(args[0])),
            "update": lambda: server.update_workout(int(args[0]), _load(args[1])),
            "corpus-categories": lambda: service.corpus_categories(creds()),
            "corpus-fetch": lambda: _corpus_fetch(args),
            "corpus-analyze": lambda: service.corpus_analyze(
                local.FileCorpusStore(_opt(args, "--dir")), _opt(args, "--out"), int(_opt(args, "--min-group", 3))),
            "swedebeat-login": lambda: _swedebeat_login(args),
            "swedebeat-match": lambda: swedebeat.match_tracks(creds(), spotify_web.find_playlist_tracks(creds(), args[0])),
        }[cmd]()
    except KeyError:
        print(f"unknown command {cmd!r}\n{__doc__}", file=sys.stderr)
        return 2
    except (MowlError, ValueError, IndexError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    sys.stdout.reconfigure(encoding="utf-8")  # track titles; the Windows console default is not UTF-8
    print(json.dumps(out, indent=1, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
