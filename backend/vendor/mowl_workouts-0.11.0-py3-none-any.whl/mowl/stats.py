"""Aggregate statistics over cached library programs; offline, no network, no credentials.

The output holds numbers and a fixed vocabulary only: the sport, a numeric category ID and a
duration bucket. A program's name, descriptions, segment names, instructor and brand never
enter a metric, and `check_aggregate` refuses any key or text outside the vocabulary before
anything is returned, so a leak fails loudly instead of being published.
"""
import math
import statistics
from collections import defaultdict
from typing import Iterable

HARD_ZONE = 4  # zone 4 and above counts as work
REST_ZONE = 2  # zone 2 and below counts as rest
CLIMB_RPM = 80  # a seated zone 3+ interval at or under this cadence reads as a climb
MIN_GROUP = 3  # a group of fewer programs is not published: it would describe one class
SCHEMA = 1

ZONES = range(1, 8)
FIFTHS = range(1, 6)
METRICS = tuple(
    ["total_min", "tss", "intensity_factor", "warmup_min", "warmup_max_zone", "cooldown_min", "segments",
     "intervals", "interval_sec_median", "interval_sec_max", "first_hard_min", "max_zone", "hardest_pos_pct",
     "work_pct", "rest_pct", "work_rest_ratio", "pair_work_rest_ratio", "zone_step_one_pct",
     "off_5s_pct", "standing_pct", "standing_in_z12_pct", "acc_count", "acc_sec_median", "acc_pct",
     "climb_pct", "game_share", "ftp_test_share", "incline_pct", "incline_changes", "incline_sec_median"]
    + [f"z{z}_pct" for z in ZONES] + [f"hard_pct_fifth_{n}" for n in FIFTHS]
    + [f"incline_pct_z{z}" for z in range(1, 6)])
SUMMARY = ("n", "min", "p5", "p25", "median", "p75", "p95", "max")
_KEYS = frozenset(METRICS) | frozenset(SUMMARY) | {
    "schema", "programs_analyzed", "programs_skipped", "min_group_size", "small_groups_omitted", "groups",
    "tss_vs_duration", "sport", "category", "duration_min", "programs", "metrics", "slope_per_min",
    "intercept", "r", "cycling", "running", "unknown"}
_STRINGS = frozenset({"cycling", "running", "unknown", "all"})


def check_aggregate(obj, path: str = "") -> None:
    """Raise unless obj is built only from the vocabulary above: known keys, numbers, None, the
    sport names and "all". The guard against publishing a title, a description or a name."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k not in _KEYS:
                raise ValueError(f"unexpected key in the statistics at {path or '/'}: {str(k)[:20]!r}")
            check_aggregate(v, f"{path}/{k}")
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            check_aggregate(v, path)
    elif isinstance(obj, str):
        if obj not in _STRINGS:
            raise ValueError(f"unexpected text in the statistics at {path or '/'}")
    elif not (obj is None or isinstance(obj, (bool, int, float))):
        raise ValueError(f"unexpected value in the statistics at {path or '/'}")


def _num(value) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(value) if isinstance(value, str) else None
    except ValueError:
        return None


def _sport(program: dict) -> str:
    value = program.get("ActivityTypeID")
    return "cycling" if value is None else {0: "cycling", 1: "running"}.get(value, "unknown") \
        if type(value) is int else "unknown"


def _intervals(program: dict) -> list[dict]:
    out = []
    for s in program.get("Segments") or []:
        kind = ("warmup" if s.get("IsWarmup") else "cooldown" if s.get("IsCooldown")
                else "recovery" if s.get("IsActiveRecovery") else "main")
        for i in s.get("Intervals") or []:
            sec, zone = _num(i.get("Duration")), _num(i.get("ScaleCoggan"))
            if not sec or sec <= 0 or zone is None or int(zone) not in ZONES:
                continue
            out.append({"sec": sec, "zone": int(zone), "kind": kind, "standing": i.get("PositionTypeID") == 2,
                        "acc": i.get("CycleID") == 4, "rpm_to": _num(i.get("RPMTo")) or 0.0,
                        "gradient": _num(i.get("Gradient")) or 0.0, "game": bool(i.get("IntervalGame")),
                        "ftp": bool(i.get("FtpTest"))})
    return out


def _pct(part: float, whole: float) -> float | None:
    return round(100 * part / whole, 2) if whole > 0 else None


def _med(values: list[float]) -> float | None:
    return statistics.median(values) if values else None


def program_metrics(program: dict) -> dict | None:
    """Numbers for one program, or None when it has no usable intervals."""
    ivs = _intervals(program)
    total = sum(i["sec"] for i in ivs)
    if not ivs or total <= 0:
        return None
    m: dict = {"total_min": total / 60, "segments": len(program.get("Segments") or []), "intervals": len(ivs)}
    tss = _num(program.get("TSS"))
    if tss and tss > 0:
        m["tss"] = tss
        m["intensity_factor"] = math.sqrt(tss / (total / 3600 * 100))
    warm = [i for i in ivs if i["kind"] == "warmup"]
    cool = [i for i in ivs if i["kind"] == "cooldown"]
    m["warmup_min"] = sum(i["sec"] for i in warm) / 60 if warm else None
    m["warmup_max_zone"] = max((i["zone"] for i in warm), default=None)
    m["cooldown_min"] = sum(i["sec"] for i in cool) / 60 if cool else None
    secs = [i["sec"] for i in ivs]
    m["interval_sec_median"], m["interval_sec_max"] = statistics.median(secs), max(secs)
    m["off_5s_pct"] = _pct(sum(1 for s in secs if s % 5), len(secs))
    start = 0.0
    for i in ivs:
        i["start"] = start
        start += i["sec"]
    hard = [i for i in ivs if i["zone"] >= HARD_ZONE]
    m["first_hard_min"] = hard[0]["start"] / 60 if hard else None
    top = max(i["zone"] for i in ivs)
    m["max_zone"] = top
    m["hardest_pos_pct"] = _pct(next(i for i in ivs if i["zone"] == top)["start"], total)
    for z in ZONES:
        m[f"z{z}_pct"] = _pct(sum(i["sec"] for i in ivs if i["zone"] == z), total)
    for n in FIFTHS:  # share of each fifth of the class spent in the hard zones
        lo, hi = total * (n - 1) / 5, total * n / 5
        inside = [(min(i["start"] + i["sec"], hi) - max(i["start"], lo), i) for i in ivs
                  if i["start"] < hi and i["start"] + i["sec"] > lo]
        m[f"hard_pct_fifth_{n}"] = _pct(sum(s for s, i in inside if i["zone"] >= HARD_ZONE), hi - lo)
    body = [i for i in ivs if i["kind"] not in ("warmup", "cooldown")]
    work = sum(i["sec"] for i in body if i["zone"] >= HARD_ZONE)
    rest = sum(i["sec"] for i in body if i["zone"] <= REST_ZONE)
    bsum = sum(i["sec"] for i in body)
    m["work_pct"], m["rest_pct"] = _pct(work, bsum), _pct(rest, bsum)
    m["work_rest_ratio"] = round(work / rest, 3) if rest else None
    pairs = [a["sec"] / b["sec"] for a, b in zip(body, body[1:])
             if a["zone"] >= HARD_ZONE and b["zone"] <= REST_ZONE]
    m["pair_work_rest_ratio"] = _med(pairs)
    steps = [abs(b["zone"] - a["zone"]) for a, b in zip(ivs, ivs[1:]) if a["zone"] != b["zone"]]
    m["zone_step_one_pct"] = _pct(sum(1 for s in steps if s == 1), len(steps))
    stand = [i for i in ivs if i["standing"]]
    m["standing_pct"] = _pct(sum(i["sec"] for i in stand), total)
    m["standing_in_z12_pct"] = _pct(sum(i["sec"] for i in stand if i["zone"] <= 2), sum(i["sec"] for i in stand))
    acc = [i for i in ivs if i["acc"]]
    m["acc_count"], m["acc_sec_median"] = len(acc), _med([i["sec"] for i in acc])
    m["acc_pct"] = _pct(sum(i["sec"] for i in acc), total)
    climb = sum(i["sec"] for i in ivs if not i["standing"] and i["zone"] >= 3 and 0 < i["rpm_to"] <= CLIMB_RPM)
    m["climb_pct"] = _pct(climb, total)
    m["game_share"] = 1.0 if any(i["game"] for i in ivs) else 0.0
    m["ftp_test_share"] = 1.0 if any(i["ftp"] for i in ivs) else 0.0
    if _sport(program) == "running":  # the treadmill incline
        inc = [i for i in ivs if i["gradient"] > 0]
        m["incline_pct"] = _pct(sum(i["sec"] for i in inc), total)
        m["incline_changes"] = sum(1 for a, b in zip(ivs, ivs[1:]) if a["gradient"] != b["gradient"])
        m["incline_sec_median"] = _med([i["sec"] for i in inc])
        for z in range(1, 6):
            m[f"incline_pct_z{z}"] = _pct(sum(i["sec"] for i in inc if i["zone"] == z),
                                          sum(i["sec"] for i in ivs if i["zone"] == z))
    return {k: (round(v, 2) if isinstance(v, float) else v) for k, v in m.items()}


def bucket(total_min: float) -> int:
    """The class length it was sold as: the timeline runs a few minutes short, so round up to 5."""
    return max(5, int(math.ceil(total_min / 5 - 1e-9)) * 5)


def summarize(values: list[float]) -> dict | None:
    """n, min, p5, p25, median, p75, p95, max. Percentiles interpolate linearly between the two
    nearest ranks (rank (n-1)*p, NumPy's default). For tiny n they stay inside [min, max]: n=1
    gives that value everywhere, and p5/p95 of n<20 lie between the two lowest/highest values,
    so classbeat uses min/max instead of p5/p95 under n=25 (ADR 0017)."""
    v = sorted(x for x in values if x is not None)
    if not v:
        return None

    def q(p: float) -> float:
        k = (len(v) - 1) * p
        lo, hi = math.floor(k), math.ceil(k)
        return round(v[lo] + (v[hi] - v[lo]) * (k - lo), 2)
    return {"n": len(v), "min": round(v[0], 2), "p5": q(.05), "p25": q(.25),
            "median": q(.5), "p75": q(.75), "p95": q(.95), "max": round(v[-1], 2)}


def _fit(points: list[tuple[float, float]]) -> dict | None:
    if len(points) < MIN_GROUP:
        return None
    xs, ys = [p[0] for p in points], [p[1] for p in points]
    mx, my = statistics.fmean(xs), statistics.fmean(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in points)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx == 0:
        return None
    return {"n": len(points), "slope_per_min": round(sxy / sxx, 3), "intercept": round(my - sxy / sxx * mx, 2),
            "r": round(sxy / math.sqrt(sxx * syy), 3) if syy else None}


def analyze(programs: Iterable[tuple[int, dict]], min_group: int = MIN_GROUP) -> dict:
    """(category, program) pairs -> statistics per sport, category and duration, and for each
    sport over all categories ("all"). Groups under min_group programs are counted, not shown."""
    rows, skipped = [], 0
    for category, program in programs:
        m = program_metrics(program)
        if m is None:
            skipped += 1
            continue
        rows.append((_sport(program), int(category), bucket(m["total_min"]), m))
    grouped: dict[tuple, list[dict]] = defaultdict(list)
    for sport, cat, dur, m in rows:
        for key in ((sport, cat, dur), (sport, "all", dur)):
            grouped[key].append(m)
    groups, omitted = [], 0
    for (sport, cat, dur), ms in sorted(grouped.items(), key=lambda kv: (kv[0][0], str(kv[0][1] != "all"),
                                                                         str(kv[0][1]).zfill(5), kv[0][2])):
        if len(ms) < min_group:
            omitted += 1
            continue
        metrics = {k: s for k in METRICS if (s := summarize([m.get(k) for m in ms]))}
        groups.append({"sport": sport, "category": cat, "duration_min": dur, "programs": len(ms), "metrics": metrics})
    fits = {}
    for sport in sorted({r[0] for r in rows}):
        fit = _fit([(m["total_min"], m["tss"]) for s, _, _, m in rows if s == sport and "tss" in m])
        if fit:
            fits[sport] = fit
    out = {"schema": SCHEMA, "programs_analyzed": len(rows), "programs_skipped": skipped,
           "min_group_size": min_group, "small_groups_omitted": omitted, "groups": groups, "tss_vs_duration": fits}
    check_aggregate(out)
    return out


def to_markdown(stats: dict) -> str:
    """The same numbers as tables: median (p25-p75) per metric. Built from the checked dict only."""
    check_aggregate(stats)
    lines = ["# Class pattern statistics", "",
             f"{stats['programs_analyzed']} programs analysed, {stats['programs_skipped']} skipped, "
             f"{stats['small_groups_omitted']} groups under {stats['min_group_size']} programs not shown. "
             "Numbers are median (p25-p75), then p5, p95, min and max. Category is the library's numeric ID.", ""]
    for sport, fit in stats["tss_vs_duration"].items():
        lines.append(f"- {sport} TSS = {fit['slope_per_min']} x minutes + {fit['intercept']} "
                     f"(r {fit['r']}, n {fit['n']})")
    for g in stats["groups"]:
        lines += ["", f"## {g['sport']}, category {g['category']}, {g['duration_min']} min ({g['programs']} programs)",
                  "", "| metric | median | p25-p75 | p5 | p95 | min | max | n |", "|---|---|---|---|---|---|---|---|"]
        lines += [f"| {k} | {s['median']} | {s['p25']}-{s['p75']} | {s['p5']} | {s['p95']} "
                  f"| {s['min']} | {s['max']} | {s['n']} |" for k, s in g["metrics"].items()]
    return "\n".join(lines) + "\n"
