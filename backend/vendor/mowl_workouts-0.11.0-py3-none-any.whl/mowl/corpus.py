"""Read a library of programs from MOWL, slowly and read-only, into a local cache.

Only reads: `POST v1/programs` (a list page) and `GET v1/programs/{id}`. Nothing here creates,
updates or deletes anything. The cache is passed in as a `CorpusStore` (local.FileCorpusStore
on the owner's disk), so this module touches no files and prints nothing; it returns counts
only, never a title. Re-running resumes: a program already cached is not requested again.
"""
import time
from typing import Callable, Iterator, Protocol

from . import api
from .credentials import Credentials
from .errors import MowlError

MY_WORKOUTS_CATEGORY = api.MY_WORKOUTS  # the user's own workouts are never part of the library
DEFAULT_DELAY = 3.0  # seconds between requests
MAX_CATEGORY_ID = 100_000  # the real library's category IDs are in the 8000s (v1/ProgramCategories)
MAX_RANGE = 200  # IDs in one 'a-b' range: each empty ID costs a request, so a typo cannot run away
RETRY_WAITS = (30, 60, 120)  # for 5xx and network errors; a 429 waits as long as it asks


class CorpusStore(Protocol):
    def known_ids(self) -> set[int]: ...
    def put_program(self, category: int, program_id: int, program: dict) -> None: ...
    def programs(self) -> Iterator[tuple[int, dict]]: ...


class Stop(Exception):
    """The run cannot go on (token rejected, repeated failures); what is cached is kept."""


def parse_categories(text: str) -> list[int]:
    """'12,14' or '1-40' or a mix -> category IDs, without 17 (My Workouts), in order."""
    out: list[int] = []
    for part in str(text).split(","):
        part = part.strip()
        if not part:
            continue
        try:
            lo, _, hi = part.partition("-")
            ids = range(int(lo), int(hi or lo) + 1)
        except ValueError:
            raise ValueError(f"not a category list: {part!r}") from None
        if not ids or ids[0] < 1 or ids[-1] > MAX_CATEGORY_ID or len(ids) > MAX_RANGE:
            raise ValueError(f"category IDs must be 1-{MAX_CATEGORY_ID}, at most {MAX_RANGE} in a range: {part!r}")
        out += [i for i in ids if i != MY_WORKOUTS_CATEGORY and i not in out]
    if not out:
        raise ValueError("no categories given")
    return out


def _read(fn: Callable, sleep: Callable[[float], None]):
    """One read with patience: a rejected token stops the run, a 429 waits, other failures retry."""
    for attempt in range(len(RETRY_WAITS) + 1):
        try:
            return fn()
        except MowlError as e:
            if e.status in (401, 403):
                raise Stop("MOWL rejected the token; sign in again (`mowl connect`) and re-run to resume") from e
            if e.status == 404:
                raise
            wait = e.retry_after if e.status == 429 and e.retry_after else None
            if e.status == 429 and wait is None:
                wait = 60
            if attempt == len(RETRY_WAITS):
                raise Stop(f"giving up after repeated failures ({e}); re-run later to resume") from e
            sleep(wait if wait is not None else RETRY_WAITS[attempt])
        except OSError as e:  # network trouble
            if attempt == len(RETRY_WAITS):
                raise Stop(f"giving up after repeated network errors ({type(e).__name__}); re-run later") from e
            sleep(RETRY_WAITS[attempt])


def fetch(creds: Credentials, store: CorpusStore, categories: list[int], *, delay: float = DEFAULT_DELAY,
          per_page: int = 50, limit: int | None = None, max_pages: int = 100,
          sleep: Callable[[float], None] = time.sleep, progress: Callable[[str], None] | None = None) -> dict:
    """Cache every program of the categories that is not cached yet; `limit` stops after that
    many new programs (for a first small run). Returns counts per category and in total."""
    say = progress or (lambda _msg: None)
    known = store.known_ids()
    per: dict[int, dict] = {}
    total = {"fetched": 0, "already_cached": 0, "failed": 0}
    stopped = None
    try:
        for cat in categories:
            counts = per[cat] = {"listed": 0, "fetched": 0, "already_cached": 0, "failed": 0}
            seen: set[int] = set()
            # PageNumber is 1-based: the server answers 0 with the same programs as 1 (seen on a
            # 57-program category, 2026-11-05), so starting at 0 made page 1 look like a repeat
            # and stopped after the first 50 programs.
            for page in range(1, max_pages + 1):
                items = _read(lambda: api.list_programs(creds, cat, page, per_page), sleep)
                sleep(delay)
                ids = [i["ProgramID"] for i in items or [] if isinstance(i, dict) and type(i.get("ProgramID")) is int]
                new_on_page = [i for i in ids if i not in seen]
                if not new_on_page:  # empty page, or the server ignored PageNumber and repeated one
                    break
                seen.update(new_on_page)
                counts["listed"] += len(new_on_page)
                for pid in new_on_page:
                    if pid in known:
                        counts["already_cached"] += 1
                        continue
                    if limit is not None and total["fetched"] >= limit:
                        raise Stop(f"stopped at --limit {limit}")
                    try:
                        program = _read(lambda: api.get_workout(creds, pid), sleep)
                    except MowlError:
                        counts["failed"] += 1  # e.g. a 404 for a program that was withdrawn
                        sleep(delay)
                        continue
                    store.put_program(cat, pid, program)
                    known.add(pid)
                    counts["fetched"] += 1
                    total["fetched"] += 1
                    sleep(delay)
                say(f"category {cat} page {page}: {len(new_on_page)} listed, {counts['fetched']} new so far")
                if len(items or []) < per_page:
                    break
    except Stop as e:
        stopped = str(e)
    for c in per.values():
        total["already_cached"] += c["already_cached"]
        total["failed"] += c["failed"]
    return {"categories": per, **total, "cached_total": len(known), "stopped": stopped}
