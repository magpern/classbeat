"""Workout spec -> MOWL program, segments and intervals.

Spec: {"name", "description"?, "short_description"?,
       "music"?: {"swedebeat": mix name or ID, "snap"?: true, "fit"?: false},
       "segments": [{"name", "kind": "warmup|main|recovery|cooldown",
                     "intervals": [{"sec", "zone" (1-7), "standing"?, "acc"?,
                                    "rpm"?: [from, to] or "beat",
                                    "game"?: one of GAMES, "ftp_test"?: 3, 5 or 20}]}]}

A running workout adds "sport": "running" and its intervals are {"sec", "zone" (1-5),
"gradient"?: 0 or 1}; no "sport" means cycling, as every spec did before. save() creates a
running workout; it refuses to update one or to give it music (see RUNNING_UPDATE).

Saving mirrors the app's Session Designer: PUT v1/programs (or v1/programs/{id}),
then per segment PUT v1/segments, DELETE .../intervals, PUT .../intervals/multiple,
and finally PUT v1/programs/{id}/segments, which replaces the segment list.
"""
from . import api
from .credentials import Credentials
from .errors import MowlError

# Zone set 1 (v1/intensityzonesets/1): HR, FTP, MAP, FTHR ranges per zone.
ZONES = {
    1: (-1, 70, 0, 55, -1, 49, 61, 68),
    2: (71, 76, 56, 75, 50, 55, 69, 83),
    3: (77, 82, 76, 90, 56, 75, 84, 94),
    4: (83, 90, 91, 105, 76, 94, 95, 105),
    5: (91, 96, 106, 120, 95, 105, 106, -1),
    6: (97, 98, 120, 150, 106, 120, -1, -1),
    7: (99, 100, -1, -1, -1, -1, -1, -1),  # Neuromuscular Power: all out, no power ceiling
}
ZONE_NAMES = {1: "Recovery", 2: "Endurance", 3: "Tempo", 4: "Threshold", 5: "VO2max", 6: "Anaerobic",
              7: "Neuromuscular"}
# The server scores an interval by its Coggan zone (ScaleCoggan), not by its %FTP: the zone's
# intensity factor, measured on single hour-long intervals (MiniCodeMonkey/flywheel), then
# Normalized Power over the whole class. A 30 s rolling mean of the per-second intensity,
# a 4th-power mean of that, and TSS = hours x IF^2 x 100 matched the server's own
# calculation (GET v1/calculations/program/{id}/TSS) within 0.7 % on 12 real classes,
# games included. The old linear fit of IF^2 per zone was off by up to 15 %.
ZONE_IF = {1: 0.2775, 2: 0.6575, 3: 0.83, 4: 0.98, 5: 1.13, 6: 1.3575, 7: 1.5025}
NP_WINDOW_SEC = 30
POSITION = {False: 1, True: 2}  # 1 Seated, 2 Standing
CYCLE = {False: 1, True: 4}  # 1 SB, 4 ACC
KINDS = ("warmup", "main", "recovery", "cooldown")
# Team games from the app's "Add a game" menu -> IntervalGameID, read from a workout made with
# each game in menu order. The server uses older names (4 Toe The Line, 5 Speed, 6 FillTheCup,
# 7 Dummygame1); 2 Race Track Laps and 3 Time Trial aren't in the menu. Saving the ID is enough.
GAMES = {"racetrack": 1, "power_pull": 4, "fast_lane": 5, "overflow": 6, "ghost_target": 7}
# FTP tests by length in minutes -> FtpTestID ("No FtpTest found by ID 4").
FTP_TESTS = {3: 1, 5: 2, 20: 3}
GAME_NAMES = {v: k for k, v in GAMES.items()}
MAX_PROGRAM_SEC = 3 * 3600
MIN_COOLDOWN_SEC = 60  # the app refuses to save a workout without a cooldown of at least this

# Running (classbeat ADR 0018, D1 read-only probe of 24 official running programs, 540
# intervals, 2026-11-02). GET v1/ActivityTypes: 0 Cycling, 1 Running. The sport is the
# program's own ActivityTypeID; their segments carry 0 in every case, so a segment's value
# says nothing. Every program has BikeTypeID 1, so BikeTypeID is not the sport.
SPORTS = ("cycling", "running")
ACTIVITY_TYPES = {0: "cycling", 1: "running"}
# Running intervals use the cycling key set and zone set 1: ScaleCoggan 1-5 seen, with the
# cycling FTP bands (as % of rFTP). Zones 6 and 7 were never seen, so they aren't accepted.
RUNNING_ZONES = {z: ZONES[z] for z in range(1, 6)}
# Gradient is the treadmill incline per interval (probably percent). Only 0.0 and 1.0 were
# seen; how a user-made program stores it is unverified, so nothing else is accepted.
RUNNING_GRADIENTS = (0, 1)
RUNNING_INTERVAL_KEYS = ("sec", "zone", "gradient")
# Creating a running program (magpern/classbeat#469, an owner-authorized live test on
# 2026-11-03, one private program created and read back): the cycling requests, unchanged,
# except that the program sends ActivityTypeID 1 and the intervals are running_interval_body.
# The segments keep ActivityTypeID 0, as official running programs have; 1 was never tried,
# so it is not sent. The server kept the program's ActivityTypeID 1 (BikeTypeID 1, private),
# each segment's 0, ScaleCoggan as sent (the test used zones 1-3; 4-5 only on official reads),
# Gradient 0.0/1.0, RPM 0, Pace null and the TSS we sent (it doesn't recompute it). The program shows in the unchanged My Workouts list with its
# own ActivityTypeID 1, so listing needs no change.
RUNNING_ACTIVITY_TYPE = 1
SEGMENT_ACTIVITY_TYPE = 0
# Still untried, so refused before any request: re-saving an existing running program, and
# a running program with music (attaching a new playlist or mix to one, or any PlaylistID).
RUNNING_UPDATE = "updating a running workout isn't supported yet; create a new one instead"
RUNNING_MUSIC = "music for a running workout isn't supported yet"
# A cycling interval with a running key is most likely a running spec without its "sport";
# saving it as a ride would drop the gradient, so save refuses it.
CYCLING_WITH_RUNNING_KEYS = ('a cycling interval has no gradient; add "sport": "running" to save a '
                             "running workout")


def seconds(seg: dict) -> int:
    return sum(i["sec"] for i in seg["intervals"])


def total_seconds(spec: dict) -> int:
    return sum(seconds(s) for s in spec["segments"])


def sport_of(spec: dict) -> str:
    """The spec's sport: "cycling" unless it says "sport": "running"."""
    value = spec.get("sport", "cycling")
    if not isinstance(value, str) or value not in SPORTS:
        raise ValueError(f"sport must be one of {SPORTS}")
    return value


def validate(spec: dict) -> None:
    """Raise ValueError unless the spec is something the app would accept."""
    if isinstance(spec, dict) and sport_of(spec) == "running":
        validate_running(spec)
        return

    def need(cond, msg):
        if not cond:
            raise ValueError(msg)
    need(isinstance(spec, dict), "spec must be an object")
    need(isinstance(spec.get("name"), str) and spec["name"].strip(), "workout needs a name")
    need(len(spec["name"]) <= 100, "name max 100 chars")
    need(len(spec.get("description", "")) <= 500, "description max 500 chars")
    segs = spec.get("segments")
    need(isinstance(segs, list) and segs, "workout needs segments")
    for s in segs:
        need(isinstance(s.get("name"), str) and s["name"].strip(), "every segment needs a name")
        need(s.get("kind") in KINDS, f"segment {s['name']!r}: kind must be one of {KINDS}")
        need(isinstance(s.get("intervals"), list) and s["intervals"], f"segment {s['name']!r} has no intervals")
        for i in s["intervals"]:
            need(isinstance(i.get("sec"), int) and 1 <= i["sec"] <= 3600,
                 f"segment {s['name']!r}: sec must be a whole number 1-3600 (MOWL stores whole seconds)")
            need(i.get("zone") in ZONES, f"segment {s['name']!r}: zone must be 1-7")
            need(i.get("game") in (None, *GAMES), f"segment {s['name']!r}: game must be one of {tuple(GAMES)}")
            if "ftp_test" in i:
                need(i["ftp_test"] in FTP_TESTS, f"segment {s['name']!r}: ftp_test must be 3, 5 or 20 (minutes)")
                need(i["sec"] == i["ftp_test"] * 60, f"segment {s['name']!r}: a {i['ftp_test']} min FTP test lasts {i['ftp_test'] * 60} s")
                need("game" not in i, f"segment {s['name']!r}: an interval can't be a game and an FTP test")
            rpm = i.get("rpm", [0, 0])
            need(isinstance(rpm, list) and len(rpm) == 2 and all(isinstance(x, int) and 0 <= x <= 200 for x in rpm)
                 and rpm[0] <= rpm[1], f"segment {s['name']!r}: rpm must be [from, to]")
    # The app's own rules for games and FTP tests, across segment boundaries too.
    special = [bool(i.get("game") or i.get("ftp_test")) for s in segs for i in s["intervals"]]
    need(not any(a and b for a, b in zip(special, special[1:])),
         "games and FTP tests must be separated by a regular interval")
    need(sum("ftp_test" in i for s in segs for i in s["intervals"]) <= 1, "only one FTP test per workout")
    need(segs[-1]["kind"] == "cooldown", "the last segment must be the cooldown")
    need(sum(s["kind"] == "cooldown" for s in segs) == 1, "exactly one cooldown segment")
    need(seconds(segs[-1]) >= MIN_COOLDOWN_SEC, f"cooldown must be at least {MIN_COOLDOWN_SEC} s")
    need(total_seconds(spec) <= MAX_PROGRAM_SEC, "workout max 3 hours")


def validate_running(spec: dict) -> None:
    """Raise ValueError unless the spec is a running workout shaped like MOWL's own: zones 1-5,
    gradient 0 or 1, and none of cycling's cadence, position, games or FTP tests. The workout
    and segment rules are cycling's (the app shows the same warm-up and cooldown blocks)."""
    def need(cond, msg):
        if not cond:
            raise ValueError(msg)
    need(isinstance(spec, dict), "spec must be an object")
    need(spec.get("sport") == "running", 'a running spec says "sport": "running"')
    need(isinstance(spec.get("name"), str) and spec["name"].strip(), "workout needs a name")
    need(len(spec["name"]) <= 100, "name max 100 chars")
    need(isinstance(spec.get("description", ""), str) and len(spec.get("description", "")) <= 500,
         "description max 500 chars")
    segs = spec.get("segments")
    need(isinstance(segs, list) and segs, "workout needs segments")
    for s in segs:
        need(isinstance(s, dict) and isinstance(s.get("name"), str) and s["name"].strip(),
             "every segment needs a name")
        need(s.get("kind") in KINDS, f"segment {s['name']!r}: kind must be one of {KINDS}")
        need(isinstance(s.get("intervals"), list) and s["intervals"], f"segment {s['name']!r} has no intervals")
        for i in s["intervals"]:
            need(isinstance(i, dict), f"segment {s['name']!r}: every interval must be an object")
            extra = sorted(k for k in i if k not in RUNNING_INTERVAL_KEYS)
            need(not extra, f"segment {s['name']!r}: a running interval has only {RUNNING_INTERVAL_KEYS}, not {extra}")
            # type() rather than isinstance(): True is an int, and must not pass as 1.
            need(type(i.get("sec")) is int and 1 <= i["sec"] <= 3600,
                 f"segment {s['name']!r}: sec must be a whole number 1-3600 (MOWL stores whole seconds)")
            need(type(i.get("zone")) is int and i["zone"] in RUNNING_ZONES,
                 f"segment {s['name']!r}: a running zone must be 1-5")
            g = i.get("gradient", 0)
            need(type(g) in (int, float) and g in RUNNING_GRADIENTS,
                 f"segment {s['name']!r}: gradient must be 0 or 1 (the treadmill inclines MOWL's running "
                 "workouts use)")
    need(segs[-1]["kind"] == "cooldown", "the last segment must be the cooldown")
    need(sum(s["kind"] == "cooldown" for s in segs) == 1, "exactly one cooldown segment")
    need(seconds(segs[-1]) >= MIN_COOLDOWN_SEC, f"cooldown must be at least {MIN_COOLDOWN_SEC} s")
    need(total_seconds(spec) <= MAX_PROGRAM_SEC, "workout max 3 hours")


def tss(spec: dict) -> float:
    """Estimated TSS: the server's Normalized Power model (see ZONE_IF).

    Running uses the same model: its intervals carry the same ScaleCoggan on zone set 1, and
    the server publishes their load in the same TSS field. Gradient doesn't enter it. That a
    running program's published TSS follows this model is not yet checked against a running
    layout: treat the server's TSS (summarize) as the reference."""
    trace = [ZONE_IF[i["zone"]] for s in spec["segments"] for i in s["intervals"] for _ in range(i["sec"])]
    if not trace:
        return 0.0
    w = NP_WINDOW_SEC
    if len(trace) >= w:
        total = [0.0]
        for x in trace:
            total.append(total[-1] + x)
        trace = [(total[k + w] - total[k]) / w for k in range(len(trace) - w + 1)]
        hours = (len(trace) + w - 1) / 3600
    else:
        hours = len(trace) / 3600
    np_if = (sum(x ** 4 for x in trace) / len(trace)) ** 0.25
    return hours * np_if ** 2 * 100


def interval_body(i: dict, sport: str = "cycling") -> dict:
    if sport == "running":
        return running_interval_body(i)
    if sport != "cycling":
        raise ValueError(f"sport must be one of {SPORTS}")
    hr0, hr1, ftp0, ftp1, map0, map1, fthr0, fthr1 = ZONES[i["zone"]]
    rpm = i.get("rpm", [0, 0])
    # Numbers as strings and the "ScaleBong" spelling copy the app exactly.
    return {
        "Duration": i["sec"], "RPMFrom": str(rpm[0]), "RPMTo": str(rpm[1]),
        "PulseZoneFrom": str(hr0), "PulseZoneTo": str(hr1), "Intensity": 1,
        "PositionTypeID": POSITION[bool(i.get("standing"))], "CycleID": CYCLE[bool(i.get("acc"))],
        "FTPFrom": str(ftp0), "FTPTo": str(ftp1), "MAPFrom": str(map0), "MAPTo": str(map1),
        "FTHRFrom": str(fthr0), "FTHRTo": str(fthr1), "LTHRFrom": "0", "LTHRTo": "0",
        "VO2From": "0", "VO2To": "0", "ScaleCoggan": i["zone"], "Scale1to5": 0, "ScaleBong": 0,
        "PresetCode": 0, "CreatedfromCode": False, "CueCards": [],
        "IntervalGame": {"IntervalGameID": GAMES[i["game"]]} if i.get("game") else None,
        "FtpTest": {"FtpTestID": FTP_TESTS[i["ftp_test"]]} if i.get("ftp_test") else None,
        "Gradient": 0,
    }


def running_interval_body(i: dict) -> dict:
    """A running interval in the interval format, with the values official running programs
    hold: cycling's keys, RPM 0, seated, SB, no game or FTP test, the zone's ranges from zone
    set 1 and the interval's Gradient. save() sends it for a running workout."""
    extra = sorted(k for k in i if k not in RUNNING_INTERVAL_KEYS)
    if extra:
        raise ValueError(f"a running interval has only {RUNNING_INTERVAL_KEYS}, not {extra}")
    if type(i.get("zone")) is not int or i["zone"] not in RUNNING_ZONES:
        raise ValueError("a running zone must be 1-5")
    g = i.get("gradient", 0)
    if type(g) not in (int, float) or g not in RUNNING_GRADIENTS:
        raise ValueError("gradient must be 0 or 1")
    # Reads give Gradient as 0.0 or 1.0, where the cycling body sends a plain 0.
    return {**interval_body({"sec": i["sec"], "zone": i["zone"]}), "Gradient": float(g)}


def check_save(spec: dict, playlist_id: int = -1, program_id: int | None = None) -> str:
    """The spec's sport, or an error for a save not yet known to work (ValueError for what the
    spec asks, MowlError for the call's arguments). Sends nothing, so callers run it before any
    request (service.save before it attaches music)."""
    if not isinstance(spec, dict):
        raise ValueError("spec must be an object")
    sport = sport_of(spec)
    if sport == "running":
        if program_id is not None:
            raise MowlError(RUNNING_UPDATE)
        if _music_opts_set(spec):
            raise ValueError(RUNNING_MUSIC)  # as service.prepare says it: the spec asks for it
        if playlist_id != -1:
            raise MowlError(RUNNING_MUSIC)
    elif any(isinstance(i, dict) and "gradient" in i for s in _list(spec.get("segments"))
             if isinstance(s, dict) for i in _list(s.get("intervals"))):
        raise MowlError(CYCLING_WITH_RUNNING_KEYS)
    return sport


def _list(value) -> list:
    return value if isinstance(value, list) else []  # a malformed spec is validate()'s to explain


def _music_opts_set(spec: dict) -> bool:
    music = spec.get("music") or {}
    return bool(spec.get("swedebeat") or (isinstance(music, dict) and (music.get("swedebeat") or music.get("spotify"))))


def save(spec: dict, creds: Credentials, playlist_id: int = -1, program_id: int | None = None) -> dict:
    """Create the workout, or with program_id re-save an existing one the way the app does
    (new segment copies replace the old segment list). Returns the program and segment IDs.
    A running workout can only be created, without music (see RUNNING_UPDATE)."""
    sport = check_save(spec, playlist_id, program_id)
    validate(spec)
    running = sport == "running"
    path = f"v1/programs/{program_id}" if program_id else "v1/programs"
    program = api.call(creds, "PUT", path, {
        **({"ProgramID": program_id} if program_id else {}),
        "ProgramCategoryID": api.MY_WORKOUTS, "Name": spec["name"],
        "Description": spec.get("description", ""), "ShortDescription": spec.get("short_description", ""),
        "PlaylistID": playlist_id, "IsPublic": False, "TSS": tss(spec),
        "ActivityTypeID": RUNNING_ACTIVITY_TYPE if running else 0,
    })
    pid = program["ProgramID"]
    if program_id and pid != program_id:
        # PUT v1/programs without the ID creates a new program; never write segments into a
        # copy while reporting an update.
        raise MowlError(f"MOWL saved workout {program_id} as a new workout {pid}; check My Workouts")
    seg_ids = []
    for s in spec["segments"]:
        seg = api.call(creds, "PUT", "v1/segments", {
            "Name": s["name"], "Description": s.get("description", ""),
            "ShortDescription": s.get("short_description", ""),
            "IsWarmup": s["kind"] == "warmup", "IsActiveRecovery": s["kind"] == "recovery",
            "IsCooldown": s["kind"] == "cooldown", "TotalDuration": seconds(s),
            "IsPublic": False, "IsTemplate": False, "ActivityTypeID": SEGMENT_ACTIVITY_TYPE,
        })
        sid = seg["SegmentID"]
        api.call(creds, "DELETE", f"v1/segments/{sid}/intervals")
        api.call(creds, "PUT", f"v1/segments/{sid}/intervals/multiple",
                 {"Intervals": [interval_body(i, sport) for i in s["intervals"]]})
        seg_ids.append(sid)
    api.call(creds, "PUT", f"v1/programs/{pid}/segments", {"SegmentIDs": seg_ids})
    return {"program_id": pid, "segment_ids": seg_ids, "updated": bool(program_id)}


def program_sport(program: dict) -> str:
    """The sport of a program as returned by GET v1/programs/{id}: its own ActivityTypeID
    (never a segment's, which is 0 even in running programs). A program without one is
    cycling, as every program read before running was."""
    value = program.get("ActivityTypeID")
    if value is None:
        return "cycling"
    if type(value) is not int or value not in ACTIVITY_TYPES:
        raise MowlError(f"workout {program.get('ProgramID')} has an activity type this tool doesn't know ({value!r})")
    return ACTIVITY_TYPES[value]


def listed_sport(entry: dict) -> str:
    """The sport of a My Workouts list entry (POST v1/programs), from its own ActivityTypeID:
    "cycling", "running", or "unknown" for a value this tool doesn't know (never guessed, and
    one odd entry doesn't break the list)."""
    value = entry.get("ActivityTypeID")
    if value is None:
        return "cycling"
    return ACTIVITY_TYPES.get(value, "unknown") if type(value) is int else "unknown"


def _number(value) -> float | None:
    if type(value) in (int, float):
        return float(value)
    try:
        return float(value) if isinstance(value, str) else None
    except ValueError:
        return None


def _running_interval(i: dict) -> dict:
    """What a running interval holds: zone and gradient, and cadence or position only if a
    program ever sets them (none of the official ones do)."""
    rpm = [i.get("RPMFrom"), i.get("RPMTo")]
    return {"zone": i.get("ScaleCoggan"), "gradient": _number(i.get("Gradient")),
            **({"rpm": rpm} if any(_number(x) for x in rpm) else {}),
            **({"position": i.get("PositionTypeName")} if i.get("PositionTypeID") not in (None, 1) else {})}


def summarize(program: dict) -> dict:
    """Compact view of a program as returned by GET v1/programs/{id}. A running program also
    says "sport": "running"; a cycling one looks as it always has."""
    running = program_sport(program) == "running"
    t, segs = 0, []
    for s in program.get("Segments") or []:
        ivs = [{"start": mmss(t + sum(x["Duration"] for x in s["Intervals"][:n])), "sec": i["Duration"],
                **(_running_interval(i) if running else
                   {"zone": i["ScaleCoggan"], "position": i["PositionTypeName"], "cycle": i["CycleName"],
                    "rpm": [i["RPMFrom"], i["RPMTo"]]}),
                **({"game": GAME_NAMES.get(i["IntervalGame"]["IntervalGameID"], i["IntervalGame"].get("IntervalGameName"))}
                   if i.get("IntervalGame") else {}),
                **({"ftp_test": i["FtpTest"].get("DisplayName")} if i.get("FtpTest") else {})}
               for n, i in enumerate(s["Intervals"])]
        kind = ("warmup" if s["IsWarmup"] else "recovery" if s["IsActiveRecovery"]
                else "cooldown" if s["IsCooldown"] else "main")
        segs.append({"name": s["Name"], "kind": kind, "start": mmss(t), "sec": s["TotalDuration"], "intervals": ivs})
        t += s["TotalDuration"]
    pl = program.get("Playlist") or {}
    return {"program_id": program["ProgramID"], "name": program["Name"], "public": program["IsPublic"],
            **({"sport": "running"} if running else {}),
            "duration": mmss(program["TotalDuration"]), "tss": round(program.get("TSS") or 0, 1),
            "music": ({"type": pl.get("PlaylistType"), "name": pl.get("PlaylistName"),
                       "playlist_id": program.get("PlaylistID")} if pl else None),
            "description": program.get("Description"), "segments": segs}


def mmss(sec: float) -> str:
    tenths = round(max(0.0, float(sec)) * 10)
    whole, frac = divmod(tenths, 10)
    return f"{whole // 60}:{whole % 60:02d}" + (f".{frac}" if frac else "")
