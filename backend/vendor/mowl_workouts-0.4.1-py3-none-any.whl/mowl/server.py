"""MCP server for MOWL / Intelligent Cycling: design workouts and time them to Swedebeat or Spotify music.

Run: python -m mowl.server   (stdio)
"""
import json

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

from . import api, connect, library, local, service, spotify_web, swedebeat, workout

INSTRUCTIONS = """\
Design indoor-cycling classes for the Intelligent Cycling (MOWL) app and save them to the
user's "My Workouts". Workouts are private unless the user publishes them in the app.

Guiding the user: many users are instructors, not technical, and come back after weeks
having forgotten how this works. A message starting "MOWL:" came from the /mowl command.
When the user asks what you can do or how to use this, or seems unsure, call
connection_status and answer in plain words, in at most about ten lines, with no tool names:
1. what's connected, and the single next step if MOWL isn't;
2. three requests they could make that fit their setup (Spotify or Swedebeat connected or
   not), such as "45 min, 90s hits, three climbs, TSS 65" or "time a class to my Spotify
   playlist Tuesday ride";
3. that you preview before saving, can change an existing class, and can add races, team
   games (Racetrack, Power Pull, Fast Lane, Overflow, Ghost Target) and an FTP test.
Mention "/mowl" (the panel and a quick guide) and "/mowl help" in Claude Code. After saving
a class, offer one natural next step, such as riding it, adjusting it, or a race version.

Accounts: only MOWL is required. connection_status shows what is connected. When a tool
says an account is not connected, call connect_account with that service: it opens a
sign-in page in the user's browser. Never ask for a password in chat. Spotify sign-in is
only needed for you to search songs or create playlists; a playlist the user already has
works through MOWL without it (list_spotify_playlists, analyze_spotify_playlist).
Swedebeat sign-in is only needed for match_swedebeat_catalogue.

Workout spec (used by preview_workout, create_workout and update_workout):
{"name": str, "description": str (max 500), "short_description": str,
 "music": {"swedebeat": mix name or ID | "spotify": playlist name or ID,
           "snap": true (default), "fit": false, "tolerance": 6},
 "segments": [{"name": str, "kind": "warmup" | "main" | "recovery" | "cooldown",
   "intervals": [{"sec": int, "zone": 1-7, "standing": bool, "acc": bool,
                  "rpm": [from, to] | "beat",
                  "game": "racetrack" | "power_pull" | "fast_lane" | "overflow" | "ghost_target",
                  "ftp_test": 3 | 5 | 20}]}]}

Rules the app enforces: whole seconds only; the last segment is the only cooldown and lasts
at least 60 s; at most 3 hours. Zones (FTP %): 1 recovery <55, 2 endurance 56-75, 3 tempo
76-90, 4 threshold 91-105, 5 VO2max 106-120, 6 anaerobic 120-150, 7 neuromuscular (all
out, no ceiling). "acc" marks an acceleration/sprint.
Typical cadence: seated flat 85-100, seated climb 65-80, standing 60-75.

Competitions, only when the user asks for races, games or a competition: "game" turns an
interval into one of the app's team games (racetrack: most laps; power_pull: two teams, who
is strongest; fast_lane: fastest team average; overflow: stay in the target zone to fill the
cup; ghost_target: hold the target without seeing it). Races in real classes are 15-35 s,
seated, zone 7 (or 6), without "rpm", after a short build-up and before a recovery; start
them on a drop. "ftp_test" (3, 5 or 20 minutes) makes the interval the app's FTP test; its
"sec" must be exactly that long. The app allows one FTP test per workout and needs a regular
interval between any two games or FTP tests. Warm up properly before an FTP test.

Timing to music:
1. Swedebeat: list_swedebeat_mixes, then analyze_swedebeat_mix for the songs, BPM and the
   drops and breakdowns (times in seconds); the first analysis of a mix takes about a minute
   and finds beat 1 from the audio. Spotify: list_spotify_playlists, then
   analyze_spotify_playlist for the tracks (exact start times, BPM) and Spotify's section
   changes as drops and breakdowns; there is no audio, so bars are counted from section
   starts. Track changes ("track" events) are the most reliable points to change effort.
2. Plan intervals around the music: start efforts on drops, recoveries on breakdowns, and
   match intensity to the energy of each song.
3. With "snap" (default) every interval change is moved to the nearest drop or breakdown
   within "tolerance" seconds, otherwise to the nearest beat 1, then rounded to whole
   seconds. "rpm": "beat" sets cadence from the song's BPM (or half of it on climbs).
   "fit": true first stretches the whole workout to the length of the mix.
Picking the songs yourself (Spotify):
a. connect_spotify once (the user approves in their browser).
b. Draft a pool of about 3x the songs the class needs, each with a role (warmup, climb,
   sprint, recovery, cooldown), from your own knowledge of the requested era or style;
   Spotify gives no popularity or BPM. find_spotify_songs resolves them to tracks.
c. create_spotify_playlist "Claude pool" with the pool, then analyze_spotify_playlist with
   its returned spotify_id (new playlists are not in MOWL's list by name yet) and refresh,
   to get each track's real BPM, length and sections from MOWL.
d. Choose and order the tracks for the class (climbs at 130-150 or 65-75 BPM ridden at
   half/on the beat, sprints on tracks with strong drops, steady 100-125 BPM to warm up),
   save that as its own playlist with create_spotify_playlist, analyze it by spotify_id
   with refresh, and design the workout on it with music {"spotify": <that spotify_id>}.
e. To reach a TSS target, adjust zones and lengths and preview until it is close.
Swedebeat music from a Spotify selection (when the class must play Swedebeat music, e.g. a
licensed gym): pick and order the songs and create the Spotify playlist as above, then
match_swedebeat_catalogue to confirm Swedebeat has them (connect_account "swedebeat" once).
The Swedebeat app can only build a mix from songs it has, so settle every song that isn't
"found" before the user builds the mix:
- "unsure": Swedebeat has a different-looking title by that artist. If it's the same song
  spelled differently, keep it; if it's another song, treat it as missing.
- "missing": pick a replacement from your pool with the same role and a similar BPM and
  energy, and match it too. Repeat until every song is found.
Then save the Spotify playlist again with create_spotify_playlist (the same name replaces its
songs), and tell the user in one line per song what changed and why. Only then ask them to
open the Swedebeat app, match that Spotify playlist and create the mix there.
When the mix appears in list_swedebeat_mixes, analyse it and check it against the plan before
designing: its length should be close to swedebeat_sec from the last match, minus up to
about 10 s per song change for crossfades. If it's clearly shorter, or has noticeably fewer
songs (songs at the same tempo can merge, so fewer songs alone is no proof), say which song
looks missing and ask the user to check the mix in the Swedebeat app.
Design on the built mix with music {"swedebeat": <its name or id>}. The Swedebeat versions
differ in length from Spotify's, so always time the class on the built mix, never on the
Spotify playlist.

4. Always preview_workout first and show the user the timeline and warnings; save only
   when they are happy. Beat 1 is estimated per song and can be one beat off; pass on the
   warning naming those songs. If the user hears a song's changes a beat early or late,
   call correct_beat_one for that song, then preview and save again.
"""

mcp = MCPServer(name="mowl", title="MOWL workouts", instructions=INSTRUCTIONS, version="0.1.0")
READ = ToolAnnotations(readOnlyHint=True, openWorldHint=True)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True)


def _creds():
    """The signed-in user's credentials, read from ~/.mowl on each call so a sign-in made
    during the session is picked up. The MCP server is an entry point: it is where files are read."""
    return local.load_credentials()


def _spec(spec: dict | str) -> dict:
    return json.loads(spec) if isinstance(spec, str) else spec


@mcp.tool(annotations=READ)
def list_workouts(ordering: str = "creationDateDesc") -> list:
    """The user's own workouts ("My Workouts"), newest first. ordering: creationDateDesc,
    popularityDesc or yourPlaysDesc."""
    rows = api.list_workouts(_creds(), ordering)
    return [{"program_id": p["ProgramID"], "name": p["Name"], "duration": workout.mmss(p["TotalDuration"]),
             "segments": p["SegmentCount"], "public": p["IsPublic"], "music": p.get("PlaylistType"),
             "created": p["DateCreated"][:10]} for p in rows]


@mcp.tool(annotations=READ)
def get_workout(program_id: int) -> dict:
    """One workout with its segments and intervals (start time, length, zone, position, cadence)."""
    return workout.summarize(api.get_workout(_creds(), program_id))


@mcp.tool(annotations=READ)
def get_zones() -> list:
    """The training zones the app uses (zone set 1): FTP, HR, MAP and FTHR ranges in percent."""
    return [{"zone": z, "name": workout.ZONE_NAMES[z], "hr_pct": [v[0], v[1]], "ftp_pct": [v[2], v[3]],
             "map_pct": [v[4], v[5]], "fthr_pct": [v[6], v[7]]} for z, v in workout.ZONES.items()]


@mcp.tool(annotations=READ)
def list_swedebeat_mixes(name_filter: str = "") -> list:
    """The user's own Swedebeat mixes. Lengths come from Swedebeat and can be wrong;
    analyze_swedebeat_mix reports the real length of the audio."""
    store = local.FileMapStore()
    return [{"swedebeat_id": m["ID"], "name": m["Name"], "listed_duration": workout.mmss(m["DurationInMilliseconds"] / 1000),
             "analysed": library.cached(store, m["ID"]) is not None}
            for m in api.swedebeat_mixes(_creds(), name_filter)]


@mcp.tool(annotations=WRITE)
def analyze_swedebeat_mix(mix: str, include_phrases: bool = False, refresh: bool = False) -> dict:
    """Music map of a Swedebeat mix: songs with BPM, and drops and breakdowns on beat 1
    (t in seconds). include_phrases adds every 8-bar phrase start. The first call per mix
    adds it to the user's MOWL playlists (as the app does), downloads and analyses the
    audio (about a minute), then caches the map."""
    entry = library.swedebeat_map(_creds(), local.FileMapStore(), mix, refresh=refresh)
    return library.summary(entry, "phrases" if include_phrases else "events")


@mcp.tool(annotations=READ)
def list_spotify_playlists(name_filter: str = "") -> list:
    """The user's Spotify playlists as MOWL sees them (MOWL's Spotify connection)."""
    store = local.FileMapStore()
    return [{"spotify_id": p["ID"], "name": p["Name"], "tracks": p["TrackCount"],
             "has_unavailable_tracks": p["HasUnavailableTracks"],
             "analysed": library.cached(store, p["ID"], "spotify") is not None}
            for p in api.spotify_playlists(_creds(), name_filter)]


@mcp.tool(annotations=WRITE)
def analyze_spotify_playlist(playlist: str, refresh: bool = False) -> dict:
    """Music map of a Spotify playlist (name or Spotify ID): each track's start time and BPM, and Spotify's
    section changes as drops and breakdowns (t in seconds from the start of the playlist).
    The first call adds the playlist to the user's MOWL playlists (as the app does, ~10 s)
    and reads Spotify's analysis of every track; use refresh after changing the playlist."""
    return library.summary(library.spotify_map(_creds(), local.FileMapStore(), playlist, refresh=refresh))


@mcp.tool(annotations=READ)
def connection_status() -> dict:
    """Which accounts are connected: MOWL (required), Spotify and Swedebeat (both optional)."""
    return connect.status()


@mcp.tool(annotations=WRITE)
def connect_account(service: str = "mowl") -> dict:
    """Sign the user in to "mowl", "swedebeat" or "spotify": opens a sign-in page in their
    browser and waits up to 5 minutes. The user types the password there, never in chat;
    only the token is kept. Only needed once per service."""
    return connect.connect(service)


@mcp.tool(annotations=WRITE)
def connect_spotify() -> dict:
    """Connect the user's Spotify account (needed to search and create playlists): opens
    Spotify's consent page in their browser and waits up to 5 minutes for them to approve.
    Only needed once; the token then renews itself."""
    return spotify_web.connect(_creds())


@mcp.tool(annotations=READ)
def find_spotify_songs(songs: list, years: str = "") -> dict:
    """Find songs on Spotify. songs: [{"artist", "title", optional extra keys such as "role"}];
    years like "1990-1999" prefers original releases from that span. Returns found tracks
    (uri, title, artists, album, year, length) with your extra keys kept, and the missing ones."""
    return spotify_web.find_songs(_creds(), songs, years)


@mcp.tool(annotations=READ)
def search_spotify(query: str) -> list:
    """Free Spotify track search (up to 10 results); supports Spotify filters such as
    artist:, track:, year:1990-1999."""
    return spotify_web.search_tracks(_creds(), query)


@mcp.tool(annotations=WRITE)
def create_spotify_playlist(name: str, track_uris: list, description: str = "", public: bool = False) -> dict:
    """Create a playlist in the user's Spotify (private by default) in this exact order, or
    replace the songs of their existing playlist with that name. Then call
    analyze_spotify_playlist with the returned spotify_id and refresh=true before designing on it."""
    return spotify_web.save_playlist(_creds(), name, track_uris, description, public)


@mcp.tool(annotations=READ)
def match_swedebeat_catalogue(tracks: list) -> dict:
    """Match songs to the Swedebeat catalogue, for a class that must play Swedebeat music (e.g.
    a licensed gym) instead of Spotify audio. tracks: [{"artist", "title"}] (extra keys ignored).
    Each song is "found" (the same song), "unsure" (a different-looking title by that artist)
    or "missing", with its position in the list; swedebeat_sec is the found songs' length
    in Swedebeat's versions. Needs Swedebeat connected once
    (connect_account "swedebeat"). Swedebeat builds the actual mix only in its own app, so after matching, have the
    user create the mix there; it then shows up in list_swedebeat_mixes, ready to analyse."""
    return swedebeat.match_tracks(_creds(), tracks)


@mcp.tool(annotations=WRITE)
def correct_beat_one(mix: str, song: int, beats: int) -> dict:
    """Fix a Swedebeat song's beat 1 after listening: beats > 0 when the changes in that song come
    early (move beat 1 later), < 0 when they come late. Saved with the mix's music map, so
    it applies to every later workout on the mix; re-save affected workouts to use it."""
    if beats == 0 or abs(beats) > 3:
        raise ValueError("beats must be -3..3 and not 0 (a bar has 4 beats)")
    entry = library.correct_beat1(_creds(), local.FileMapStore(), mix, song, beats)
    return library.summary(entry)


@mcp.tool(annotations=WRITE)
def preview_workout(spec: dict) -> dict:
    """Check a workout spec and, with music, show where every change lands in the mix.
    Saves no workout (a mix not analysed before is analysed first, see analyze_swedebeat_mix).
    Returns the final timeline, duration, estimated TSS and warnings."""
    plan = service.preview(_spec(spec), _creds(), local.FileMapStore())
    return {k: plan[k] for k in ("duration", "tss", "music", "timeline", "warnings")} | {"spec": plan["spec"]}


@mcp.tool(annotations=WRITE)
def create_workout(spec: dict) -> dict:
    """Save a new private workout in the user's My Workouts (with its music, if any)."""
    return service.save(_spec(spec), _creds(), local.FileMapStore())


@mcp.tool(annotations=WRITE)
def update_workout(program_id: int, spec: dict) -> dict:
    """Replace an existing workout's name, description, music and segments, as re-saving it
    in the app's Session Designer does."""
    return service.save(_spec(spec), _creds(), local.FileMapStore(), program_id=program_id)


def main():
    connect.remember_launcher()
    mcp.run("stdio")


if __name__ == "__main__":
    main()
