"""Music maps for Swedebeat mixes and Spotify playlists.

Analysing a Swedebeat mix wraps it in a MOWL playlist (as the app does when you add it
to a workout), downloads the MP3 through MOWL's temporary link, analyses it and deletes
the audio again; only the map (timings, no audio) is kept. A Spotify playlist is wrapped
the same way and mapped from track lengths, BPM and Spotify's sections (see spotify.py).

What is kept is split in two, behind a `MapStore` (the CLI uses a file store, see local.py;
a hosted app supplies a database one):
- the analysis is the same for everyone: keyed by (source, fingerprint) and carrying
  `music.MAP_VERSION`, so users of the same mix share one analysis. The fingerprint is the
  mix's Swedebeat ID, or the Spotify playlist ID;
- the link is one user's: the MOWL playlist that wraps the mix in their account, what
  Spotify marks unplayable for them, and their by-ear beat-1 corrections.
A store instance is bound to one user for the link methods.
"""
import copy
import re
import shutil
import tempfile
from collections.abc import Callable
from typing import Protocol

from . import api, music, spotify
from .credentials import Credentials


class MapStore(Protocol):
    """Where analyses (shared) and links (per user) are kept. Missing means None."""

    def get_analysis(self, source: str, fingerprint: str) -> dict | None: ...

    def put_analysis(self, source: str, fingerprint: str, analysis: dict) -> None: ...

    def get_link(self, source: str, source_id: str) -> dict | None: ...

    def put_link(self, source: str, source_id: str, link: dict) -> None: ...


def split_legacy(entry: dict) -> tuple[dict, dict]:
    """Split a map entry cached by mowl-workouts 0.3.x (one file holding both) into
    (analysis, link). Entries from before Spotify support have no source."""
    source = entry.get("source", "swedebeat")
    source_id = entry.get("source_id") or entry[f"{source}_id"]
    analysis = {k: entry[k] for k in ("name", "duration", "listed_duration", "map") if k in entry}
    analysis.update(source=source, source_id=source_id)
    link = {"source": source, "source_id": source_id, "playlist_id": entry["playlist_id"],
            "beat1_shifts": {}}
    for k in ("track_id", "unavailable"):
        if k in entry:
            link[k] = entry[k]
    return analysis, link


def _fresh(analysis: dict | None) -> dict | None:
    return analysis if analysis and analysis.get("map", {}).get("version") == music.MAP_VERSION else None


def cached(store: MapStore, source_id: str, source: str = "swedebeat") -> dict | None:
    """The shared analysis, if there is a current one."""
    return _fresh(store.get_analysis(source, source_id))


def _entry(analysis: dict, link: dict) -> dict:
    """The analysis and one user's link as the single dict the rest of the package uses."""
    source, m = analysis["source"], copy.deepcopy(analysis["map"])
    for song, beats in (link.get("beat1_shifts") or {}).items():
        shift_beat1(m, int(song), beats)
    entry = {k: v for k, v in analysis.items() if k != "map"}
    entry.update({f"{source}_id": analysis["source_id"], "playlist_id": link["playlist_id"], "map": m})
    for k in ("track_id", "unavailable"):
        if k in link:
            entry[k] = link[k]
    return entry


def _new_link(source: str, source_id: str, playlist_id: int, **extra) -> dict:
    return {"source": source, "source_id": source_id, "playlist_id": playlist_id, "beat1_shifts": {}, **extra}


def swedebeat_map(creds: Credentials, store: MapStore, mix, refresh: bool = False) -> dict:
    """{"swedebeat_id", "name", "playlist_id", "track_id", "duration", "map"} for a mix."""
    found = api.find_swedebeat(creds, mix)
    sid = found["ID"]
    analysis = None if refresh else cached(store, sid)
    link = store.get_link("swedebeat", sid) if analysis else None
    if analysis and link:
        return _entry(analysis, link)
    # Wrap the mix in this user's MOWL account and wait for MOWL to process it.
    pid = api.attach_swedebeat(creds, sid)["PlaylistID"]
    track = api.wait_indexed(creds, pid)
    link = _new_link("swedebeat", sid, pid, track_id=track["TrackID"])
    if not analysis:
        audio_dir = tempfile.mkdtemp(prefix="mowl-audio-")
        try:
            path = api.download_swedebeat_audio(creds, pid, audio_dir + "/mix.mp3")
            m = music.analyze_file(path)
        finally:
            shutil.rmtree(audio_dir, ignore_errors=True)
        analysis = {"source": "swedebeat", "source_id": sid, "name": found["Name"],
                    "duration": round(track["Duration"] / 1000, 3),
                    # Swedebeat's own length can be wrong (one mix lists 67:35 for a 10:51 file).
                    "listed_duration": round(found["DurationInMilliseconds"] / 1000, 3), "map": m}
        store.put_analysis("swedebeat", sid, analysis)
    store.put_link("swedebeat", sid, link)
    return _entry(analysis, link)


def spotify_map(creds: Credentials, store: MapStore, playlist, refresh: bool = False) -> dict:
    """Map of a Spotify playlist. Playlists change, so pass refresh after editing one in Spotify."""
    try:
        found = api.find_spotify(creds, playlist)
    except api.MowlError:
        # MOWL's list leaves out playlists created since its last sync (seen with a new
        # private one), but attaching works by ID; a Spotify ID is 22 letters and digits.
        if not re.fullmatch(r"[0-9A-Za-z]{22}", str(playlist).strip()):
            raise
        found = {"ID": str(playlist).strip(), "Name": None}
    sid = found["ID"]
    analysis = None if refresh else cached(store, sid, "spotify")
    link = store.get_link("spotify", sid) if analysis else None
    if analysis and link:
        return _entry(analysis, link)
    attached = api.attach_spotify(creds, sid)
    pid = attached["PlaylistID"]
    # The name is only needed for a new analysis; MOWL's attach reply may lack PlaylistName.
    name = None if analysis else (found["Name"] or attached["PlaylistName"])
    link_unavailable, built = spotify_analysis(creds, pid, sid, name, with_map=not analysis)
    link = _new_link("spotify", sid, pid, unavailable=link_unavailable)
    if not analysis:
        analysis = built
        store.put_analysis("spotify", sid, analysis)
    store.put_link("spotify", sid, link)
    return _entry(analysis, link)


def spotify_analysis(creds: Credentials, playlist_id: int, spotify_id: str, name: str | None = None,
                     with_map: bool = True,
                     checkpoint: Callable[[], None] | None = None) -> tuple[list, dict | None]:
    """The read-only half of `spotify_map`: (unavailable, analysis) for a Spotify playlist that is
    already wrapped in a MOWL playlist (`playlist_id`, from `api.attach_spotify` or a stored link).

    Only GET calls are made (tracks, availability, one `AudioAnalysis` per track), so a caller that
    must not write to the user's account, such as a hosted app tracking the attach as its own
    operation, can use it; it never attaches. `unavailable` is what Spotify marks unplayable for this
    user. `analysis` is the shared analysis entry (`source`, `source_id`, `name`, `duration`, `map`),
    or None when `with_map` is false (the caller already has a current one and wants only the link
    data; then the per-track sections are not fetched, and `name` is ignored).

    `checkpoint`, if given, is called before each read (tracks, availability, each track's
    sections); a caller cancels the run by raising from it, which stops the function at once with
    no further reads."""
    check = checkpoint or (lambda: None)
    check()
    tracks = api.playlist_tracks(creds, playlist_id)
    check()
    problems = api.playlist_availability(creds, playlist_id).get("PlaylistErrors") or []
    unavailable = [p.get("Description", "").strip() for p in problems]
    if not with_map:
        return unavailable, None
    skipped = {p["TrackInfo"]["TrackName"] for p in problems if p.get("TrackInfo")}
    playable = [t for t in tracks if t["Title"] not in skipped]
    sections = {}
    for t in playable:
        if t["SpotifyTrackID"] not in sections:
            check()
            sections[t["SpotifyTrackID"]] = api.spotify_sections(creds, t["SpotifyTrackID"])
    m = spotify.build_map(playable, sections)
    return unavailable, {"source": "spotify", "source_id": spotify_id, "name": name,
                         "duration": m["duration"], "map": m}


def shift_beat1(m: dict, song_no: int, beats: int) -> None:
    """Move a song's beat 1 (and its phrase starts and events) by whole beats, in place."""
    song = next((s for s in m["songs"] if s["song"] == song_no), None)
    if song is None:
        raise ValueError(f"no song {song_no} in this mix")
    d = beats * 60.0 / song["bpm"]
    song["first_downbeat"] = round(song["first_downbeat"] + d, 4)
    song["first_phrase"] = round(song["first_phrase"] + d, 4)
    song["beat1_shift"] = song.get("beat1_shift", 0) + beats
    bar = 4 * 60.0 / song["bpm"]
    for e in m["events"]:
        if e["song"] == song_no:
            # place the change again on the corrected bar start nearest to where it was found
            at = e.get("precise", e["t"] + d)
            e["t"] = round(min(music.grid_points(song, 4, song["first_downbeat"], at - bar, at + bar),
                               key=lambda x: abs(x - at)), 3)


def correct_beat1(creds: Credentials, store: MapStore, mix, song_no: int, beats: int) -> dict:
    """Save a by-ear correction of a song's beat 1 in the user's link (the shared analysis is
    not touched); it applies to every later workout of theirs on the mix."""
    entry = swedebeat_map(creds, store, mix)
    shift_beat1(copy.deepcopy(entry["map"]), song_no, beats)  # raises for a song the mix lacks
    sid = entry["swedebeat_id"]
    link = store.get_link("swedebeat", sid)
    shifts = link.setdefault("beat1_shifts", {})
    total = shifts.get(str(song_no), 0) + beats
    if total:
        shifts[str(song_no)] = total
    else:
        shifts.pop(str(song_no), None)
    store.put_link("swedebeat", sid, link)
    return _entry(store.get_analysis("swedebeat", sid), link)


def summary(entry: dict, detail: str = "events") -> dict:
    """Compact map for an AI to plan with: songs, drops/breakdowns, optionally every phrase start."""
    from .workout import mmss
    m = entry["map"]
    if entry.get("source") == "spotify":
        starts = {}
        for s in m["songs"]:
            starts.setdefault(s["track"], s["start"])
        return {
            "playlist": entry["name"], "spotify_id": entry["spotify_id"], "playlist_id": entry["playlist_id"],
            "duration": mmss(entry["duration"]), "duration_sec": entry["duration"],
            "unavailable": entry.get("unavailable", []),
            "tracks": [{"track": t["track"], "title": t["title"], "artist": t["artist"], "bpm": t["bpm"],
                        "from": mmss(starts[t["track"]]), "sec": t["sec"]} for t in m["tracks"]],
            "events": [{"at": mmss(e["t"]), "t": e["t"], "kind": e["kind"], "strength": e["strength"]}
                       for e in m["events"]],
        }
    out = {
        "mix": entry["name"], "swedebeat_id": entry["swedebeat_id"], "playlist_id": entry["playlist_id"],
        "duration": mmss(entry["duration"]), "duration_sec": entry["duration"],
        "songs": [{"song": s["song"], "from": mmss(s["start"]), "to": mmss(s["end"]), "bpm": round(s["bpm"], 1),
                   "beat1_margin": s["beat1_margin"], "beat1_shift": s.get("beat1_shift", 0)}
                  for s in m["songs"]],
        "events": [{"at": mmss(e["t"]), "t": e["t"], "kind": e["kind"], "strength": e["strength"]}
                   for e in m["events"]],
    }
    if detail == "phrases":
        out["phrase_starts"] = [round(t, 2) for t in music.phrases(m)]
    return out
