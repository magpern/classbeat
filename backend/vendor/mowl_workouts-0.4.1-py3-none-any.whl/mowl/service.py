"""High-level actions shared by the MCP server and the command line."""
import copy

from . import api, library, sync, workout
from .credentials import Credentials
from .workout import mmss

LOW_MARGIN = 1.3  # below this the beat-1 vote can be a beat off (1 of 4 such songs in the Hill mix was)


def _music_opts(spec: dict) -> dict:
    opts = dict(spec.get("music") or {})
    if spec.get("swedebeat") and not opts.get("swedebeat") and not opts.get("spotify"):
        opts["swedebeat"] = spec["swedebeat"]  # older specs put the mix at the top level
    return opts


def _swedebeat_warnings(entry: dict) -> list:
    out = []
    if abs(entry["listed_duration"] - entry["duration"]) > 60:
        out.append(f"Swedebeat lists this mix as {mmss(entry['listed_duration'])} but the audio is "
                   f"{mmss(entry['duration'])}")
    unsure = [s for s in entry["map"]["songs"] if s["beat1_margin"] < LOW_MARGIN and not s.get("beat1_shift")]
    if unsure:
        out.append("beat 1 is an estimate in song " + ", ".join(
            f"{s['song']} ({mmss(s['start'])}-{mmss(s['end'])}, {s['bpm']:.0f} BPM)" for s in unsure)
            + "; listen to the first change in each and, if it is a beat early or late, fix it with correct_beat_one")
    return out


def _spotify_warnings(entry: dict) -> list:
    out = ["Spotify timing assumes the playlist plays in order from the first track, with shuffle and "
           "crossfade off in Spotify; bars are counted from Spotify's section starts"]
    out += [f"skipped: {u}" for u in entry.get("unavailable", [])]
    return out


def prepare(spec: dict, creds: Credentials, store: library.MapStore) -> dict:
    """Validate the spec and, with music, fit it to the mix. Writes nothing to the workout list
    (analysing a new mix does create its MOWL playlist, as adding it in the app would)."""
    spec = copy.deepcopy(spec)
    opts = _music_opts(spec)
    warnings, report, playlist_id, mix = [], None, -1, None
    if opts.get("swedebeat") and opts.get("spotify"):
        raise ValueError("choose either a Swedebeat mix or a Spotify playlist, not both")
    if opts.get("swedebeat") or opts.get("spotify"):
        entry = (library.swedebeat_map(creds, store, opts["swedebeat"]) if opts.get("swedebeat")
                 else library.spotify_map(creds, store, opts["spotify"]))
        playlist_id = entry["playlist_id"]
        mix = {"source": entry.get("source", "swedebeat"), "name": entry["name"],
               "duration": mmss(entry["duration"]), "playlist_id": playlist_id}
        if opts.get("snap", True):
            spec["music"] = opts
            spec, report = sync.fit_to_music(spec, entry["map"], tolerance=float(opts.get("tolerance", 6.0)))
        total = workout.total_seconds(spec) if all(isinstance(i["sec"], int) for s in spec["segments"]
                                                   for i in s["intervals"]) else 0
        if total > entry["duration"] + 1:
            warnings.append(f"the workout ({mmss(total)}) is longer than the music ({mmss(entry['duration'])}); "
                            "the rest of the ride has no music")
        warnings += _swedebeat_warnings(entry) if mix["source"] == "swedebeat" else _spotify_warnings(entry)
    for s in spec["segments"]:
        for i in s["intervals"]:
            if i.get("rpm") == "beat":
                i.pop("rpm")  # no music to take a cadence from
    spec.pop("swedebeat", None)
    workout.validate(spec)
    return {"spec": spec, "playlist_id": playlist_id, "music": mix, "timeline": report,
            "warnings": warnings, "duration": mmss(workout.total_seconds(spec)), "tss": round(workout.tss(spec), 1)}


def preview(spec: dict, creds: Credentials, store: library.MapStore) -> dict:
    return prepare(spec, creds, store)


def save(spec: dict, creds: Credentials, store: library.MapStore, program_id: int | None = None) -> dict:
    plan = prepare(spec, creds, store)
    result = workout.save(plan["spec"], creds, plan["playlist_id"], program_id)
    saved = workout.summarize(api.get_workout(creds, result["program_id"]))
    return {**result, "workout": saved, "timeline": plan["timeline"], "warnings": plan["warnings"]}
