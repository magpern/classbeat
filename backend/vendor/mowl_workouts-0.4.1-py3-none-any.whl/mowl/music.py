"""Music map of a DJ mix: songs, exact beat grids, bar and phrase starts, drops and breakdowns.

How it works (validated against the Hill 30min mix, where the user confirmed the
changes land on beat 1):
1. Kick onsets: rectified rise of low-band (< 150 Hz) energy, about 6 ms resolution.
2. Tempo over time: in 16 s windows, fit the beat grid (BPM + phase) the kicks line up with best.
   Tempos are folded into 78-160 BPM, so 74 reads as 148 and 170 as 85.
3. Songs: consecutive windows with the same grid; each song then gets one exact grid
   fitted over its whole length (DJ mixes keep each song at a constant tempo).
4. Beat 1: drops and breakdowns (bass in or out over 2 bars) fall on bar starts, so the
   beat position they favour gives each song's downbeat; their bar spacing gives the
   8-bar phrase starts.
"""
import numpy as np

SR = 11025
N_FFT = 1024
HOP = 64
LOW_HZ = 150.0
BPM_MIN, BPM_MAX = 78.0, 160.0
WIN, STEP = 16.0, 4.0
RELIABLE = 1.35  # beat-grid kick strength vs the window average needed to trust a window
EVENT_MIN = 0.35  # log energy change over 2 bars needed to call a drop or breakdown
PHRASE_BARS = 8
MAP_VERSION = 12  # bump when the map format or analysis changes; older caches are redone
KICK_LAG = 0.041  # s; onset-curve delay measured on synthetic kicks at 85-140 BPM
PLATEAU = 0.2  # log energy; changes this close to the strongest count as the same change


# --- features -----------------------------------------------------------------

def features(y: np.ndarray, sr: int = SR) -> dict:
    """Per-frame kick onset strength, bass power and total power, computed in chunks
    so an hour-long mix fits in memory."""
    import librosa
    window = np.hanning(N_FFT).astype(np.float32)
    freqs = librosa.fft_frequencies(sr=sr, n_fft=N_FFT)
    low = freqs < LOW_HZ
    n_frames = max(0, 1 + (len(y) - N_FFT) // HOP)
    low_db = np.empty((n_frames, int(low.sum())), np.float32)
    bass = np.empty(n_frames, np.float32)
    full = np.empty(n_frames, np.float32)
    chunk = 20000
    for f0 in range(0, n_frames, chunk):
        f1 = min(n_frames, f0 + chunk)
        idx = (np.arange(f0, f1) * HOP)[:, None] + np.arange(N_FFT)[None, :]
        frames = y[idx] * window
        power = np.abs(np.fft.rfft(frames, axis=1)) ** 2
        low_db[f0:f1] = 10 * np.log10(power[:, low] + 1e-10)
        bass[f0:f1] = power[:, low].sum(axis=1)
        full[f0:f1] = power.sum(axis=1)
    kick = np.concatenate([[0.0], np.maximum(0, np.diff(low_db, axis=0)).mean(axis=1)])
    fps = sr / HOP
    times = (np.arange(n_frames) * HOP + N_FFT / 2) / sr
    # The rise in dB peaks as a kick enters the window's leading edge, before the frame centre;
    # shift the onset curve so beats land on the kick itself.
    kick = np.interp(times - KICK_LAG, times, kick)
    return {"kick": kick, "bass": bass, "full": full, "fps": fps, "times": times,
            "duration": len(y) / sr}


# --- beat grids ---------------------------------------------------------------

def fit_grid(env, times, a, b, bpms, phase_step):
    """Best (score, bpm, first beat time) for a constant grid over [a, b].
    Score is the mean onset strength on the grid divided by the mean over [a, b]."""
    sel = (times >= a) & (times <= b)
    base = env[sel].mean() + 1e-9
    best = (0.0, bpms[0], a)
    for bpm in bpms:
        p = 60.0 / bpm
        n = int((b - a) / p)
        if n < 4:
            continue
        ph = np.arange(0, p, phase_step)
        grid = a + ph[:, None] + np.arange(n)[None, :] * p
        sc = np.interp(grid, times, env).mean(axis=1) / base
        i = int(sc.argmax())
        if sc[i] > best[0]:
            best = (float(sc[i]), float(bpm), float(a + ph[i]))
    return best


def local_tempo(f: dict) -> list:
    """Beat grid per 16 s window: [{t (centre), bpm, phase, score}]."""
    kick, times, dur = f["kick"], f["times"], f["duration"]
    out = []
    for a in np.arange(0, max(dur - WIN, 0) + 1e-6, STEP):
        b = a + WIN
        s, bpm, ph = fit_grid(kick, times, a, b, np.arange(BPM_MIN, BPM_MAX, 0.25), 0.01)
        s, bpm, ph = fit_grid(kick, times, a, b, np.arange(bpm - 0.3, bpm + 0.3, 0.02), 0.002)
        out.append({"t": a + WIN / 2, "bpm": bpm, "phase": ph, "score": s})
    return out


MIN_SONG_WINDOWS = 4  # shorter stretches at an odd tempo are breakdowns or crossfades
SAME_SONG = 0.95  # merge two pieces if one grid explains their kicks this well vs one grid each
ABSORB = 0.8  # a short piece joins a neighbour whose grid explains its kicks this well
SHORT_SONG = 40.0  # s


def _same_tempo(a: float, b: float) -> bool:
    return abs(a - b) <= max(0.6, 0.005 * b)


def _runs(windows: list) -> list:
    runs = []
    for w in windows:
        if runs and _same_tempo(w["bpm"], float(np.median([x["bpm"] for x in runs[-1]]))):
            runs[-1].append(w)
        else:
            runs.append([w])
    return runs


def _grid_mean(f, bpm, phase, a, b):
    g = beats_between({"bpm": bpm, "phase": phase}, a, b)
    return (float(np.interp(g, f["times"], f["kick"]).mean()), len(g)) if len(g) else (0.0, 0)


def _fit(f, ws, bpm0=None, width=0.15, step=0.01, phase_step=0.002) -> dict:
    a, b = ws[0]["t"] - WIN / 2, ws[-1]["t"] + WIN / 2
    bpm0 = float(np.median([w["bpm"] for w in ws])) if bpm0 is None else bpm0
    s, bpm, ph = fit_grid(f["kick"], f["times"], a, b, np.arange(bpm0 - width, bpm0 + width, step), phase_step)
    mean, n = _grid_mean(f, bpm, ph, a, b)
    return {"bpm": bpm, "phase": ph, "score": s, "mean": mean, "beats": n,
            "windows": ws, "fit_start": a, "fit_end": b}


def _merge_same(f, songs) -> bool:
    for i in range(len(songs) - 1):
        a, b = songs[i], songs[i + 1]
        if not _same_tempo(a["bpm"], b["bpm"]):
            continue
        joint = _fit(f, a["windows"] + b["windows"], bpm0=(a["bpm"] * a["beats"] + b["bpm"] * b["beats"])
                     / (a["beats"] + b["beats"]))
        separate = (a["mean"] * a["beats"] + b["mean"] * b["beats"]) / (a["beats"] + b["beats"])
        if joint["mean"] >= SAME_SONG * separate:
            songs[i:i + 2] = [joint]
            return True
    return False


def _absorb_short(f, songs) -> bool:
    for i, s in enumerate(songs):
        if s["fit_end"] - s["fit_start"] >= SHORT_SONG or len(songs) == 1:
            continue
        # A breakdown with a different feel inside one song: the song's grid spans across it.
        if 0 < i < len(songs) - 1 and _same_tempo(songs[i - 1]["bpm"], songs[i + 1]["bpm"]):
            prev, nxt = songs[i - 1], songs[i + 1]
            joint = _fit(f, prev["windows"] + nxt["windows"],
                         bpm0=(prev["bpm"] * prev["beats"] + nxt["bpm"] * nxt["beats"]) / (prev["beats"] + nxt["beats"]))
            if all(_grid_mean(f, joint["bpm"], joint["phase"], x["fit_start"], x["fit_end"])[0] >= SAME_SONG * x["mean"]
                   for x in (prev, nxt)):
                songs[i - 1:i + 2] = [_fit(f, prev["windows"] + s["windows"] + nxt["windows"], bpm0=joint["bpm"])]
                return True
        for j in (i - 1, i + 1):
            if 0 <= j < len(songs):
                nb = songs[j]
                mean, _ = _grid_mean(f, nb["bpm"], nb["phase"], s["fit_start"], s["fit_end"])
                if mean >= ABSORB * s["mean"]:
                    ws = nb["windows"] + s["windows"] if j < i else s["windows"] + nb["windows"]
                    songs[min(i, j):max(i, j) + 1] = [_fit(f, ws, bpm0=nb["bpm"])]
                    return True
    return False


def group_songs(f, windows: list) -> list:
    """Split the mix into songs, each with one constant beat grid."""
    good = [w for w in windows if w["score"] >= RELIABLE]
    runs = [r for r in _runs(good) if len(r) >= MIN_SONG_WINDOWS] or _runs(good)
    # Start from short pieces and merge wherever one grid explains both as well as two do.
    songs = [_fit(f, r[i:i + MIN_SONG_WINDOWS]) for r in runs for i in range(0, len(r), MIN_SONG_WINDOWS)]
    while _merge_same(f, songs) or _absorb_short(f, songs):
        pass
    return songs


def refine_song(f, song) -> dict:
    return _fit(f, song["windows"], bpm0=song["bpm"], width=0.05, step=0.002, phase_step=0.001)


def beats_between(song, a, b) -> np.ndarray:
    p = 60.0 / song["bpm"]
    k0 = int(np.ceil((a - song["phase"]) / p))
    k1 = int(np.floor((b - song["phase"]) / p))
    return song["phase"] + np.arange(k0, k1 + 1) * p


def song_boundaries(f, songs) -> None:
    """Hand over from one song's grid to the next where the next one fits the kicks better."""
    kick, times = f["kick"], f["times"]
    songs[0]["start"] = 0.0
    for prev, nxt in zip(songs, songs[1:]):
        a, b = prev["fit_end"] - WIN / 2, nxt["fit_start"] + WIN / 2
        cut = (a + b) / 2
        for t in np.arange(a, b, 0.5):
            def fit(s):
                g = beats_between(s, t, t + 4)
                return np.interp(g, times, kick).mean() if len(g) else 0
            if fit(nxt) > fit(prev):
                cut = float(t)
                break
        prev["end"] = nxt["start"] = cut
    songs[-1]["end"] = f["duration"]


# --- bars, phrases and events -------------------------------------------------

def _span_energy(power, times, t0, t1):
    i, j = np.searchsorted(times, [t0, t1])
    return float(power[i:max(j, i + 1)].mean()) if i < len(power) else float(power[-1])


EDGE = 8.0  # s; a song's own breakdown can come just after the next song takes over, and a drop just before


def _bar_rows(f, song, a, b):
    """Energy change over 2 bars either side of every beat in [a, b]: (k, t, strength, up, accent)."""
    p = 60.0 / song["bpm"]
    bar = 4 * p
    rows = []
    for k in range(int(np.ceil((a - song["phase"]) / p)), int(np.floor((b - song["phase"]) / p)) + 1):
        t = song["phase"] + k * p
        if t - 2 * bar < 0 or t + 2 * bar > f["duration"]:
            continue
        def change(x):
            return (np.log(_span_energy(x, f["times"], t, t + 2 * bar) + 1e-10)
                    - np.log(_span_energy(x, f["times"], t - 2 * bar, t) + 1e-10))
        cb, cf = change(f["bass"]), change(f["full"])
        accent = np.interp(t, f["times"], f["kick"])
        rows.append((k, t, abs(cb) + 0.5 * abs(cf), cb > 0, accent))
    return rows


def _bar_change(f, t, bar, up) -> float:
    """Bass change over one bar either side of t, in the event's direction."""
    if t - bar < 0 or t + bar > f["duration"]:
        return -np.inf
    d = (np.log(_span_energy(f["bass"], f["times"], t, t + bar) + 1e-10)
         - np.log(_span_energy(f["bass"], f["times"], t - bar, t) + 1e-10))
    return d if up else -d


def _peaks(rows, floor=0.15):
    return [r for n, r in enumerate(rows)
            if r[2] >= floor and all(r[2] >= rows[m][2] for m in range(max(0, n - 3), min(len(rows), n + 4)))]


def downbeats_and_events(f, song) -> list:
    """Find the song's drops and breakdowns, each on its own most precise beat, and take
    the song's beat 1 (and 8-bar phrase start) from where they fall."""
    p = 60.0 / song["bpm"]
    bar = 4 * p
    rows = _bar_rows(f, song, song["start"] - EDGE, song["end"] + EDGE)
    found = []
    for k, t, s, up, _ in _peaks(rows):
        if s < EVENT_MIN:
            continue
        # The 2-bar comparison finds the change to within a beat or so; refine it over one bar
        # either side. In log energy the loud side dominates: a beat before a drop scores
        # nearly as high as the drop (the bar after it is mostly loud already), and a beat
        # after a breakdown nearly as high as the breakdown. So among beats within PLATEAU
        # of the strongest, a drop starts on the last and a breakdown on the first.
        cands = [(q, _bar_change(f, song["phase"] + q * p, bar, up)) for q in (k - 1, k, k + 1)]
        best = max(c for _, c in cands)
        near = [q for q, c in cands if c >= best - PLATEAU] if np.isfinite(best) else [k]
        kk = near[-1] if up else near[0]
        td = song["phase"] + kk * p
        own = song["start"] <= td <= song["end"] or (td < song["start"] and up) or (td > song["end"] and not up)
        if own:
            found.append((kk, td, s, up))
    votes = np.zeros(4)
    for kk, td, s, _ in found:
        if song["start"] <= td <= song["end"]:
            votes[kk % 4] += s
    r = int(votes.argmax())
    ranked = np.sort(votes)
    # how far the chosen beat 1 is ahead of the runner-up (1.0 = a coin toss)
    song["beat1_margin"] = round(float(ranked[-1] / ranked[-2]), 2) if ranked[-2] > 0 else 9.99
    phrase_votes = np.zeros(PHRASE_BARS)
    for kk, td, s, _ in found:
        if kk % 4 == r and song["start"] <= td <= song["end"]:
            phrase_votes[((kk - r) // 4) % PHRASE_BARS] += s
    q = int(phrase_votes.argmax())
    k_first = int(np.ceil((song["start"] - song["phase"]) / p))
    song["first_downbeat"] = song["phase"] + (r + 4 * int(np.ceil((k_first - r) / 4))) * p
    k_phrase = r + 4 * q
    step = 4 * PHRASE_BARS
    song["first_phrase"] = song["phase"] + (k_phrase + step * int(np.ceil((k_first - k_phrase) / step))) * p
    # Changes in a DJ mix start on beat 1: put each on the song's nearest bar start, then
    # keep the bar (one either way) with the sharpest 1-bar change.
    placed = []
    for kk, raw, s, up in found:
        kd = r + 4 * int(round((kk - r) / 4))
        kd = max((kd - 4, kd, kd + 4), key=lambda q: _bar_change(f, song["phase"] + q * p, bar, up))
        placed.append((kd, song["phase"] + kd * p, s, up, raw))
    kept = []
    for kk, td, s, up, raw in sorted(placed, key=lambda e: -e[2]):
        if all(abs(td - x["t"]) >= 2 * bar - 1e-6 for x in kept):
            # "precise" is where the change itself was found, before placing it on a bar start
            kept.append({"t": round(float(td), 3), "precise": round(float(raw), 3),
                         "kind": "drop" if up else "breakdown", "strength": round(float(s), 2)})
    return sorted(kept, key=lambda e: e["t"])


def analyze_signal(y: np.ndarray, sr: int = SR) -> dict:
    f = features(y, sr)
    windows = local_tempo(f)
    groups = group_songs(f, windows)
    if not groups:
        raise ValueError("no steady beat found in the music")
    songs = [refine_song(f, g) for g in groups]
    song_boundaries(f, songs)
    events = []
    for n, s in enumerate(songs):
        for e in downbeats_and_events(f, s):
            events.append({**e, "song": n + 1})
    # Near a hand-over both songs may report the same change. A breakdown there is the
    # outgoing song's bass leaving and a drop the incoming song's arriving, so keep the
    # copy from that song (timed on its grid); elsewhere keep the stronger.
    def owner_first(e):
        return (-e["song"] if e["kind"] == "breakdown" else e["song"]), -e["strength"]
    kept = []
    for e in sorted(events, key=lambda e: -e["strength"]):
        rival = next((x for x in kept if abs(x["precise"] - e["precise"]) < 2.5 and x["kind"] == e["kind"]
                      and x["song"] != e["song"]), None)
        if rival and owner_first(e) < owner_first(rival):
            kept[kept.index(rival)] = e
        elif not rival and all(abs(e["t"] - x["t"]) >= 1.5 for x in kept):
            kept.append(e)
    events = sorted(kept, key=lambda e: e["t"])
    return {
        "version": MAP_VERSION, "duration": round(f["duration"], 3),
        "songs": [{"song": n + 1, "start": round(s["start"], 3), "end": round(s["end"], 3),
                   "bpm": round(s["bpm"], 3), "first_downbeat": round(s["first_downbeat"], 4),
                   "first_phrase": round(s["first_phrase"], 4), "phrase_bars": PHRASE_BARS,
                   "grid_score": round(s["score"], 2), "beat1_margin": s["beat1_margin"]}
                  for n, s in enumerate(songs)],
        "events": events,
    }


def analyze_file(path: str) -> dict:
    import librosa
    y, sr = librosa.load(path, sr=SR, mono=True)
    return analyze_signal(y.astype(np.float32), sr)


# --- using a map --------------------------------------------------------------

def song_at(music: dict, t: float) -> dict:
    for s in music["songs"]:
        if s["start"] <= t < s["end"]:
            return s
    return music["songs"][-1] if t >= music["songs"][-1]["start"] else music["songs"][0]


def grid_points(song: dict, every_beats: int, first: float, a: float, b: float) -> list:
    step = every_beats * 60.0 / song["bpm"]
    n0 = int(np.ceil((a - first) / step))
    n1 = int(np.floor((b - first) / step))
    return [first + n * step for n in range(n0, n1 + 1)]


def downbeats(music: dict, a: float = 0.0, b: float | None = None) -> list:
    b = music["duration"] if b is None else b
    out = []
    for s in music["songs"]:
        lo, hi = max(a, s["start"]), min(b, s["end"])
        if lo < hi:
            out += grid_points(s, 4, s["first_downbeat"], lo, hi)
    return out


def phrases(music: dict, a: float = 0.0, b: float | None = None) -> list:
    b = music["duration"] if b is None else b
    out = []
    for s in music["songs"]:
        lo, hi = max(a, s["start"]), min(b, s["end"])
        if lo < hi:
            out += grid_points(s, 4 * s["phrase_bars"], s["first_phrase"], lo, hi)
    return out
