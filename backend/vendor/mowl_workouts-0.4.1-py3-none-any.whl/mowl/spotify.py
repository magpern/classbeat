"""Music map of a Spotify playlist, built from what MOWL knows about it.

MOWL cannot give the audio of Spotify tracks, but it gives each track's exact length and
BPM, and relays Spotify's section analysis (start, duration, loudness; no beats). So:
- track changes are exact (assuming the player plays the playlist in order, without
  shuffle or crossfade);
- each section starts a new bar grid, since Spotify's sections start on bar starts and an
  integer BPM would drift over a whole track; each section is one "song" entry in the map;
- a section boundary that gets clearly louder is a drop, clearly quieter a breakdown.
"""
from . import music

SECTION_DB = 3.0  # loudness change between sections (dB) that counts as a drop or breakdown
TRACK_STRENGTH = 9.0  # a new track outranks any section change when snapping


def build_map(tracks: list, sections: dict) -> dict:
    """tracks: MOWL playlist tracks in play order; sections: SpotifyTrackID -> sections."""
    entries, events, t0 = [], [], 0.0
    for n, tr in enumerate(tracks, 1):
        dur = tr["Duration"] / 1000.0
        bpm = float(tr.get("BPM") or 0) or 120.0
        secs = [s for s in sections.get(tr["SpotifyTrackID"]) or [] if s["start"] < dur - 0.5]
        if not secs or secs[0]["start"] > 0.5:
            secs = [{"start": 0.0, "duration": dur, "loudness": None}] + secs
        for i, s in enumerate(secs):
            a = t0 + s["start"]
            b = t0 + (secs[i + 1]["start"] if i + 1 < len(secs) else dur)
            entries.append({"song": len(entries) + 1, "track": n, "start": round(a, 3), "end": round(b, 3),
                            "bpm": bpm, "bpm_known": bool(tr.get("BPM")), "first_downbeat": round(a, 3),
                            "first_phrase": round(a, 3), "phrase_bars": music.PHRASE_BARS,
                            "beat1_margin": None, "beat1_source": "spotify section"})
            if i == 0:
                if n > 1:
                    events.append({"t": round(a, 3), "kind": "track", "strength": TRACK_STRENGTH,
                                   "song": entries[-1]["song"]})
            elif s.get("loudness") is not None and secs[i - 1].get("loudness") is not None:
                d = s["loudness"] - secs[i - 1]["loudness"]
                if abs(d) >= SECTION_DB:
                    events.append({"t": round(a, 3), "kind": "drop" if d > 0 else "breakdown",
                                   "strength": round(abs(d) / SECTION_DB, 2), "song": entries[-1]["song"]})
        t0 += dur
    return {"version": music.MAP_VERSION, "source": "spotify", "duration": round(t0, 3),
            "songs": entries, "events": events,
            "tracks": [{"track": n, "title": tr["Title"], "artist": tr["Artist"], "bpm": tr.get("BPM"),
                        "spotify_id": tr["SpotifyTrackID"], "sec": round(tr["Duration"] / 1000.0, 3)}
                       for n, tr in enumerate(tracks, 1)]}
