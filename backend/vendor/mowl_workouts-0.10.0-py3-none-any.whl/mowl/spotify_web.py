"""Spotify Web API: find songs and build playlists for a class.

Sign-in is the Authorization Code flow with PKCE (no client secret): the user approves
once in their own browser. The client ID, access token and refresh token live in the
caller's `Credentials`; this module reads and writes no files (a renewed token is passed to
`creds.on_spotify_token`).
Spotify's Development Mode limits apply: search returns at most 10 results per call,
and BPM / audio features are not available to new apps; MOWL supplies those instead.

A hosted app addresses playlists only by ID: `create_playlist` (always a new private one),
`add_items`, `replace_playlist_items`, `get_playlist`, `playlist_items`. Lists are read by
`offset` and `total`; a `next` URL from a response is never requested, and every id from a
response is validated before it goes into a path or a URI.
"""
import base64
import hashlib
import http.server
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from .credentials import Credentials
from .errors import MowlError
from .spotify import SPOTIFY_ID, track_uri

ACCOUNTS = "https://accounts.spotify.com/"
API = "https://api.spotify.com/v1/"
SCOPES = "playlist-read-private playlist-modify-private playlist-modify-public"  # the CLI may make one public
SCOPES_PRIVATE = "playlist-read-private playlist-modify-private"  # hosted use: nothing is ever public
SEARCH_LIMIT = 10  # Development Mode maximum
PAGE = 50  # /items and /me/playlists pages hold at most 50
MAX_ITEMS = 1000  # a hosted read fails above this rather than truncating
MAX_LIST_PAGES = 20
CLI_MAX_ITEMS = 10000  # Spotify's own playlist limit
CLI_MAX_LIST_PAGES = 200
MARKET = re.compile(r"[A-Z]{2}")
VERSION_WORDS = re.compile(r"\b(live|karaoke|instrumental|cover|tribute|re-?recorded|acoustic|demo|8-bit)\b", re.I)
PLAYLIST_FIELDS = "id,name,description,public,collaborative,snapshot_id,owner(id),items(total)"


def _post_form(url: str, form: dict) -> dict:
    req = urllib.request.Request(url, data=urllib.parse.urlencode(form).encode(), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        raise MowlError(f"Spotify sign-in failed: HTTP {e.code} {_reason(e)}", status=e.code) from e


def _with_expiry(tok: dict) -> dict:
    return {**tok, "expires_at": time.time() + tok.get("expires_in", 3600) - 60}


def connect(creds: Credentials, timeout: float = 300, open_browser=webbrowser.open) -> dict:
    """Open Spotify's consent page in the user's browser and wait for them to approve. The
    page is also served at /start on the callback address, for a tab to be sent on to it.
    The new tokens are set on `creds` (and passed to its on_spotify_token). Needs
    creds.spotify_client_id. Returns who signed in; never a token."""
    if not creds.spotify_client_id:
        raise MowlError("No Spotify app configured; set the Client ID first (mowl connect spotify)")
    if not creds.spotify_refresh_enabled:
        raise MowlError("Spotify sign-in is disabled for these credentials; their owner connects Spotify")
    redirect = urllib.parse.urlparse(creds.spotify_redirect_uri)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    result = {}

    class Callback(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if self.path == "/start":
                self.send_response(302)
                self.send_header("Location", url)
                self.end_headers()
                return
            if urllib.parse.urlparse(self.path).path != redirect.path:
                self.send_response(404)
                self.end_headers()
                return
            if q.get("state", [""])[0] == state:
                result.update({k: v[0] for k, v in q.items()})
            ok = "code" in result
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(("Spotify is connected; you can close this tab." if ok
                              else "Spotify was not connected.").encode())

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer((redirect.hostname, redirect.port), Callback)
    server.timeout = 1
    url = ACCOUNTS + "authorize?" + urllib.parse.urlencode({
        "client_id": creds.spotify_client_id, "response_type": "code", "redirect_uri": creds.spotify_redirect_uri,
        "code_challenge_method": "S256", "code_challenge": challenge, "scope": SCOPES, "state": state})
    threading.Thread(target=open_browser, args=(url,), daemon=True).start()
    deadline = time.monotonic() + timeout
    try:
        while "code" not in result and "error" not in result and time.monotonic() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if "code" not in result:
        raise MowlError(f"Spotify was not connected ({result.get('error', 'no answer in time')}); "
                        f"open this page to try again: {url}")
    tok = _post_form(ACCOUNTS + "api/token", {
        "grant_type": "authorization_code", "code": result["code"], "redirect_uri": creds.spotify_redirect_uri,
        "client_id": creds.spotify_client_id, "code_verifier": verifier})
    creds.set_spotify_tokens(_with_expiry(tok))
    me = call(creds, "GET", "me")
    return {"connected_as": me.get("display_name") or me.get("id"), "product": me.get("product")}


def _access_token(creds: Credentials) -> str:
    with creds.lock:  # one refresh at a time per user; other users' credentials are unaffected
        if not creds.spotify_access_token and not creds.spotify_refresh_token:
            raise MowlError("Spotify is not connected yet; run connect_spotify first")
        if creds.spotify_access_token and time.time() < creds.spotify_expires_at:
            return creds.spotify_access_token
        if not creds.spotify_refresh_enabled:  # the owner refreshes; never the token endpoint from here
            raise MowlError("Spotify access token expired; renewal is disabled for these credentials")
        if not creds.spotify_refresh_token or not creds.spotify_client_id:
            raise MowlError("Spotify sign-in expired; run connect_spotify again")
        new = _post_form(ACCOUNTS + "api/token", {"grant_type": "refresh_token",
                                                   "refresh_token": creds.spotify_refresh_token,
                                                   "client_id": creds.spotify_client_id})
        creds.set_spotify_tokens(_with_expiry(new))  # Spotify may or may not rotate the refresh token
        return creds.spotify_access_token


def _reason(e: urllib.error.HTTPError) -> str:
    """Spotify's short error message, if the body has one; never the raw body."""
    try:
        msg = json.loads(e.read()[:2000]).get("error")
        msg = msg.get("message") if isinstance(msg, dict) else msg
    except Exception:  # no body, not JSON, not an object: nothing worth showing
        return ""
    return re.sub(r"[^\x20-\x7e]", "", msg)[:120] if isinstance(msg, str) else ""


def _retry_after(e: urllib.error.HTTPError) -> int | None:
    try:
        return max(0, int((e.headers or {}).get("Retry-After")))
    except (TypeError, ValueError):
        return None


def call(creds: Credentials, method: str, path: str, params: dict | None = None, body=None):
    url = API + path + ("?" + urllib.parse.urlencode(params) if params else "")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {_access_token(creds)}", "Content-Type": "application/json"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            wait = _retry_after(e) if e.code == 429 else None
            max_wait = creds.spotify_max_retry_wait
            if e.code == 429 and attempt < 2 and max_wait > 0:  # rate limited: wait as told
                time.sleep(min(max_wait, 2 if wait is None else wait))
                continue
            raise MowlError(f"Spotify {method} {path}: HTTP {e.code} {_reason(e)}".rstrip(),
                            status=e.code, retry_after=wait) from e


def _pages(creds: Credentials, path: str, max_items: int, params: dict | None = None) -> list:
    """Every entry of a paged list, read by offset until `total`; over `max_items` fails
    rather than truncating. The page's `next` URL is never followed."""
    out = []
    while True:
        page = call(creds, "GET", path, {**(params or {}), "limit": PAGE, "offset": len(out)})
        items, total = (page.get("items"), page.get("total")) if isinstance(page, dict) else (None, None)
        if not isinstance(items, list) or not isinstance(total, int) or isinstance(total, bool):
            raise MowlError(f"Spotify GET {path}: not a page of items")
        if total > max_items or len(out) + len(items) > max_items:
            raise MowlError(f"Spotify GET {path}: more than {max_items} entries")
        out += items
        if not items or len(out) >= total:
            return out


def _valid_id(value) -> str | None:
    return value if isinstance(value, str) and SPOTIFY_ID.fullmatch(value) else None


def _get(obj, key: str):
    """obj[key] when obj is a JSON object, else None: an answer of another shape reads as missing."""
    return obj.get(key) if isinstance(obj, dict) else None


# --- songs ------------------------------------------------------------------------

MIN_IMAGE_WIDTH = 64


def _album_image(album) -> str | None:
    """The URL of the album's narrowest image at least MIN_IMAGE_WIDTH px wide, else None."""
    return _smallest_image(_get(album, "images"))


def _smallest_image(images) -> str | None:
    """The URL of the narrowest image in a Spotify `images` list at least MIN_IMAGE_WIDTH px
    wide, else None. An image without an integer width, or without a non-empty string URL, is
    skipped rather than guessed at. Equal widths keep the first in Spotify's order. The URL is
    only passed on, never requested; the caller checks its host before using it."""
    best = None
    for img in images if isinstance(images, list) else []:
        url, w = _get(img, "url"), _get(img, "width")
        if (isinstance(url, str) and url and isinstance(w, int) and not isinstance(w, bool)
                and w >= MIN_IMAGE_WIDTH and (best is None or w < best[0])):
            best = (w, url)
    return best[1] if best else None


def _playlist_image(images) -> str | None:
    """A playlist's image URL: by _smallest_image's rule, except that when no image in the list
    carries a width (Spotify lists a cover the owner uploaded with `width: null`) it is the
    first image with a non-empty string URL. An image whose width is present but not an int
    counts as carrying one, so the 64 px rule then applies. Never requested, not host-checked."""
    entries = [img for img in images if isinstance(img, dict)] if isinstance(images, list) else []
    if any(img.get("width") is not None for img in entries):
        return _smallest_image(entries)
    return next((u for u in (img.get("url") for img in entries) if isinstance(u, str) and u), None)


def _track(t) -> dict | None:
    """A playable track's fields, or None for anything else (null, an episode, a local file,
    a track without a valid id). The URI is rebuilt from the id."""
    if not isinstance(t, dict) or t.get("type", "track") != "track" or t.get("is_local"):
        return None
    tid = _valid_id(t.get("id"))
    if not tid:
        return None
    album = t.get("album") if isinstance(t.get("album"), dict) else {}
    release = album.get("release_date") if isinstance(album.get("release_date"), str) else ""
    ms = t.get("duration_ms")
    ms = ms if isinstance(ms, int) and not isinstance(ms, bool) else None
    return {"uri": track_uri(tid), "id": tid, "title": t.get("name") or "",
            "artists": [a["name"] for a in t.get("artists") or [] if isinstance(a, dict) and a.get("name")],
            "album": album.get("name"), "year": release[:4], "sec": None if ms is None else round(ms / 1000),
            "duration_ms": ms, "release_date": release or None, "image": _album_image(album)}


def search_tracks(creds: Credentials, query: str, limit: int = SEARCH_LIMIT, market: str | None = None) -> list:
    """Tracks matching the query (at most 10). market, a country code like "SE", is sent only
    when given; Spotify then uses the account's own market."""
    params = {"q": query, "type": "track", "limit": max(1, min(limit, SEARCH_LIMIT))}
    if market is not None:
        if not isinstance(market, str) or not MARKET.fullmatch(market):
            raise MowlError(f"not a market code: {market!r}")
        params["market"] = market
    data = call(creds, "GET", "search", params)
    items = _get(_get(data, "tracks"), "items") or []
    return [x for x in map(_track, items) if x]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def best_match(wanted_artist: str, wanted_title: str, candidates: list) -> dict | None:
    """The candidate by the wanted artist whose title matches best, avoiding live, karaoke,
    cover and similar versions unless the wanted title asks for one."""
    artist, title = _norm(wanted_artist), _norm(wanted_title)

    def score(c):
        if not any(artist in _norm(a) or _norm(a) in artist for a in c["artists"]):
            return None
        t = _norm(c["title"])
        s = 3 if t == title else 2 if t.startswith(title) else 1 if title in t else 0
        if not s:
            return None
        if VERSION_WORDS.search(c["title"]) and not VERSION_WORDS.search(wanted_title):
            s -= 2.5
        if "remaster" in t:
            s -= 0.1  # fine, but prefer the original release when both exist
        return s
    scored = [(score(c), n, c) for n, c in enumerate(candidates)]
    scored = [x for x in scored if x[0] is not None and x[0] > 0]
    return max(scored, key=lambda x: (x[0], -x[1]))[2] if scored else None


def find_songs(creds: Credentials, songs: list, years: str = "") -> dict:
    """Resolve [{"artist", "title"}] to Spotify tracks. years like "1990-1999" narrows the search,
    falling back to an unrestricted search when the song was re-released later."""
    found, missing = [], []
    for s in songs:
        base = f'track:"{s["title"]}" artist:"{s["artist"]}"'
        hit = None
        for q in ([f"{base} year:{years}"] if years else []) + [base, f'{s["artist"]} {s["title"]}']:
            hit = best_match(s["artist"], s["title"], search_tracks(creds, q))
            if hit:
                break
        if hit:
            found.append({**{k: v for k, v in s.items() if k not in ("artist", "title")}, **hit,
                          "wanted": f'{s["artist"]} - {s["title"]}'})
        else:
            missing.append(s)
    return {"found": found, "missing": missing}


# --- playlists --------------------------------------------------------------------

def _check_id(playlist_id: str) -> str:
    if not _valid_id(playlist_id):
        raise MowlError(f"not a Spotify playlist ID: {playlist_id!r}")
    return playlist_id


def _uris(uris) -> list:
    uris = list(uris)
    if not all(isinstance(u, str) for u in uris):
        raise MowlError("track URIs must be strings")
    return uris


def me(creds: Credentials) -> dict:
    """The signed-in Spotify user's id, and nothing else about them."""
    uid = _get(call(creds, "GET", "me"), "id")
    if not isinstance(uid, str) or not 1 <= len(uid) <= 100 or not uid.isprintable():
        raise MowlError("Spotify GET me: no valid user id")
    return {"id": uid}


def my_playlists(creds: Credentials, max_pages: int = MAX_LIST_PAGES) -> list:
    """The user's playlists (own and followed): id, name, description, owner_id, public,
    collaborative and image (see _playlist_image). Entries without a valid id are left out."""
    out = []
    for p in _pages(creds, "me/playlists", max_pages * PAGE):
        pid = _valid_id(p.get("id")) if isinstance(p, dict) else None
        if pid:
            owner = p.get("owner") if isinstance(p.get("owner"), dict) else {}
            out.append({"id": pid, "name": p.get("name") or "", "description": p.get("description") or "",
                        "owner_id": owner.get("id"), "public": p.get("public"),
                        "collaborative": p.get("collaborative"), "image": _playlist_image(p.get("images"))})
    return out


def get_playlist(creds: Credentials, playlist_id: str) -> dict:
    """One playlist's owner, privacy and version, for checking it before a write."""
    pid = _check_id(playlist_id)
    p = call(creds, "GET", f"playlists/{pid}", {"fields": PLAYLIST_FIELDS})
    if not isinstance(p, dict) or p.get("id") != pid:
        raise MowlError(f"Spotify GET playlists/{pid}: answered for another playlist")
    owner = p.get("owner") if isinstance(p.get("owner"), dict) else {}
    # The Feb 2026 API names the contents `items`; older answers called them `tracks`.
    total = _get(p.get("items"), "total") if isinstance(p.get("items"), dict) else _get(p.get("tracks"), "total")
    return {"id": pid, "name": p.get("name"), "description": p.get("description"), "public": p.get("public"),
            "collaborative": p.get("collaborative"), "snapshot_id": p.get("snapshot_id"),
            "owner_id": owner.get("id"), "total": total}


def _entry(e) -> dict:
    """One playlist entry: a track's fields with playable True, or a marker (playable False)
    for a null entry, an episode, a local file or a track without a valid id."""
    t = (e.get("item") if "item" in e else e.get("track")) if isinstance(e, dict) else None
    local = bool(isinstance(e, dict) and e.get("is_local")) or bool(isinstance(t, dict) and t.get("is_local"))
    hit = None if local else _track(t)
    if hit:
        return {"id": hit["id"], "uri": hit["uri"], "name": hit["title"], "artists": hit["artists"],
                "album": hit["album"], "release_date": hit["release_date"], "duration_ms": hit["duration_ms"],
                "image": hit["image"], "type": "track", "is_local": False, "playable": True}
    kind = t.get("type") if isinstance(t, dict) and isinstance(t.get("type"), str) else None
    return {"id": None, "uri": None, "name": None, "artists": [], "album": None, "release_date": None,
            "duration_ms": None, "image": None, "type": kind, "is_local": local, "playable": False}


def playlist_items(creds: Credentials, playlist_id: str, max_items: int = MAX_ITEMS) -> list:
    """Every entry of the playlist with exactly this ID, in order (see _entry). Spotify
    returns contents only for playlists the user owns or collaborates on."""
    pid = _check_id(playlist_id)
    return [_entry(e) for e in _pages(creds, f"playlists/{pid}/items", max_items)]


playlist_tracks = playlist_items  # the 0.5 name


def find_playlist_tracks(creds: Credentials, playlist: str) -> list:
    """For the CLI: the playable tracks of a Spotify playlist given by 22-char ID or by the
    name of one of the user's playlists."""
    pid = str(playlist).strip()
    if not SPOTIFY_ID.fullmatch(pid):
        match = next((p for p in my_playlists(creds, CLI_MAX_LIST_PAGES) if p["name"].lower() == pid.lower()), None)
        if not match:
            raise MowlError(f"no Spotify playlist named {playlist!r}")
        pid = match["id"]
    return [t for t in playlist_items(creds, pid, CLI_MAX_ITEMS) if t["playable"]]


def add_items(creds: Credentials, playlist_id: str, uris) -> str | None:
    """Append the tracks, in order, to the playlist with exactly this ID; returns the last
    snapshot_id (None when there was nothing to add)."""
    pid, uris, snap = _check_id(playlist_id), _uris(uris), None
    for i in range(0, len(uris), 100):  # the API takes at most 100 per call
        snap = _get(call(creds, "POST", f"playlists/{pid}/items", body={"uris": uris[i:i + 100]}), "snapshot_id")
    return snap


def _new_playlist(creds: Credentials, name: str, description: str, public: bool) -> str:
    out = call(creds, "POST", "me/playlists", body={
        "name": name, "description": description, "public": public, "collaborative": False})
    pid = _valid_id(_get(out, "id"))
    if not pid:
        raise MowlError("Spotify POST me/playlists: no valid playlist id in the answer")
    return pid


def create_playlist(creds: Credentials, name: str, uris=(), description: str = "") -> str:
    """Create a new private, non-collaborative playlist and return its ID; with `uris` it is
    then filled in this order (empty creates it only). Always new: it never looks at existing
    playlists, so it is safe for a server that must not touch a playlist it did not create."""
    uris = _uris(uris)
    pid = _new_playlist(creds, name, description, public=False)
    add_items(creds, pid, uris)
    return pid


def replace_playlist_items(creds: Credentials, playlist_id: str, uris) -> str | None:
    """Replace every track of the playlist with exactly this ID by `uris`, in order (an empty
    list clears it); returns the last snapshot_id."""
    pid, uris = _check_id(playlist_id), _uris(uris)
    snap = _get(call(creds, "PUT", f"playlists/{pid}/items", body={"uris": uris[:100]}), "snapshot_id")
    return add_items(creds, pid, uris[100:]) or snap


def save_playlist(creds: Credentials, name: str, uris: list, description: str = "", public: bool = False) -> dict:
    """Name-based helper for the CLI and the local MCP server only: replace the songs of the
    user's own playlist with that name, or create it, so re-running a design reuses one playlist
    instead of piling up new ones. Hosted apps should store IDs and use create_playlist and
    replace_playlist_items instead."""
    uid = me(creds)["id"]
    existing = next((p for p in my_playlists(creds, CLI_MAX_LIST_PAGES)
                     if p["name"] == name and p["owner_id"] == uid), None)
    if existing:
        pid = existing["id"]
        replace_playlist_items(creds, pid, uris)
    else:
        pid = _new_playlist(creds, name, description, public)
        add_items(creds, pid, uris)
    return {"spotify_id": pid, "name": name, "tracks": len(uris), "replaced": bool(existing)}
