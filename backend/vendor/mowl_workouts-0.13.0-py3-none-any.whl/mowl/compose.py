"""Compose per-track maps into one mix map, and the sample offsets that render it.

Pure functions, no I/O. `compose_map` (timing for `sync.fit_to_music`) and `mix_offsets`
(sample positions for the renderer) both come from `_layout`, so the map and the audio
cannot drift apart. Cuts are stored rounded to 0.01 s (the app's precision), so all the
arithmetic is in whole hundredths of a second; crossfades are whole seconds.

One duration rule: the sum of the played windows minus the sum of the crossfades.
"""
import math

from . import music

CS = 100  # hundredths of a second per second
EPS = 1e-6


def _cs(sec: float) -> int:
    return int(round(float(sec) * CS))


def samples(sec: float, sample_rate: int) -> int:
    """Seconds to samples, half up, from whole hundredths in integer arithmetic. The one
    conversion for offsets and for reading a composed map's times back as samples."""
    return (2 * _cs(sec) * sample_rate + CS) // (2 * CS)


def _clamp(a: int, b: int, dur_cs: int | None) -> int:
    """A window's end, clamped to the file when its length is known (0.01 s of slack for
    the cut rounding; further past the end is an error)."""
    if dur_cs is None or b <= dur_cs:
        return b
    if b > dur_cs + 1:
        raise ValueError("window ends at %.2f s, after the track (%.2f s)" % (b / CS, dur_cs / CS))
    if dur_cs <= a:
        raise ValueError("window starts at the end of the track")
    return dur_cs


def _layout(spec: dict, durations: list | None = None) -> list:
    """Per track, in hundredths of a second: {index, src_start, src_end, dst_start,
    fade_in, fade_out}. dst_start is where the window starts in the mix. `durations`
    (seconds per track, when known) clamps each window's end to its file."""
    tracks, cfs = spec["tracks"], list(spec.get("crossfades") or [])
    if not tracks:
        raise ValueError("a mix needs at least one track")
    if len(cfs) != len(tracks) - 1:
        raise ValueError("one crossfade per transition: %d tracks need %d crossfades"
                         % (len(tracks), len(tracks) - 1))
    wins = []
    for n, t in enumerate(tracks):
        a, b = _cs(t["start_sec"]), _cs(t["end_sec"])
        if not 0 <= a < b:
            raise ValueError("track %d: need 0 <= start_sec < end_sec" % n)
        if durations is not None:
            b = _clamp(a, b, _cs(durations[n]))
        wins.append((a, b))
    if any(float(c) != int(c) for c in cfs):
        raise ValueError("crossfades are whole seconds")
    cf = [int(c) * CS for c in cfs]
    for n, c in enumerate(cf):
        if c < 0 or c >= min(wins[n][1] - wins[n][0], wins[n + 1][1] - wins[n + 1][0]):
            raise ValueError("crossfade %d must be >= 0 and shorter than both neighbouring windows" % n)
    for n in range(1, len(wins) - 1):
        if cf[n - 1] + cf[n] >= wins[n][1] - wins[n][0]:
            raise ValueError("track %d: incoming plus outgoing crossfade must be shorter than its window" % n)
    out, dst = [], 0
    for n, (a, b) in enumerate(wins):
        out.append({"index": n, "src_start": a, "src_end": b, "dst_start": dst,
                    "fade_in": cf[n - 1] if n else 0, "fade_out": cf[n] if n < len(cf) else 0})
        dst += (b - a) - (cf[n] if n < len(cf) else 0)
    return out


def _total_cs(lay: list) -> int:
    last = lay[-1]
    return last["dst_start"] + last["src_end"] - last["src_start"]


def _next_on_grid(first: float, period: float, at: float) -> float:
    """The first point of the grid first + n * period at or after `at` (n may be negative)."""
    n = math.ceil((at - first) / period - EPS)
    return first + n * period


def _cut(track_map: dict, a_cs: int, b_cs: int, dst_cs: int = 0, track: int | None = None,
         first_song: int = 1) -> dict:
    """The map cut to [a, b) and moved so a lands on dst. Times in seconds, 3 decimals."""
    a, b, dst = a_cs / CS, b_cs / CS, dst_cs / CS
    shift = dst - a
    songs, new_id = [], {}
    for n, s in enumerate(track_map["songs"], 1):
        lo, hi = max(s["start"], a), min(s["end"], b)
        if lo >= hi:
            continue
        c = dict(s)
        bar = 4 * 60.0 / s["bpm"]
        # Beat 1 moves to the first downbeat at or after the start of the window.
        c["first_downbeat"] = _next_on_grid(s["first_downbeat"], bar, a) if s["first_downbeat"] < a else s["first_downbeat"]
        if s.get("first_phrase") is not None:
            ph = bar * (s.get("phrase_bars") or music.PHRASE_BARS)
            c["first_phrase"] = _next_on_grid(s["first_phrase"], ph, a) if s["first_phrase"] < a else s["first_phrase"]
        c["start"], c["end"] = lo, hi
        for k in ("start", "end", "first_downbeat", "first_phrase"):
            if c.get(k) is not None:
                c[k] = round(c[k] + shift, 3)
        new_id[s.get("song", n)] = first_song + len(songs)
        c["song"] = first_song + len(songs)
        if track is not None:
            c["track"] = track
        songs.append(c)
    events = []
    for e in track_map.get("events") or []:
        if not a <= e["t"] < b or not songs:  # the window is half-open: an event at end_sec is out
            continue
        c = dict(e)
        c["t"] = round(e["t"] + shift, 3)
        if "song" in c:
            # A song that was not played (or an event in a gap) goes to the nearest played one.
            c["song"] = new_id.get(c["song"]) or min(
                songs, key=lambda x: max(x["start"] - c["t"], c["t"] - x["end"], 0))["song"]
        events.append(c)
    sections = []
    for s in track_map.get("sections") or []:
        lo, hi = max(s["start"], a), min(s["end"], b)
        if lo < hi:
            c = dict(s, start=round(lo + shift, 3), end=round(hi + shift, 3))
            if track is not None:
                c["track"] = track
            sections.append(c)
    return {"songs": songs, "events": events, "sections": sections}


def window_map(track_map: dict, start_sec: float, end_sec: float) -> dict:
    """The track's map cut to its played window, in window time (0 = start_sec). Events
    and sections outside are dropped, sections on an edge are clipped, beat 1 moves to
    the first downbeat at or after start_sec; BPM is unchanged. Cuts are rounded to 0.01 s."""
    a, b = _cs(start_sec), _cs(end_sec)
    if not 0 <= a < b:
        raise ValueError("need 0 <= start_sec < end_sec")
    b = _clamp(a, b, _cs(track_map["duration"]))
    c = _cut(track_map, a, b)
    out = {"duration": round((b - a) / CS, 3), "songs": c["songs"], "events": c["events"]}
    if track_map.get("sections") is not None:
        out["sections"] = c["sections"]
    return out


def compose_map(track_maps: list, spec: dict) -> dict:
    """The mix's map: the windows joined with one crossfade per transition. Fields as
    `sync.fit_to_music` reads them (duration, songs, events), `track` (1-based) on each song
    and section, and `sections` with `energy` when the track maps have them."""
    if len(track_maps) != len(spec["tracks"]):
        raise ValueError("%d track maps for %d tracks in the spec" % (len(track_maps), len(spec["tracks"])))
    lay = _layout(spec, [m["duration"] for m in track_maps])
    songs, events, sections = [], [], []
    for t, m in zip(lay, track_maps):
        c = _cut(m, t["src_start"], t["src_end"], t["dst_start"], t["index"] + 1, len(songs) + 1)
        songs += c["songs"]
        events += c["events"]
        sections += c["sections"]
    events.sort(key=lambda e: e["t"])
    out = {"version": music.MAP_VERSION, "source": "composed", "duration": round(_total_cs(lay) / CS, 3),
           "crossfades": [int(c) for c in spec.get("crossfades") or []], "songs": songs, "events": events}
    if any(m.get("sections") is not None for m in track_maps):
        out["sections"] = sections
    return out


def mix_offsets(spec: dict, sample_rate: int, durations: list | None = None) -> list:
    """Per track, in samples: {index (0-based), src_start, src_end, dst_start, fade_in,
    fade_out}. The same arithmetic as `compose_map`, converted once at the
    end with `samples`. Pass `durations` (seconds per track file) to clamp window ends the
    way `compose_map` does."""
    return [{k: (v if k == "index" else (2 * v * sample_rate + CS) // (2 * CS)) for k, v in t.items()}
            for t in _layout(spec, durations)]
