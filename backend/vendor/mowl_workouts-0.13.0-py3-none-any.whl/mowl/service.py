"""High-level actions shared by the MCP server and the command line."""
import contextlib
import copy
import json

from . import api, corpus, library, stats, quality, spotify, sync, workout
from .credentials import Credentials
from .errors import MowlError
from .workout import mmss

SPORTS = {name: value for value, name in workout.ACTIVITY_TYPES.items()}  # {"cycling": 0, "running": 1}

LOW_MARGIN = 1.3  # below this the beat-1 vote can be a beat off (1 of 4 such songs in the Hill mix was)


def _music_opts(spec: dict) -> dict:
    opts = dict(spec.get("music") or {})
    if spec.get("swedebeat") and not opts.get("swedebeat") and not opts.get("spotify"):
        opts["swedebeat"] = spec["swedebeat"]  # older specs put the mix at the top level
    return opts


def _swedebeat_warnings(entry: dict) -> list:
    out = []
    if abs(entry["listed_duration"] - entry["duration"]) > 60:
        out.append(f"Swedebeat lists this mix as {mmss(entry['listed_duration'])} but the audio is "
                   f"{mmss(entry['duration'])}")
    unsure = [s for s in entry["map"]["songs"] if s["beat1_margin"] < LOW_MARGIN and not s.get("beat1_shift")]
    if unsure:
        out.append("beat 1 is an estimate in song " + ", ".join(
            f"{s['song']} ({mmss(s['start'])}-{mmss(s['end'])}, {s['bpm']:.0f} BPM)" for s in unsure)
            + "; listen to the first change in each and, if it is a beat early or late, fix it with correct_beat_one")
    return out


def _spotify_warnings(entry: dict) -> list:
    xf = entry["map"].get("crossfade", 0)
    if xf == spotify.CROSSFADE_SEC:
        fade = ("Spotify's crossfade at 10 s, as MOWL's how-to asks (if crossfade is off on the playing "
                'device, set "crossfade": 0 in music)')
    else:
        fade = f"tracks overlapping {xf:g} s (Spotify's crossfade)" if xf else "crossfade off in Spotify"
    out = [f"Spotify timing assumes the playlist plays in order from the first track, with shuffle off and "
           f"{fade}; bars are counted from Spotify's section starts"]
    unknown = spotify.unknown_bpm(entry["map"])
    if unknown:
        out.append(f"MOWL has no BPM yet for {', '.join(unknown)}; bars there are a guess at 120 BPM, so "
                   "analyse the playlist again in a few minutes")
    out += [f"skipped: {u}" for u in entry.get("unavailable", [])]
    return out


def _crossfade(entry: dict, opts: dict) -> None:
    """Apply the spec's music.crossfade (Spotify only) to the entry's map, in place."""
    if "crossfade" not in opts:
        return
    xf = opts["crossfade"]
    if entry.get("source") != "spotify":
        raise ValueError("crossfade applies to Spotify playlists; a Swedebeat mix has its crossfades in the audio")
    if isinstance(xf, bool) or not isinstance(xf, (int, float)) or not 0 <= xf <= spotify.MAX_CROSSFADE_SEC:
        raise ValueError(f"crossfade must be 0-{spotify.MAX_CROSSFADE_SEC:g} seconds")
    entry["map"] = spotify.with_crossfade(entry["map"], float(xf))
    entry["duration"] = entry["map"]["duration"]


def prepare(spec: dict, creds: Credentials, store: library.MapStore) -> dict:
    """Validate the spec and, with music, fit it to the mix. Writes nothing to the workout list
    (analysing a new mix does create its MOWL playlist, as adding it in the app would)."""
    spec = copy.deepcopy(spec)
    wanted = copy.deepcopy(spec)
    opts = _music_opts(spec)
    warnings, report, playlist_id, mix, m = [], None, -1, None, None
    if opts.get("swedebeat") and opts.get("spotify"):
        raise ValueError("choose either a Swedebeat mix or a Spotify playlist, not both")
    if workout.sport_of(spec) == "running" and (opts.get("swedebeat") or opts.get("spotify")):
        # Before any request: analysing a new mix creates a MOWL playlist, and fitting a run to
        # music (steps per minute, not rpm) is not built yet.
        raise ValueError(workout.RUNNING_MUSIC)
    if opts.get("swedebeat") or opts.get("spotify"):
        entry = (library.swedebeat_map(creds, store, opts["swedebeat"]) if opts.get("swedebeat")
                 else library.spotify_map(creds, store, opts["spotify"]))
        _crossfade(entry, opts)
        playlist_id, m = entry["playlist_id"], entry["map"]
        mix = {"source": entry.get("source", "swedebeat"), "name": entry["name"],
               "duration": mmss(entry["duration"]), "playlist_id": playlist_id}
        if opts.get("snap", True):
            spec["music"] = opts
            spec, report = sync.fit_to_music(spec, entry["map"], tolerance=float(opts.get("tolerance", 6.0)))
        total = workout.total_seconds(spec) if all(isinstance(i["sec"], int) for s in spec["segments"]
                                                   for i in s["intervals"]) else 0
        if total > entry["duration"] + 1:
            warnings.append(f"the workout ({mmss(total)}) is longer than the music ({mmss(entry['duration'])}); "
                            "the rest of the ride has no music")
        warnings += _swedebeat_warnings(entry) if mix["source"] == "swedebeat" else _spotify_warnings(entry)
    for s in spec["segments"]:
        for i in s["intervals"]:
            if i.get("rpm") == "beat":
                i.pop("rpm")  # no music to take a cadence from
    spec.pop("swedebeat", None)
    workout.validate(spec)
    return {"spec": spec, "playlist_id": playlist_id, "music": mix, "timeline": report,
            "warnings": warnings, "quality": quality.report(wanted, spec, m, report),
            "duration": mmss(workout.total_seconds(spec)), "tss": round(workout.tss(spec), 1)}


def preview(spec: dict, creds: Credentials, store: library.MapStore) -> dict:
    return prepare(spec, creds, store)


def save(spec: dict, creds: Credentials, store: library.MapStore, program_id: int | None = None) -> dict:
    """Create a workout, or with program_id update one. An update reads the target first,
    before prepare attaches any music, and writes nothing unless it is the program asked for
    and of the spec's sport: an update never turns a run into a ride or a ride into a run
    (magpern/classbeat#485). workout.save gets that read and doesn't send it again."""
    sport = workout.check_save(spec, program_id=program_id)  # before prepare attaches any music
    target = None
    if program_id is not None:
        if not (type(program_id) is int and program_id > 0):
            raise MowlError(workout.PROGRAM_ID)
        target = api.get_workout(creds, program_id)
        workout.check_target(target, program_id, sport)
    plan = prepare(spec, creds, store)
    result = workout.save(plan["spec"], creds, plan["playlist_id"], program_id, target=target)
    saved = workout.summarize(api.get_workout(creds, result["program_id"]))
    return {**result, "workout": saved, "timeline": plan["timeline"], "warnings": plan["warnings"]}


# --- library statistics (read-only) -----------------------------------------------------

@contextlib.contextmanager
def _sport(creds: Credentials, sport: str | None, notice):
    """Run the body with the account on `sport` ("cycling"/"running"), or on whatever the app
    is already set to when `sport` is None. The library (categories, program search) follows
    this per-account setting, not a request parameter, so a temporary switch is the only way
    to read the other sport. The original value is ALWAYS restored (errors and Ctrl+C included),
    and the effective sport is yielded so the caller can label the result. `notice(msg)` prints
    a one-line, token-free note when the setting is changed."""
    say = notice or (lambda _msg: None)
    current = api.get_activity_type(creds)
    if sport is None:
        yield current
        return
    if sport not in SPORTS:
        raise MowlError(f"--sport must be one of {', '.join(SPORTS)}, not {sport!r}")
    wanted = SPORTS[sport]
    if current == wanted:
        yield wanted  # already on the requested sport; change nothing
        return
    api.set_activity_type(creds, wanted)
    say(f"Temporarily set the account sport to {sport}; it will be restored when done.")
    try:
        yield wanted
    finally:
        if current in workout.ACTIVITY_TYPES:  # a real account is always 0 or 1
            api.set_activity_type(creds, current)
            say(f"Restored the account sport to {workout.ACTIVITY_TYPES[current]}.")


def corpus_categories(creds: Credentials, sport: str | None = None, notice=None) -> dict:
    """What the app lists as program categories (IDs and nothing else is shown). The library is
    per sport: `sport` ("cycling"/"running") reads that sport's categories and restores the
    account setting afterwards; without it, reads whatever the app is on and says which sport."""
    with _sport(creds, sport, notice) as activity_type:
        data = api.program_categories(creds)
        rows = data if isinstance(data, list) else (data or {}).get("Categories") or []
        ids = sorted({r["ProgramCategoryID"] for r in rows if isinstance(r, dict)
                      and type(r.get("ProgramCategoryID")) is int})
        return {"sport": workout.ACTIVITY_TYPES.get(activity_type, "unknown"), "category_ids": ids}


def corpus_fetch(creds: Credentials, store: corpus.CorpusStore, categories: str,
                 sport: str | None = None, notice=None, **opts) -> dict:
    """Cache the programs of the categories, slowly, read-only; resumable. Counts only. The
    library is per sport: `sport` ("cycling"/"running") fetches that sport and restores the
    account setting afterwards; without it, fetches whatever the app is on and says which sport."""
    cats = corpus.parse_categories(categories)  # validate before flipping the live account
    with _sport(creds, sport, notice) as activity_type:
        result = corpus.fetch(creds, store, cats, **opts)
        return {"sport": workout.ACTIVITY_TYPES.get(activity_type, "unknown"), **result}


def corpus_analyze(store, out_dir: str | None = None, min_group: int = stats.MIN_GROUP) -> dict:
    """Aggregate statistics from the cache, written as stats.json and stats.md. Offline."""
    result = stats.analyze(store.programs(), min_group=min_group)
    paths = [store.write_report("stats.json", json.dumps(result, indent=1) + "\n", out_dir),
             store.write_report("stats.md", stats.to_markdown(result), out_dir)]
    return {"programs_analyzed": result["programs_analyzed"], "groups": len(result["groups"]),
            "small_groups_omitted": result["small_groups_omitted"], "written": paths}
