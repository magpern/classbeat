"""One catalogue track on its own (SwedeBeat studio): a single tempo, grid and beat 1 for the
whole file, drops and breakdowns up to its edges, and each section's energy.

`music.analyze_signal` is built for DJ mixes: on one song it can split it into several tempo
runs, and it ignores changes within 2 bars of the file's ends, where a mix cuts. Here the
file is one song, so both are wrong. An event needs about 1.5 bars of music before the end. The beat grid, events and beat 1 reuse music's code."""
import numpy as np

from . import music

TRACK_VERSION = 1  # bump when the track map format or analysis changes
MIN_SECTION_SEC = 8.0  # a shorter stretch between two events is a fill; it joins its neighbour
MIN_ENERGY_SPREAD_DB = 1.5  # sections closer in loudness than this sound alike (as in spotify.py)


def _one_song(f: dict) -> dict:
    """One grid fitted on every reliable window at the track's main tempo."""
    if f["duration"] <= 0:
        raise ValueError("no music to analyse")
    good = [w for w in music.local_tempo(f) if w["score"] >= music.RELIABLE]
    if not good:
        raise ValueError("no steady beat found in the music")
    bpm = float(np.median([w["bpm"] for w in good]))
    ws = [w for w in good if music._same_tempo(w["bpm"], bpm)]
    if not ws:  # noise: reliable windows at scattered tempos, none near their median
        raise ValueError("no steady beat found in the music")
    song = music.refine_song(f, music._fit(f, ws))
    song["start"], song["end"] = 0.0, f["duration"]
    return song


def _sections(f: dict, events: list) -> list:
    """Split at the events, fold short pieces into a neighbour, then rank each piece's
    loudness within the track: 0 quietest, 1 loudest, None when they all sound alike."""
    cuts = [0.0] + [e["t"] for e in events if 0 < e["t"] < f["duration"]] + [f["duration"]]
    secs = [[a, b] for a, b in zip(cuts, cuts[1:])]
    while len(secs) > 1:
        i = next((n for n, s in enumerate(secs) if s[1] - s[0] < MIN_SECTION_SEC), None)
        if i is None:
            break
        j = i - 1 if i else 1
        secs[j] = [min(secs[j][0], secs[i][0]), max(secs[j][1], secs[i][1])]
        del secs[i]
    db = [10 * np.log10(music._span_energy(f["full"], f["times"], a, b) + 1e-10) for a, b in secs]
    flat = len(db) < 2 or max(db) - min(db) < MIN_ENERGY_SPREAD_DB
    out = []
    for (a, b), v in zip(secs, db):
        # rank, so one quiet intro or fade doesn't squash the rest (same as the Spotify map)
        below, same = sum(x < v for x in db), sum(x == v for x in db)
        energy = None if flat else round(float((below + (same - 1) / 2) / (len(db) - 1)), 2)
        out.append({"start": round(float(a), 3), "end": round(float(b), 3), "energy": energy})
    return out


def analyze_track(y: np.ndarray, sr: int = music.SR) -> dict:
    """Analyse one song: {duration, songs: [one], events, sections, track_version}."""
    if len(y) < music.N_FFT:
        raise ValueError("no steady beat found in the music")
    f = music.features(y, sr)
    f["clamp"] = True
    song = _one_song(f)
    events = [{**e, "song": 0} for e in music.downbeats_and_events(f, song)]
    return {
        "duration": round(f["duration"], 3),
        "songs": [{"start": 0, "end": round(f["duration"], 3), "bpm": round(song["bpm"], 3),
                   "first_downbeat": round(song["first_downbeat"], 4),
                   "first_phrase": round(song["first_phrase"], 4), "phrase_bars": music.PHRASE_BARS,
                   "grid_score": round(song["score"], 2), "beat1_margin": song["beat1_margin"]}],
        "events": events,
        "sections": _sections(f, events),
        "track_version": TRACK_VERSION,
    }
